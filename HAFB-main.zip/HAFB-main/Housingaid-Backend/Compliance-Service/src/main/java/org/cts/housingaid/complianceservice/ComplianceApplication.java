package org.cts.housingaid.complianceservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication(scanBasePackages = "org.cts")
@EnableDiscoveryClient
@EnableFeignClients
public class ComplianceApplication {

    public static void main(String[] args) {

        SpringApplication.run(ComplianceApplication.class, args);
        System.out.println("Compliance Service Application Started");

    }

}
