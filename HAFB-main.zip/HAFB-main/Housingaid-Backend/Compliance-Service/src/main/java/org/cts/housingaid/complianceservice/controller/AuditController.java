package org.cts.housingaid.complianceservice.controller;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.cts.housingaid.complianceservice.dto.AuditDTO;
import org.cts.housingaid.complianceservice.exception.AuditNotFoundException;
import org.cts.housingaid.complianceservice.service.AuditService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN')")
@RequestMapping("/compliance/audit")
@AllArgsConstructor
public class AuditController {

    private final AuditService auditService;


    @PostMapping("/create-audit")
    public ResponseEntity<String> createAudit(
            @Valid @RequestBody AuditDTO auditDTO) {
        auditService.createAudit(auditDTO);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body("Audit created successfully");
    }


    @PutMapping("/update-audit")
    public ResponseEntity<String> updateAudit(@Valid @RequestBody AuditDTO auditDTO)
            throws AuditNotFoundException {

        if (auditDTO.getAuditId() == null) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body("Audit ID must be provided for updates.");
        }

        auditService.updateAudit(auditDTO);

        return ResponseEntity
                .status(HttpStatus.OK)
                .body("Audit updated successfully");
    }

    @GetMapping("/get-all-audits")
    public ResponseEntity<List<AuditDTO>> getAllAudits()
            throws AuditNotFoundException {

        List<AuditDTO> list = auditService.getAllAudits();

        return ResponseEntity
                .status(HttpStatus.OK)
                .body(list);
    }


    @GetMapping("/search-audit")
    public ResponseEntity<List<AuditDTO>> searchAudit(
            @RequestParam(required = false) Long officerId,
            @RequestParam(required = false) String scope)
            throws AuditNotFoundException {

        if (officerId == null && (scope == null || scope.trim().isEmpty())) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .build();
        }

        List<AuditDTO> list = auditService.getAuditsByOfficerOrScope(officerId, scope);

        return ResponseEntity
                .status(HttpStatus.OK)
                .body(list);
    }
}
