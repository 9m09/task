package org.cts.housingaid.complianceservice.controller;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.cts.housingaid.complianceservice.dto.ComplianceRecordDTO;
import org.cts.housingaid.complianceservice.enums.ComplianceEntityType;
import org.cts.housingaid.complianceservice.exception.ComplianceRecordNotFoundException;
import org.cts.housingaid.complianceservice.service.ComplianceRecordService;
//import org.cts.housingaid.service.HousingApplicationService;
//import org.cts.housingaid.service.HousingProjectService;
//import org.cts.housingaid.service.HousingUnitService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN')")
@RequestMapping("/compliance/compliance-record")
@AllArgsConstructor
public class ComplianceRecordController {

    private final ComplianceRecordService complianceRecordService;

    @PostMapping("/create-compliance-record")
    public ResponseEntity<String> saveComplianceRecord(@Valid @RequestBody ComplianceRecordDTO record) {

        complianceRecordService.saveRecord(record);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body("Compliance Record created successfully");
    }

    @GetMapping("/get-all-compliance-records")
    public ResponseEntity<List<ComplianceRecordDTO>> getAllRecords() throws ComplianceRecordNotFoundException {

        List<ComplianceRecordDTO> list =
                complianceRecordService.getAllRecords();

        return ResponseEntity
                .status(HttpStatus.OK)
                .body(list);
    }

    @GetMapping("/search-compliance-record")
    public ResponseEntity<List<ComplianceRecordDTO>> getByEntityOrType(
            @RequestParam(required = false) Long entityId,
            @RequestParam(required = false) ComplianceEntityType type)
            throws ComplianceRecordNotFoundException {

        List<ComplianceRecordDTO> list = complianceRecordService
                        .getRecordsByEntityIdOrType(
                                Math.toIntExact(entityId),
                                type
                        );

        return ResponseEntity
                .status(HttpStatus.OK)
                .body(list);
    }

//    @GetMapping("/get-compliance-dashboard")
//    public ResponseEntity<Map<String, Object>> getComplianceDashboard(
//            @RequestParam(name = "selection", required = false, defaultValue = "ALL") String selection) {
//
//        Map<String, Object> dashboard = new LinkedHashMap<>(); // LinkedHashMap keeps the order nice
//        String choice = selection.toUpperCase();
//
//        System.out.println("Dashboard Request Received for: " + choice);
//
//        // 1. Check Projects
//        if (choice.equals("PROJECT") || choice.equals("ALL")) {
//            try {
//                List<HousingProjectDTO> projects = housingProjectService.getAllHousingProjects();
//                System.out.println("Projects found: " + (projects != null ? projects.size() : 0));
//                dashboard.put("projects", projects);
//            } catch (Exception e) {
//                System.err.println("Error fetching Projects: " + e.getMessage());
//                dashboard.put("projects", new ArrayList<>());
//            }
//        }
//
//        // 2. Check Units
//        if (choice.equals("UNIT") || choice.equals("ALL")) {
//            try {
//                List<HousingUnitDTO> units = housingUnitService.getAllHousingUnits();
//                System.out.println("Units found: " + (units != null ? units.size() : 0));
//                dashboard.put("housingUnits", units);
//            } catch (Exception e) {
//                System.err.println("Error fetching Units: " + e.getMessage());
//                dashboard.put("housingUnits", new ArrayList<>());
//            }
//        }
//
//        // 3. Check Applications
//        if (choice.equals("APPLICATION") || choice.equals("ALL")) {
//            try {
//                List<HousingApplicationDTO> apps = housingApplicationService.getAllHousingApplications();
//                System.out.println("Applications found: " + (apps != null ? apps.size() : 0));
//                dashboard.put("applications", apps);
//            } catch (Exception e) {
//                System.err.println("Error fetching Applications: " + e.getMessage());
//                dashboard.put("applications", new ArrayList<>());
//            }
//        }
//
//        return ResponseEntity.ok(dashboard);
//    }
    @GetMapping("/get-compliance-dashboard")
    public ResponseEntity<Map<String, Object>> getComplianceDashboard(
            @RequestParam(name = "selection", required = false, defaultValue = "ALL") String selection) {

        // Delegate all logic to the service layer
        Map<String, Object> dashboard = complianceRecordService.getDashboardData(selection);

        return ResponseEntity.ok(dashboard);
    }
}
