package org.cts.housingaid.complianceservice.dao;

import org.cts.housingaid.complianceservice.entity.ComplianceRecord;
import org.cts.housingaid.complianceservice.enums.ComplianceEntityType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ComplianceRecordRepository extends JpaRepository<ComplianceRecord, Long> {

    @Query("SELECT cr FROM ComplianceRecord cr WHERE cr.entityId = :entityId AND cr.type = :entityType")
    List<ComplianceRecord> findByEntityIdOrType(
            @Param("entityId") Long entityId,
            @Param("entityType") ComplianceEntityType type
    );

}
