package org.cts.housingaid.complianceservice.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cts.housingaid.complianceservice.enums.HousingApplicationStatus;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HousingApplicationDTO {

    private Long housingApplicationId;
    private Long citizenId;
    private Long housingProjectId;
    private String housingApplicantName;
    private String housingSchemeName;
    private LocalDateTime housingApplicationSubmittedDate;
    private HousingApplicationStatus housingApplicationStatus;
}