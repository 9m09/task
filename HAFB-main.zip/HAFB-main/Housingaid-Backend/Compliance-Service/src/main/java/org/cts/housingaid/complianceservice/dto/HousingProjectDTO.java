package org.cts.housingaid.complianceservice.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cts.housingaid.complianceservice.enums.HousingProjectStatus;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HousingProjectDTO {

    private Long housingProjectId;


    private Long numberOfHouses;


    private String housingProjectTitle;


    private String housingProjectDescription;


    private LocalDate housingProjectStartDate;


    private LocalDate housingProjectEndDate;


    private Double housingProjectBudget;

    private HousingProjectStatus housingProjectStatus;

}
