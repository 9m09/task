package org.cts.housingaid.complianceservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cts.housingaid.complianceservice.enums.HousingUnitStatus;
import org.cts.housingaid.complianceservice.enums.HousingUnitType;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HousingUnitDTO {

    private Long housingUnitId;

    private String housingUnitLocation;

    private HousingUnitType housingUnitType;

    private Long housingUnitCapacity;

    private HousingUnitStatus housingUnitStatus;

    private Long resourcesId;

    private Long housingProjectId;

}
