package org.cts.housingaid.complianceservice.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cts.housingaid.complianceservice.enums.AuditStatus;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Audit") // Matches your CREATE TABLE Audit
public class Audit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long auditId;

    @NotNull(message = "Officer ID is required")
    private Long officerId;

    @Column(name = "auditScope")
    @JsonProperty("scope")
    private String scope;

    @Column(name = "auditFindings")
    @JsonProperty("remarks")
    @NotBlank(message = "Findings required")
    private String findings;

    @Column(name = "auditDate")
    @JsonProperty("auditDate")
    @NotNull(message = "Date required")
    private LocalDate date;

    @Enumerated(EnumType.STRING)
    @Column(name = "auditStatus")
    @JsonProperty("status")
    private AuditStatus status;
}
