package org.cts.housingaid.complianceservice.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cts.housingaid.complianceservice.enums.ComplianceEntityType;
import org.cts.housingaid.complianceservice.enums.ComplianceResult;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class ComplianceRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long complianceId;

    private Long entityId;

    @Column(name = "entityType")
    @Enumerated(EnumType.STRING)
    private ComplianceEntityType type;

    @Enumerated(EnumType.STRING)
    private ComplianceResult result;

    private LocalDate date;

    private String notes;
}
