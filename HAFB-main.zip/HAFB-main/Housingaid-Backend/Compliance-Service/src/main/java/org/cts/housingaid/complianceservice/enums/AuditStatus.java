package org.cts.housingaid.complianceservice.enums;

public enum AuditStatus {
    PENDING, COMPLETED, FLAGGED
}