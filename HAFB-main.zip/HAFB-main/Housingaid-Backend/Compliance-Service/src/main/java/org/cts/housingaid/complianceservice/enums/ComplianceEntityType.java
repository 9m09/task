package org.cts.housingaid.complianceservice.enums;

public enum ComplianceEntityType {
    APPLICATION, UNIT, PROJECT
}