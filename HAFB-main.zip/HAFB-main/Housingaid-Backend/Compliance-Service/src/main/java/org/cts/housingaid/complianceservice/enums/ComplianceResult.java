package org.cts.housingaid.complianceservice.enums;

public enum ComplianceResult {
    COMPLIANT, NONCOMPLIANT
}