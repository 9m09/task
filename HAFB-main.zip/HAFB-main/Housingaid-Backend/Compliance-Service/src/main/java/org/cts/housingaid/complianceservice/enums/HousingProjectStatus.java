package org.cts.housingaid.complianceservice.enums;


public enum HousingProjectStatus {
    PLANNED, UNDERPROGRESS, COMPLETED
}
