package org.cts.housingaid.complianceservice.enums;


public enum HousingUnitStatus {
    AVAILABLE,ALLOCATED,MAINTENANCE
}
