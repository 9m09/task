package org.cts.housingaid.complianceservice.enums;


public enum HousingUnitType {
    APARTMENT, SHELTER
}