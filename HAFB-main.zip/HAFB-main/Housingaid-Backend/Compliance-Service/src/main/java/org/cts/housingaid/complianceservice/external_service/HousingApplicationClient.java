package org.cts.housingaid.complianceservice.external_service;

import org.cts.housingaid.complianceservice.dto.HousingApplicationDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "application-service",configuration = FeignClientInterceptor.class)
public interface HousingApplicationClient {
    @GetMapping("/application/housing-application/all")
    List<HousingApplicationDTO> getAllHousingApplications();
}
