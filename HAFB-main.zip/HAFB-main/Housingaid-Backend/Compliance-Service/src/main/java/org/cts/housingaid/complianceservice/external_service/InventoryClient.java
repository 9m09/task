package org.cts.housingaid.complianceservice.external_service;

import org.cts.housingaid.complianceservice.dto.HousingProjectDTO;
import org.cts.housingaid.complianceservice.dto.HousingUnitDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "inventory-service",configuration = FeignClientInterceptor.class)
public interface InventoryClient {

    @GetMapping("/inventory/housing-unit/get-all-housing-units")
    List<HousingUnitDTO> getAllHousingUnits();

    @GetMapping("/inventory/housing-project/get-all-housing-projects")
    List<HousingProjectDTO> getAllHousingProjects();
}
