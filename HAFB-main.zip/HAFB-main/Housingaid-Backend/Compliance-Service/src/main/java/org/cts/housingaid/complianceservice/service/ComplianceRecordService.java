package org.cts.housingaid.complianceservice.service;

import org.cts.housingaid.complianceservice.dto.ComplianceRecordDTO;
import org.cts.housingaid.complianceservice.enums.ComplianceEntityType;
import org.cts.housingaid.complianceservice.exception.ComplianceRecordNotFoundException;

import java.util.List;
import java.util.Map;

public interface ComplianceRecordService {

    void saveRecord(ComplianceRecordDTO dto);

    List<ComplianceRecordDTO> getRecordsByEntityIdOrType(
            Integer entityId,
            ComplianceEntityType type)
            throws ComplianceRecordNotFoundException;

    List<ComplianceRecordDTO> getAllRecords()
            throws ComplianceRecordNotFoundException;

    Map<String, Object> getDashboardData(String selection)
    throws ComplianceRecordNotFoundException;
}

