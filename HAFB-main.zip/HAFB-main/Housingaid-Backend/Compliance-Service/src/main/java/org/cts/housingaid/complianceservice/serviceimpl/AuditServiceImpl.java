package org.cts.housingaid.complianceservice.serviceimpl;

import lombok.AllArgsConstructor;
import org.cts.housingaid.complianceservice.dao.AuditRepository;
import org.cts.housingaid.complianceservice.dto.AuditDTO;
import org.cts.housingaid.complianceservice.entity.Audit;
import org.cts.housingaid.complianceservice.exception.AuditNotFoundException;
import org.cts.housingaid.complianceservice.service.AuditService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

import static org.cts.housingaid.complianceservice.util.ExceptionConstants.AUDIT_NOT_FOUND;
import static org.cts.housingaid.complianceservice.util.ExceptionConstants.EMPTY_PROJECT;

@Service
@AllArgsConstructor
public class AuditServiceImpl implements AuditService {

    private final AuditRepository auditRepository;
    private final ModelMapper modelMapper; // Injected via @AllArgsConstructor

    @Override
    @Transactional
    public void createAudit(AuditDTO auditDTO) {
        // Automatically maps DTO to a new Entity
        Audit audit = modelMapper.map(auditDTO, Audit.class);

        // Ensure the ID is null for a new record so DB generates a fresh one
        audit.setAuditId(null);

        auditRepository.save(audit);
    }

    @Override
    @Transactional
    public void updateAudit(AuditDTO auditDTO) throws AuditNotFoundException {
        // 1. Verify the record exists
        auditRepository.findById(auditDTO.getAuditId())
                .orElseThrow(() -> new AuditNotFoundException(AUDIT_NOT_FOUND));

        // 2. Map DTO directly to an Entity object
        Audit audit = modelMapper.map(auditDTO, Audit.class);

        // 3. Save the updated entity
        auditRepository.save(audit);
    }

    @Override
    public List<AuditDTO> getAllAudits() throws AuditNotFoundException {
        List<Audit> list = auditRepository.findAll();

        if (list.isEmpty()) {
            throw new AuditNotFoundException(EMPTY_PROJECT);
        }

        return list.stream()
                .map(audit -> modelMapper.map(audit, AuditDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<AuditDTO> getAuditsByOfficerOrScope(Long officerId, String scope)
            throws AuditNotFoundException {

        List<Audit> list = auditRepository.findByOfficerIdAndScope(officerId, scope);

        if (list.isEmpty()) {
            throw new AuditNotFoundException(AUDIT_NOT_FOUND);
        }

        return list.stream()
                .map(audit -> modelMapper.map(audit, AuditDTO.class))
                .collect(Collectors.toList());
    }
}