package org.cts.housingaid.complianceservice.serviceimpl;

import lombok.AllArgsConstructor;
import org.cts.housingaid.complianceservice.dao.ComplianceRecordRepository;
import org.cts.housingaid.complianceservice.dto.ComplianceRecordDTO;
import org.cts.housingaid.complianceservice.entity.ComplianceRecord;
import org.cts.housingaid.complianceservice.enums.ComplianceEntityType;
import org.cts.housingaid.complianceservice.exception.ComplianceRecordNotFoundException;
import org.cts.housingaid.complianceservice.external_service.HousingApplicationClient;
import org.cts.housingaid.complianceservice.external_service.InventoryClient;
import org.cts.housingaid.complianceservice.service.ComplianceRecordService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static org.cts.housingaid.complianceservice.util.ExceptionConstants.EMPTY_PROJECT;

@Service
@AllArgsConstructor
public class ComplianceRecordServiceImpl implements ComplianceRecordService {

    private final ComplianceRecordRepository complianceRecordRepository;
    private final ModelMapper modelMapper; // Injected automatically via @AllArgsConstructor
    private final InventoryClient  inventoryClient;
    private final HousingApplicationClient applicationClient;

    @Override
    public void saveRecord(ComplianceRecordDTO dto) {
        // Automatically creates a new ComplianceRecord and copies all matching fields
        ComplianceRecord record = modelMapper.map(dto, ComplianceRecord.class);
        complianceRecordRepository.save(record);
    }

    @Override
    public List<ComplianceRecordDTO> getRecordsByEntityIdOrType(
            Integer entityId,
            ComplianceEntityType type)
            throws ComplianceRecordNotFoundException {

        List<ComplianceRecord> list = complianceRecordRepository
                .findByEntityIdOrType(Long.valueOf(entityId), type);


        if (list.isEmpty()) {
            throw new ComplianceRecordNotFoundException(EMPTY_PROJECT);
        }

        // Transforms the stream of Entities into DTOs using ModelMapper
        return list.stream()
                .map(record -> modelMapper.map(record, ComplianceRecordDTO.class))
                .collect(Collectors.toList());
    }



//    @Override
//    public List<ComplianceRecordDTO> getAllRecords()
//            throws ComplianceRecordNotFoundException {
//
//        List<ComplianceRecord> list = complianceRecordRepository.findAll();
//
//        if (list.isEmpty()) {
//            throw new ComplianceRecordNotFoundException(EMPTY_PROJECT);
//        }
//
//        return list.stream()
//                .map(record -> modelMapper.map(record, ComplianceRecordDTO.class))
//                .collect(Collectors.toList());
//    }

    @Override
    public List<ComplianceRecordDTO> getAllRecords()
            throws ComplianceRecordNotFoundException {

        return Optional.of(complianceRecordRepository.findAll())
                .filter(list -> !list.isEmpty()) // Only proceed if list is not empty
                .map(list -> list.stream()
                        .map(record -> modelMapper.map(record, ComplianceRecordDTO.class))
                        .toList())               // Java 16+ concise version of collect
                .orElseThrow(() -> new ComplianceRecordNotFoundException(EMPTY_PROJECT));
    }

    public Map<String, Object> getDashboardData(String selection) {
        Map<String, Object> dashboard = new LinkedHashMap<>();
        String choice = selection.toUpperCase();

        if (choice.equals("PROJECT") || choice.equals("ALL")) {
            try {
                dashboard.put("projects", inventoryClient.getAllHousingProjects());
            } catch (Exception e) {
                dashboard.put("projects", Collections.emptyList());
            }
        }

        if (choice.equals("UNIT") || choice.equals("ALL")) {
            try {
                dashboard.put("housingUnits", inventoryClient.getAllHousingUnits());
            } catch (Exception e) {
                dashboard.put("housingUnits", Collections.emptyList());
            }
        }

        if (choice.equals("APPLICATION") || choice.equals("ALL")) {
            try {
                dashboard.put("applications", applicationClient.getAllHousingApplications());
            } catch (Exception e) {
                dashboard.put("applications", Collections.emptyList());
            }
        }
        return dashboard;
    }
}