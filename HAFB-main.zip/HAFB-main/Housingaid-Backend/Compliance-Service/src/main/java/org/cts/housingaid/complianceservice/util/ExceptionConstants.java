package org.cts.housingaid.complianceservice.util;

public class ExceptionConstants {

    public static final String AUDIT_NOT_FOUND = "Audit record not found.";
    public static final String COMPLIANCE_NOT_FOUND = "Compliance record not found.";
    public static final String EMPTY_PROJECT = "No data available in the database.";

    private ExceptionConstants() {
    }
}