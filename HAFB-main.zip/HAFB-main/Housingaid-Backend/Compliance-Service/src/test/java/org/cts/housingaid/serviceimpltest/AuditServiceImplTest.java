package org.cts.housingaid.serviceimpltest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.cts.housingaid.complianceservice.dao.AuditRepository;
import org.cts.housingaid.complianceservice.dto.AuditDTO;
import org.cts.housingaid.complianceservice.entity.Audit;
import org.cts.housingaid.complianceservice.exception.AuditNotFoundException;
import org.cts.housingaid.complianceservice.serviceimpl.AuditServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.List;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
class AuditServiceImplTest {

    @Mock
    private AuditRepository auditRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private AuditServiceImpl auditService;

    private Audit audit;
    private AuditDTO auditDTO;

    @BeforeEach
    void setUp() {
        audit = new Audit();
        audit.setAuditId(1L);

        auditDTO = new AuditDTO();
        auditDTO.setAuditId(1L);
    }

    @Test
    void testCreateAudit_Success() {
        when(modelMapper.map(auditDTO, Audit.class)).thenReturn(audit);

        auditService.createAudit(auditDTO);

        verify(auditRepository, times(1)).save(audit);
        assertNull(audit.getAuditId()); // Verifies the code sets ID to null for new records
    }

    @Test
    void testUpdateAudit_ThrowsException_WhenNotFound() {
        when(auditRepository.findById(anyLong())).thenReturn(Optional.empty());

        assertThrows(AuditNotFoundException.class, () -> auditService.updateAudit(auditDTO));
    }

    @Test
    void testGetAllAudits_Success() throws AuditNotFoundException {
        when(auditRepository.findAll()).thenReturn(List.of(audit));
        when(modelMapper.map(audit, AuditDTO.class)).thenReturn(auditDTO);

        List<AuditDTO> result = auditService.getAllAudits();

        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
    }
}