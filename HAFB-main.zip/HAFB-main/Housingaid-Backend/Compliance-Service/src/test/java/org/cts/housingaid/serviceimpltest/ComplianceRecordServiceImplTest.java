package org.cts.housingaid.serviceimpltest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.cts.housingaid.complianceservice.dao.ComplianceRecordRepository;
import org.cts.housingaid.complianceservice.dto.ComplianceRecordDTO;
import org.cts.housingaid.complianceservice.entity.ComplianceRecord;
import org.cts.housingaid.complianceservice.enums.ComplianceEntityType;
import org.cts.housingaid.complianceservice.exception.ComplianceRecordNotFoundException;
import org.cts.housingaid.complianceservice.serviceimpl.ComplianceRecordServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;

import java.util.Collections;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class ComplianceRecordServiceImplTest {

    @Mock
    private ComplianceRecordRepository complianceRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private ComplianceRecordServiceImpl complianceService;

    private ComplianceRecord record;
    private ComplianceRecordDTO recordDTO;

    @BeforeEach
    void setUp() {
        record = new ComplianceRecord();
        recordDTO = new ComplianceRecordDTO();
    }

    @Test
    void testSaveRecord_Success() {
        when(modelMapper.map(recordDTO, ComplianceRecord.class)).thenReturn(record);

        complianceService.saveRecord(recordDTO);

        verify(complianceRepository, times(1)).save(record);
    }

    @Test
    void testGetAllRecords_ThrowsException_WhenEmpty() {
        // Simulating an empty list from database
        when(complianceRepository.findAll()).thenReturn(Collections.emptyList());

        assertThrows(ComplianceRecordNotFoundException.class, () -> complianceService.getAllRecords());
    }

    @Test
    void testGetRecordsByEntityIdOrType_Success() throws ComplianceRecordNotFoundException {
        // Arrange
        ComplianceEntityType type = ComplianceEntityType.UNIT;
        when(complianceRepository.findByEntityIdOrType(101L, type)).thenReturn(List.of(record));
        when(modelMapper.map(record, ComplianceRecordDTO.class)).thenReturn(recordDTO);

        // Act
        List<ComplianceRecordDTO> result = complianceService.getRecordsByEntityIdOrType(101, type);

        // Assert
        assertEquals(1, result.size());
        verify(complianceRepository).findByEntityIdOrType(101L, type);
    }
}