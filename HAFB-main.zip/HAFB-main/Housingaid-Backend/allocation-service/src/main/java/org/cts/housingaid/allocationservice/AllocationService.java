package org.cts.housingaid.allocationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * Hello world!
 *
 */
@SpringBootApplication(scanBasePackages = "org.cts")
@EnableFeignClients
@EnableDiscoveryClient
public class AllocationService
{
    public static void main( String[] args )
    {
        SpringApplication.run(AllocationService.class,args);
        System.out.println("Allocation Service is Started");
    }
}
//git remote add origin https://github.com/logesh0205-cts/Allocation-Service.git
//git branch -M main
//git push -u origin main