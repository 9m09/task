package org.cts.housingaid.allocationservice.Client;

import org.cts.housingaid.allocationservice.dto.HousingApplicationDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name="APPLICATION-SERVICE" ,configuration = FeignClientInterceptor.class)
public interface HousingApplicationClient {
    @GetMapping("/application/housing-application/applicationId")
    public Long getHosuingApplication(@RequestParam Long citizenId, @RequestParam String status); // housingapplication status -- approved
    @GetMapping("/application/eligibility-check/get-result")
    public Long getEligibilityCheckId(@RequestParam Long housingApplicationId,@RequestParam String status); // eligibility status -- eligible
    @GetMapping("/application/housing-application/Id")
    public HousingApplicationDTO getHousingApplicationDTOById(@RequestParam Long housingApplicationId);
}
