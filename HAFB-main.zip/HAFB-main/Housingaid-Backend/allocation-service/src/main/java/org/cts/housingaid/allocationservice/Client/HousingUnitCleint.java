package org.cts.housingaid.allocationservice.Client;

import org.cts.housingaid.allocationservice.dto.HousingUnitDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name="INVENTORY-SERVICE", configuration = FeignClientInterceptor.class)
public interface HousingUnitCleint {
    @GetMapping("/inventory/housing-unit/get-id")
        // You MUST add ("housingProjectId") inside the annotation
    List<Long> getHousingUnitId(@RequestParam("housingProjectId") Long housingProjectId);

    @GetMapping("inventory/housing-unit/find-status")
    public String findStatus(@RequestParam  Long housingUnitId); // housingUnit Status --> AVAILABLE

    @PutMapping("inventory/housing-unit/update")
    public void updateHousingStatus(@RequestParam String housingStatus,@RequestParam Long housingUnitId);

    @GetMapping("inventory/housing-unit/get-by-id")
    public HousingUnitDTO getHousingUnitById(@RequestParam Long housingUnitId);

    @PutMapping("/inventory/housing-project/update-no-of-houses")
    public void updateNoOfHouses(@RequestParam Long housingProjectId);


}
