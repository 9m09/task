package org.cts.housingaid.allocationservice.controller;

import lombok.AllArgsConstructor;
import org.cts.housingaid.allocationservice.dto.AllocationRequestDTO;
import org.cts.housingaid.allocationservice.dto.AllocationResponseDTO;
import org.cts.housingaid.allocationservice.service.AllocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@PreAuthorize("hasAnyRole('OFFICER','ADMIN')")
@RequestMapping("/allocation/allocations")
@AllArgsConstructor
public class AllocationController {

    @Autowired
    private AllocationService allocationService;

    @PostMapping("/create")
    public ResponseEntity<AllocationResponseDTO> createAllocation(@RequestBody AllocationRequestDTO requestDTO) {
        // Returns 201 Created upon success
        return new ResponseEntity<>(allocationService.createAllocation(requestDTO), HttpStatus.CREATED);
    }
       
    @PreAuthorize("hasAnyRole('AUDITOR','ADMIN','OFFICER')")
    @GetMapping("/get-all-Allocation")
    public ResponseEntity<List<AllocationResponseDTO>> getAllAllocation() {
        // Returns 200 OK upon success
        return ResponseEntity.ok(allocationService.getAllAllocation());
    }

    @PreAuthorize("hasAnyRole('AUDITOR','ADMIN','OFFICER')")
    @GetMapping("/total")
    public long getTotalAllocations() {
        return allocationService.getTotalAllocations();
    }

    @PreAuthorize("hasAnyRole('AUDITOR','ADMIN','OFFICER')")
    @GetMapping("/count/{status}")
    public long getCountByStatus(@PathVariable String status) {
        return allocationService.countByStatus(status);
    }
}