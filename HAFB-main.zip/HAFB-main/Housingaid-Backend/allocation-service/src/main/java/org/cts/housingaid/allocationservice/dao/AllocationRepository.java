package org.cts.housingaid.allocationservice.dao;

import org.cts.housingaid.allocationservice.entity.Allocation;
import org.cts.housingaid.allocationservice.enums.AllocationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AllocationRepository extends JpaRepository<Allocation, Long> {

    long countByStatus(AllocationStatus status);
}