package org.cts.housingaid.allocationservice.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AllocationRequestDTO {
    @Positive(message = "CitizenId should be positive ")
    @NotNull(message="CitizenID can't be null")
    private Long citizenId;
    @Positive(message = "OfficerId should be positive ")
    @NotNull(message="OfficerID can't be null")
    private Long officerId;
    @Positive(message = "housingProjectId should be positive ")
    @NotNull(message="housingProjectId can't be null")
    private Long housingProjectId;

    private String allocationMessage;
}
