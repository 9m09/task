package org.cts.housingaid.allocationservice.dto;


import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cts.housingaid.allocationservice.enums.HousingApplicationStatus;
import org.cts.housingaid.allocationservice.enums.HousingUnitType;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HousingApplicationDTO {

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long housingApplicationId;

    @NotNull(message = "Citizen ID is required")
    private Long citizenId;

    @NotNull(message = "Project ID is required")
    private Long housingProjectId;

    private HousingUnitType housingUnitType;
    private Long housingCapacity;

    private LocalDateTime housingApplicationSubmittedDate;
    private HousingApplicationStatus housingApplicationStatus;
}