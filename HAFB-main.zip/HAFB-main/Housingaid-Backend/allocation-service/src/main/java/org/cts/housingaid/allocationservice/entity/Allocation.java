package org.cts.housingaid.allocationservice.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cts.housingaid.allocationservice.enums.AllocationStatus;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Allocation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long allocationId;

    private Long officerId;

    private LocalDate allocationDate;

    @Enumerated(EnumType.STRING)
    private AllocationStatus status;

    private Long housingUnitId;

    private Long eligibilityCheckId;

    private Long citizenId;

    private String allocationMessage;

}