package org.cts.housingaid.allocationservice.enums;

public enum AllocationStatus {
    ALLOCATED, NOTALLOCATED
}