package org.cts.housingaid.allocationservice.enums;



public enum HousingApplicationStatus {
    PENDING,      // Initial state
    UNDER_REVIEW, // Officer is currently checking documents
    APPROVED,     // Result was ELIGIBLE
    REJECTED      // Result was NOTELIGIBLE
}