package org.cts.housingaid.allocationservice.enums;

public enum HousingUnitStatus {
    AVAILABLE,ALLOCATED,MAINTENANCE
}