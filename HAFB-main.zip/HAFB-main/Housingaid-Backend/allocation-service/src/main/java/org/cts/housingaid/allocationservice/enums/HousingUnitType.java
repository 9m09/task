package org.cts.housingaid.allocationservice.enums;

public enum HousingUnitType {
    APARTMENT, SHELTER
}
