package org.cts.housingaid.allocationservice.exception;

import org.cts.housingaid.allocationservice.util.ExceptionConstants;

public class AllocationNotFoundException extends RuntimeException {

    public AllocationNotFoundException() {
        super(ExceptionConstants.ALLOCATION_NOT_FOUND);
    }
    public AllocationNotFoundException(String message) {
        super(message);
    }
}