package org.cts.housingaid.allocationservice.exception;

public class AllocationProcessingException extends RuntimeException {
    public AllocationProcessingException(String message) {
        super(message);
    }
}
