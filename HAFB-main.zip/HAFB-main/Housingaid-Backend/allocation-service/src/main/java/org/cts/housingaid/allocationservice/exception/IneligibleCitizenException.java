package org.cts.housingaid.allocationservice.exception;

public class IneligibleCitizenException extends RuntimeException {
    public IneligibleCitizenException(String message) {
        super(message);
    }
}
