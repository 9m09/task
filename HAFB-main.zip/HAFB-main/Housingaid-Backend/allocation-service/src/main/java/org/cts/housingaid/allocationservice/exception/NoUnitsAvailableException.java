package org.cts.housingaid.allocationservice.exception;

public class NoUnitsAvailableException extends RuntimeException {
    public NoUnitsAvailableException(String message) {
        super(message);
    }
}
