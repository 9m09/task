package org.cts.housingaid.allocationservice.exception;

public class ProjectUnitNotFoundException extends RuntimeException {
    public ProjectUnitNotFoundException(String message) {
        super(message);
    }
}
