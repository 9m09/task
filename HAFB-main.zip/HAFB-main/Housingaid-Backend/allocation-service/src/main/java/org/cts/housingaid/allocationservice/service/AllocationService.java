package org.cts.housingaid.allocationservice.service;

import org.cts.housingaid.allocationservice.dto.AllocationRequestDTO;
import org.cts.housingaid.allocationservice.dto.AllocationResponseDTO;

import java.util.List;

public interface AllocationService {

    List<AllocationResponseDTO> getAllAllocation();

    AllocationResponseDTO createAllocation(AllocationRequestDTO requestDTO);

    long getTotalAllocations();

    long countByStatus(String status);

}