package org.cts.housingaid.allocationservice.serviceimpl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j; // Added for logging
import org.cts.housingaid.allocationservice.Client.HousingApplicationClient;
import org.cts.housingaid.allocationservice.Client.HousingUnitCleint;
import org.cts.housingaid.allocationservice.dao.AllocationRepository;
import org.cts.housingaid.allocationservice.dto.AllocationRequestDTO;
import org.cts.housingaid.allocationservice.dto.AllocationResponseDTO;
import org.cts.housingaid.allocationservice.dto.HousingApplicationDTO;
import org.cts.housingaid.allocationservice.dto.HousingUnitDTO;
import org.cts.housingaid.allocationservice.entity.Allocation;
import org.cts.housingaid.allocationservice.enums.AllocationStatus;
import org.cts.housingaid.allocationservice.enums.HousingUnitStatus;
import org.cts.housingaid.allocationservice.exception.*; // Ensure these custom exceptions exist
import org.cts.housingaid.allocationservice.service.AllocationService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

import static org.cts.housingaid.allocationservice.util.ExceptionConstants.EMPTY_DATA;

@Service
@AllArgsConstructor
@Slf4j // Logs help you trace the flow in the console
public class AllocationServiceImpl implements AllocationService {

    @Autowired
    private AllocationRepository allocationRepository;
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private HousingApplicationClient housingApplicationClient;
    @Autowired
    private HousingUnitCleint housingUnitCleint;

    @Override
    @Transactional
    public AllocationResponseDTO createAllocation(AllocationRequestDTO requestDTO) {
        log.info("Starting allocation process for citizen ID: {}", requestDTO.getCitizenId());

        // 1. Validate Input (Basic Guard Clause)
        if (requestDTO.getHousingProjectId() == null) {
            throw new IllegalArgumentException("Project ID must not be null.");
        }

        // 2. Check for Approved Application
        // Wrap client calls in try-catch if you want to handle 404s or timeouts specifically
        Long housingApplicationId = housingApplicationClient.getHosuingApplication(requestDTO.getCitizenId(), "APPROVED");
        System.out.println(housingApplicationId);
        HousingApplicationDTO housingApplicationDTO=housingApplicationClient.getHousingApplicationDTOById(housingApplicationId);

        if (housingApplicationId == null) {
            log.error("No approved application found for citizen: {}", requestDTO.getCitizenId());
            throw new ApplicationNotFoundException("No approved housing application found for citizen: " + requestDTO.getCitizenId());
        }

        // 3. Check for Eligibility


        Long eligibilityCheckId = housingApplicationClient.getEligibilityCheckId(housingApplicationId, "ELIGIBLE");
        System.out.println("hello :"+eligibilityCheckId);
        if (eligibilityCheckId == null) {
            log.error("Citizen ID {} is not eligible for allocation.", requestDTO.getCitizenId());
            throw new IneligibleCitizenException("Citizen is not marked as ELIGIBLE in the system.");
        }

        // 4. Check for Housing Project Units
        List<Long> housingUnitIds = housingUnitCleint.getHousingUnitId(requestDTO.getHousingProjectId());
        if (housingUnitIds == null || housingUnitIds.isEmpty()) {
            log.error("No units found for project ID: {}", requestDTO.getHousingProjectId());
            throw new ProjectUnitNotFoundException("The requested project has no registered units.");
        }

        // 5. Find an Available Unit
        for (Long unitId : housingUnitIds) {
            HousingUnitDTO housingUnitDTO = housingUnitCleint.getHousingUnitById(unitId);

            // Logical Check: Ensure we don't try to allocate an already ALLOCATED unit
            // Note: I reversed your logic to check for AVAILABLE status instead of ALLOCATED
            if (HousingUnitStatus.AVAILABLE.equals(housingUnitDTO.getHousingUnitStatus())
                    && housingApplicationDTO.getHousingCapacity().equals(housingUnitDTO.getHousingUnitCapacity())
                    && housingApplicationDTO.getHousingUnitType().equals(housingUnitDTO.getHousingUnitType())) {

                return processAllocation(requestDTO, housingApplicationDTO, eligibilityCheckId, unitId);
            }
        }

        log.warn("Allocation failed: No units match criteria for project {}", requestDTO.getHousingProjectId());
        throw new NoUnitsAvailableException("No available units match the required capacity and type for this project.");
    }

    private AllocationResponseDTO processAllocation(AllocationRequestDTO requestDTO, HousingApplicationDTO app, Long eligibilityId, Long unitId) {
        try {
            Allocation allocation = new Allocation();
            allocation.setAllocationDate(LocalDate.now());
            allocation.setStatus(AllocationStatus.ALLOCATED);
            allocation.setCitizenId(requestDTO.getCitizenId());
            allocation.setEligibilityCheckId(eligibilityId);
            allocation.setHousingUnitId(unitId);
            allocation.setOfficerId(requestDTO.getOfficerId());
            allocation.setAllocationMessage(requestDTO.getAllocationMessage());

            allocationRepository.save(allocation);

            // 6. Remote State Update (Crucial Exception Point)


            System.out.println("project Id "+app.getHousingProjectId());
            housingUnitCleint.updateNoOfHouses(app.getHousingProjectId());
            log.info("Successfully allocated unit {} to citizen {}", unitId, requestDTO.getCitizenId());

            housingUnitCleint.updateHousingStatus("ALLOCATED", unitId);

            AllocationResponseDTO responseDTO = modelMapper.map(allocation, AllocationResponseDTO.class);
            responseDTO.setMessage("Successfully Allocated");
            responseDTO.setHousingProjectId(requestDTO.getHousingProjectId());
            responseDTO.setAllocationMessage(requestDTO.getAllocationMessage());

            return responseDTO;

        } catch (Exception e) {
            log.error("Internal error during allocation persistence: {}", e.getMessage());
            throw new AllocationProcessingException("An error occurred while saving the allocation record.");
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<AllocationResponseDTO> getAllAllocation() {
        List<Allocation> allocation = allocationRepository.findAll();
        if (allocation.isEmpty()) {
            throw new AllocationNotFoundException(EMPTY_DATA);
        }
        return allocation.stream()
                .map(unit -> {
                    AllocationResponseDTO dto = modelMapper.map(unit, AllocationResponseDTO.class);
                    dto.setMessage("Allocation details retrieved successfully");
                    return dto;
                })
                .toList();
    }

    @Override
    public long getTotalAllocations() {
        return allocationRepository.count();
    }

    @Override
    public long countByStatus(String statusString) {
        try {
            // Converts "ALLOCATED" -> AllocationStatus.ALLOCATED
            AllocationStatus status = AllocationStatus.valueOf(statusString.toUpperCase());
            return allocationRepository.countByStatus(status);
        } catch (IllegalArgumentException | NullPointerException e) {
            return 0;
        }
    }
}