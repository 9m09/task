package org.cts.housingaid.allocationservice.util;

public class ExceptionConstants {

    public static final String HOUSING_PROJECT_NOT_FOUND = "Housing Project not found with the given details.";
    public static final String HOUSING_UNIT_NOT_FOUND = "Housing Unit not found with the given details.";
    public static final String RESOURCE_NOT_FOUND = "Resource not found with the given details.";
    public static final String CITIZEN_NOT_FOUND = "Citizen not found with the given details.";
    public static final String CITIZEN_DOCUMENT_NOT_FOUND = "Citizen document not found.";
    public static final String HOUSING_APPLICATION_NOT_FOUND = "Housing application not found.";
    public static final String ALLOCATION_NOT_FOUND = "Allocation details not found.";
    public static final String AUDIT_NOT_FOUND = "Audit record not found.";
    public static final String AUDIT_LOG_NOT_FOUND = "Audit log not found.";
    public static final String COMPLIANCE_NOT_FOUND = "Compliance record not found.";
    public static final String ELIGIBILITY_NOT_FOUND = "Eligibility check record not found.";
    public static final String NOTIFICATION_NOT_FOUND = "Notification not found.";
    public static final String REPORT_NOT_FOUND = "Report not found.";
    public static final String USER_NOT_FOUND = "User not found.";
    public static final String EMPTY_DATA = "No data available in database.";
    public static final String VALIDATION_FAILED = "Validation failed.";
    public static final String INTERNAL_ERROR = "Something went wrong. Please try again.";
    public static final String USER_ALREADY_EXISTS = "User already exists with given email.";
    public static final String DOCUMENT_NOT_OWNED_BY_CITIZEN = "The document does not belong to the specified citizen.";
    public static final String DOCUMENT_NOT_DELETABLE = "Document cannot be deleted after verification.";
    public static final String CITIZEN_NOT_ELIGIBLE = "Citizen is not eligible for allocation.";
    public static final String PROJECT_MISMATCH = "Project does not match eligibility record.";
    public static final String UNIT_NOT_AVAILABLE = "No housing unit available.";
    public static final String EMPTY_PROJECT = "No data available in the database.";

    public static final String CITIZEN_ALLOCATED="House has been already allocated to citizen.";


    private ExceptionConstants() {
    }
}