package org.cts.housingaid.apigateway.constants;

public class SecurityConstants {
    public static final String AUTH_HEADER="Authorization";
}