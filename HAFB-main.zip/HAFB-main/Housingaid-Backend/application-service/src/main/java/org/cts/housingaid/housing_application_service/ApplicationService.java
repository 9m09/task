package org.cts.housingaid.housing_application_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication(scanBasePackages = "org.cts")
@EnableFeignClients
@EnableDiscoveryClient
public class ApplicationService {
    public static void main(String[] args) {
        SpringApplication.run(ApplicationService.class,args);
        System.out.println("Application Service Started");
    }
}
