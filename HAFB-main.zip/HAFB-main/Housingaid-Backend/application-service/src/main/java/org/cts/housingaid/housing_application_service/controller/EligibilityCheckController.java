package org.cts.housingaid.housing_application_service.controller;


import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.cts.housingaid.housing_application_service.dto.CitizenDocumentDTO;
import org.cts.housingaid.housing_application_service.dto.EligibilityCheckDTO;
import org.cts.housingaid.housing_application_service.service.EligibilityCheckService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@PreAuthorize("hasAnyRole('OFFICER','ADMIN')")
@RequestMapping("/application/eligibility-check")
@AllArgsConstructor
public class EligibilityCheckController {
    @Autowired
    private  EligibilityCheckService eligibilityCheckService;

    // Submit a new eligibility validation (Updates the Application Status automatically)
    @PostMapping("/submit")
    public ResponseEntity<String> createEligibilityCheck(@Valid @RequestBody EligibilityCheckDTO dto) {
        eligibilityCheckService.createEligibilityCheck(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body("Eligibility check recorded and application updated");
    }

    // View all checks performed
    @GetMapping("/history")
    public ResponseEntity<List<EligibilityCheckDTO>> getAllChecks() {
        List<EligibilityCheckDTO> list = eligibilityCheckService.getAllEligibilityChecks();
        return ResponseEntity.ok(list);
    }

    // Get specific check details
    @GetMapping("/{id}")
    public ResponseEntity<EligibilityCheckDTO> getCheckById(@PathVariable Long id) {
        EligibilityCheckDTO dto = eligibilityCheckService.getEligibilityCheckById(id);
        return ResponseEntity.ok(dto);
    }
    @GetMapping("/get-result")
    public Long getEligibilityCheckId(@RequestParam Long housingApplicationId,@RequestParam String status){
        return eligibilityCheckService.getEligibilityCheckId(housingApplicationId,status);
    }

    public ResponseEntity<String> updateDocumentStatus(@RequestBody CitizenDocumentDTO citizenDocumentDTO){
        eligibilityCheckService.updateDocumentStatus(citizenDocumentDTO);
        return ResponseEntity.ok("Status is Updated for the citizen "+citizenDocumentDTO.getCitizenDocumentId());
    }
}
