package org.cts.housingaid.housing_application_service.controller;



import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.cts.housingaid.housing_application_service.dto.HousingApplicationDTO;
import org.cts.housingaid.housing_application_service.dto.HousingApplicationRequestDTO;
import org.cts.housingaid.housing_application_service.enums.HousingApplicationStatus;
import org.cts.housingaid.housing_application_service.service.HousingApplicationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/application/housing-application")
@PreAuthorize("hasAnyRole('OFFICER','ADMIN','CITIZEN')")
@AllArgsConstructor
public class HousingApplicationController {

    private final HousingApplicationService housingApplicationService;

    // Create a new application
    @PreAuthorize("hasAnyRole('CITIZEN','ADMIN','OFFICER')")
    @PostMapping("/create")
    public ResponseEntity<String> createHousingApplication(@Valid @RequestBody HousingApplicationRequestDTO dto) {
        housingApplicationService.createHousingApplication(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body("Housing application submitted successfully");
    }

    // Get all applications (for admin/officer dashboard)
    @PreAuthorize("hasAnyRole('COMPLIANCE','CITIZEN','ADMIN','OFFICER','AUDITOR')")
    @GetMapping("/all")
    public ResponseEntity<List<HousingApplicationDTO>> getAllApplications() {
        List<HousingApplicationDTO> list = housingApplicationService.getAllHousingApplications();
        return ResponseEntity.ok(list);
    }
    @PreAuthorize("hasAnyRole('ADMIN','OFFICER')")
    @PutMapping("/update-status")
    public ResponseEntity<String> updateStatus(@RequestParam String housingApplicationStatus,@RequestParam Long housingApplicationId){
        housingApplicationService.updateStatus(housingApplicationStatus,housingApplicationId);
        return ResponseEntity.ok("Status has been updated");
    }
    // Search for a specific application by ID
    @PreAuthorize("hasAnyRole('ADMIN','OFFICER')")
    @GetMapping("/{id}")
    public ResponseEntity<HousingApplicationDTO> getApplicationById(@PathVariable Long id) {
        HousingApplicationDTO dto = housingApplicationService.getHousingApplicationById(id);
        return ResponseEntity.ok(dto);
    }

    // Filter applications by Status (PENDING, APPROVED, etc.)
    @PreAuthorize("hasAnyRole('ADMIN','OFFICER')")
    @GetMapping("/status/{status}")
    public ResponseEntity<List<HousingApplicationDTO>> getApplicationsByStatus(@PathVariable HousingApplicationStatus status) {
        List<HousingApplicationDTO> list = housingApplicationService.getHousingApplicationsByStatus(status);
        return ResponseEntity.ok(list);
    }

    @PreAuthorize("hasAnyRole('ADMIN','OFFICER')")
    @GetMapping("/applicationId")
    public Long getHosuingApplication(@RequestParam Long citizenId,@RequestParam String status){
        System.out.println("inside controller");
        return housingApplicationService.getHousingApplication(citizenId,status);
    }

    @PreAuthorize("hasAnyRole('AUDITOR','ADMIN','OFFICER')")
    @GetMapping("/get-total-count")
    public long getTotalCount() {
        return housingApplicationService.getTotalCount();
    }

    @PreAuthorize("hasAnyRole('AUDITOR','ADMIN','OFFICER')")
    @GetMapping("/count/status/{status}")
    public long getCountByStatus(@PathVariable String status) {
        return housingApplicationService.countByStatus(status);
    }

    @PreAuthorize("hasAnyRole('AUDITOR','ADMIN','OFFICER')")
    @GetMapping("/Id")
    public HousingApplicationDTO getHousingApplicationDTOById(@RequestParam Long housingApplicationId){
        return housingApplicationService.getHousingApplicationById(housingApplicationId);
    }

}