package org.cts.housingaid.housing_application_service.dao;


import org.cts.housingaid.housing_application_service.entity.EligibilityCheck;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EligibilityCheckRepository extends JpaRepository<EligibilityCheck, Long> {

    /**
     * Finds all eligibility checks related to a specific application.
     */
    List<EligibilityCheck> findByHousingApplicationHousingApplicationId(Long applicationId);

    /**
     * Finds checks performed by a specific officer.
     */
    List<EligibilityCheck> findByOfficerId(Long officerId);

    // FIXED VERSION
    @Query("select ec.eligibilityCheckResult from EligibilityCheck ec where ec.housingApplication.housingApplicationId = :id")
    String findByHousingApplicationIdStatus(@Param("id") Long id);
}