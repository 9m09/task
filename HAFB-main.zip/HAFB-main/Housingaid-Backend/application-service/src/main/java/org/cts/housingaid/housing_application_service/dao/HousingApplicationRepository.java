package org.cts.housingaid.housing_application_service.dao;

import org.cts.housingaid.housing_application_service.entity.HousingApplication;
import org.cts.housingaid.housing_application_service.enums.HousingApplicationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HousingApplicationRepository extends JpaRepository<HousingApplication, Long> {

    /**
     * Spring Data JPA automatically generates the SQL for this based on the method name.
     * SQL: SELECT * FROM housing_applications WHERE housing_application_status = ?
     */
    List<HousingApplication> findByHousingApplicationStatus(HousingApplicationStatus status);

    /**
     * Finds applications by Citizen ID (useful for the Citizen's personal dashboard).
     */
    List<HousingApplication> findByCitizenId(Long citizenId);
    @Query("select ha.housingApplicationId from HousingApplication ha where ha.citizenId = :citizenId")
    List<Long> findApplicationIdsByCitizenId(@Param("citizenId") Long citizenId);
    @Query("select ha.housingApplicationStatus from HousingApplication ha where ha.housingApplicationId = :housingApplicationId")
    String findStatus(@Param("housingApplicationId")Long housingApplicationId);

    long countByHousingApplicationStatus(HousingApplicationStatus status);
}

