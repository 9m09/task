package org.cts.housingaid.housing_application_service.dto;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cts.housingaid.housing_application_service.enums.CitizenGender;
import org.cts.housingaid.housing_application_service.enums.CitizenStatus;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CitizenDTO {

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long citizenId;

    @NotNull(message="DOB required")
    @JsonFormat(pattern="yyyy-MM-dd")
    private LocalDate citizenDOB;

    @NotBlank(message = "citizen name should not be null")
    private String citizenName;

    @NotNull(message="Gender required")
    private CitizenGender citizenGender;

    @NotBlank(message="Address required")
    @Size(min=10,max=200)
    private String citizenAddress;

    @NotBlank(message="Contact info required")
    private String citizenContactInfo;

    @NotNull(message="User ID required")
    private Long userId;

    private CitizenStatus citizenStatus;

}