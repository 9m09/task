package org.cts.housingaid.housing_application_service.dto;



import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cts.housingaid.housing_application_service.enums.CitizenDocumentDocType;
import org.cts.housingaid.housing_application_service.enums.CitizenDocumentVerificationStatus;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CitizenDocumentDTO {

    private Long citizenDocumentId;

    private CitizenDocumentDocType citizenDocumentDocType;

    private String citizenDocumentFileUri;

    private LocalDateTime citizenDocumentUploadedDate;


    private CitizenDocumentVerificationStatus citizenDocumentVerificationStatus;


}
