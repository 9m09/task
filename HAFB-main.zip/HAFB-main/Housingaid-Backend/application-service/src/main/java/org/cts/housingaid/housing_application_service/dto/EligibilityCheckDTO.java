package org.cts.housingaid.housing_application_service.dto;


import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cts.housingaid.housing_application_service.enums.EligibilityCheckResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EligibilityCheckDTO {

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long eligibilityCheckId;

    @NotNull(message = "Application ID is required")
    private Long housingApplicationId;

    @NotNull(message = "Officer ID is required")
    private Long officerId;

    @NotNull(message = "Document ID is required")
    private Long citizenDocumentId;

    private EligibilityCheckResult eligibilityCheckResult;
    private LocalDate eligibilityCheckDate;
    private String eligibilityCheckNotes;
}
