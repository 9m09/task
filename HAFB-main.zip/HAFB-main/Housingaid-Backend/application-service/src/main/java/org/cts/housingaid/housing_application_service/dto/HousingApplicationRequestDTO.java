package org.cts.housingaid.housing_application_service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.cts.housingaid.housing_application_service.enums.HousingUnitType;

@Data
@AllArgsConstructor
public class HousingApplicationRequestDTO {

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long housingApplicationId;

    @NotNull(message = "Project ID is required")
    private Long housingProjectId;

    @NotNull(message = "housing unit should not be blank")
    private HousingUnitType housingUnitType;

    @NotNull(message = "housing capacity should not be null")
    private Long housingCapacity;

    @NotNull(message = "Citizen ID is required")
    private Long citizenId;

}
