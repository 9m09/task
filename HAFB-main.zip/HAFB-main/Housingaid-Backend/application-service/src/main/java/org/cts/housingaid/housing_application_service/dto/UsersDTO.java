package org.cts.housingaid.housing_application_service.dto;



import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cts.housingaid.housing_application_service.enums.UserRole;
import org.cts.housingaid.housing_application_service.enums.UserStatus;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UsersDTO {

    private Long userId;


    private String userName;

    private String userEmail;


    private String userPhone;

    private UserRole userRole;

    private UserStatus userStatus;

}