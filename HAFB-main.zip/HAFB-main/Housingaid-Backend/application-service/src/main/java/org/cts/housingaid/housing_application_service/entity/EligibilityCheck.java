package org.cts.housingaid.housing_application_service.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cts.housingaid.housing_application_service.enums.EligibilityCheckResult;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EligibilityCheck {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eligibilityCheckId;

    @Enumerated(EnumType.STRING)
    private EligibilityCheckResult eligibilityCheckResult;

    private LocalDate eligibilityCheckDate = LocalDate.now();
    private String eligibilityCheckNotes;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "housingApplicationId", nullable = false)
    private HousingApplication housingApplication;

    // Microservice replacements:
    private Long officerId;        // Replaced Users entity
    private Long citizenDocumentId; // Replaced CitizenDocument entity
}
