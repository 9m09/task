package org.cts.housingaid.housing_application_service.enums;

public enum CitizenDocumentVerificationStatus {
    PENDING,VERIFIED,REJECTED

}
