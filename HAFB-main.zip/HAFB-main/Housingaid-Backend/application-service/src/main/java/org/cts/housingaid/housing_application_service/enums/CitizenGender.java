package org.cts.housingaid.housing_application_service.enums;

public enum CitizenGender {
    MALE,FEMALE,OTHER
}
