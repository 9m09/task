package org.cts.housingaid.housing_application_service.enums;

public enum CitizenStatus {
    ACTIVE,INACTIVE,SUSPENDED,PENDING
}
