package org.cts.housingaid.housing_application_service.enums;

public enum UserRole {
    CITIZEN,OFFICER,MANAGER,ADMIN,COMPLIANCE,AUDITOR
}
