package org.cts.housingaid.housing_application_service.enums;

public enum UserStatus {
    ACTIVE ,INACTIVE,PENDING,SUSPENDED
}
