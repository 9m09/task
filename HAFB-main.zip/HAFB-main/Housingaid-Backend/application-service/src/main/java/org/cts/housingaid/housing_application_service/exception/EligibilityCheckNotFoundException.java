package org.cts.housingaid.housing_application_service.exception;

public class EligibilityCheckNotFoundException extends RuntimeException {

    public EligibilityCheckNotFoundException(String message) {

        super(message);

    }
}