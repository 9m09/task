package org.cts.housingaid.housing_application_service.exception;

public class HousingApplicationNotFoundException extends RuntimeException {

    public HousingApplicationNotFoundException(String message) {

        super(message);

    }

}
