package org.cts.housingaid.housing_application_service.openfeign;

import org.cts.housingaid.housing_application_service.dto.CitizenDTO;
import org.cts.housingaid.housing_application_service.dto.CitizenDocumentDTO;
import org.cts.housingaid.housing_application_service.dto.UsersDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "auth-service",configuration = FeignClientInterceptor.class)
public interface AuthClient {

    @GetMapping("/auths/admin/search-user/{id}")
    UsersDTO getUserById(@PathVariable("id") Long id);

    @GetMapping("/auths/citizen/search-citizen/{id}")
    CitizenDTO getCitizenById(@PathVariable("id") Long id);

    @GetMapping("/auths/citizen/{citizenId}/documents/get-all-documents")
    List<CitizenDocumentDTO> getCitizenDocumentById(@PathVariable("citizenId") Long citizenId);

    @PatchMapping("/auths/citizen/{citizenId}/documents/update-document-staus")
    void updateDocStatus(@PathVariable("citizenId") Long citizenId);

    @GetMapping("/auths/document/get-citizenId/{citizenDocumentId}")
    Long getCitizenId(@PathVariable("citizenDocumentId") Long citizenDocumentId);
}