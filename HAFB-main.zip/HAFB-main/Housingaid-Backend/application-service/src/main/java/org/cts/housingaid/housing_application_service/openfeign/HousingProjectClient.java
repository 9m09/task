package org.cts.housingaid.housing_application_service.openfeign;

import org.cts.housingaid.housing_application_service.dto.HousingProjectDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name ="inventory-service",configuration = FeignClientInterceptor.class)
public interface HousingProjectClient {

    @GetMapping("/inventory/housing-project/get-housing-project/{housingProjectId}")
    HousingProjectDTO getHousingProject(@RequestParam Long housingProjectId);

    @GetMapping("inventory/housing-project/get-all-housing-projects")
    public ResponseEntity<List<HousingProjectDTO>> getAllHousingProjects();
}
