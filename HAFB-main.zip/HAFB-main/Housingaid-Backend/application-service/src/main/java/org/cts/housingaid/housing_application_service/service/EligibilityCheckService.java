package org.cts.housingaid.housing_application_service.service;



import org.cts.housingaid.housing_application_service.dto.CitizenDocumentDTO;
import org.cts.housingaid.housing_application_service.dto.EligibilityCheckDTO;
import org.springframework.stereotype.Service;

import java.util.List;

public interface EligibilityCheckService {
    void createEligibilityCheck(EligibilityCheckDTO dto);
    EligibilityCheckDTO getEligibilityCheckById(Long id);
    List<EligibilityCheckDTO> getAllEligibilityChecks();

    Long getEligibilityCheckId(Long housingApplicationId, String status);
    void updateDocumentStatus(CitizenDocumentDTO citizenDocumentDTO);
}