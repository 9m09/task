package org.cts.housingaid.housing_application_service.service;



import org.cts.housingaid.housing_application_service.dto.HousingApplicationDTO;
import org.cts.housingaid.housing_application_service.dto.HousingApplicationRequestDTO;
import org.cts.housingaid.housing_application_service.enums.HousingApplicationStatus;
import org.springframework.stereotype.Service;

import java.util.List;


public interface HousingApplicationService {
    void createHousingApplication(HousingApplicationRequestDTO dto);
    HousingApplicationDTO getHousingApplicationById(Long id);
    List<HousingApplicationDTO> getHousingApplicationsByStatus(HousingApplicationStatus status);
    List<HousingApplicationDTO> getAllHousingApplications();

    Long getHousingApplication(Long citizenId, String status);

    long getTotalCount();

    long countByStatus(String status);

    void updateStatus(String housingApplicationStatus, Long housingApplicationId);
}
