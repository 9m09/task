package org.cts.housingaid.housing_application_service.serviceimpl;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.cts.housingaid.housing_application_service.dao.EligibilityCheckRepository;
import org.cts.housingaid.housing_application_service.dao.HousingApplicationRepository;
import org.cts.housingaid.housing_application_service.dto.CitizenDocumentDTO;
import org.cts.housingaid.housing_application_service.dto.EligibilityCheckDTO;
import org.cts.housingaid.housing_application_service.dto.UsersDTO;
import org.cts.housingaid.housing_application_service.entity.EligibilityCheck;
import org.cts.housingaid.housing_application_service.entity.HousingApplication;
import org.cts.housingaid.housing_application_service.enums.CitizenDocumentVerificationStatus;
import org.cts.housingaid.housing_application_service.enums.EligibilityCheckResult;
import org.cts.housingaid.housing_application_service.enums.HousingApplicationStatus;
import org.cts.housingaid.housing_application_service.enums.UserRole;
import org.cts.housingaid.housing_application_service.exception.EligibilityCheckNotFoundException;
import org.cts.housingaid.housing_application_service.openfeign.AuthClient;
import org.cts.housingaid.housing_application_service.service.EligibilityCheckService;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class EligibilityCheckServiceImpl implements EligibilityCheckService {
    private final EligibilityCheckRepository checkRepo;
    private final HousingApplicationRepository appRepo;
    private final AuthClient authClient;

    @Override
    @Transactional
    public void createEligibilityCheck(EligibilityCheckDTO dto) {
        // Find the housing application
        HousingApplication app = appRepo.findById(dto.getHousingApplicationId())
                .orElseThrow(() -> new RuntimeException("Cannot check eligibility: Application not found."));

        // Validate officer
        UsersDTO officer = authClient.getUserById(dto.getOfficerId());
        if (officer.getUserRole() != UserRole.OFFICER) {
            throw new RuntimeException("User is not an officer");
        }
        // Fetch citizen document
        List<CitizenDocumentDTO> document = authClient.getCitizenDocumentById(authClient.getCitizenId(dto.getCitizenDocumentId()));


        for(CitizenDocumentDTO doc:document){
            if(doc.getCitizenDocumentVerificationStatus()== CitizenDocumentVerificationStatus.VERIFIED){
                EligibilityCheck check = new EligibilityCheck();
                check.setHousingApplication(app);
                check.setOfficerId(officer.getUserId());
                check.setCitizenDocumentId(doc.getCitizenDocumentId());
                check.setEligibilityCheckDate(dto.getEligibilityCheckDate());
                check.setEligibilityCheckNotes(dto.getEligibilityCheckNotes());
                check.setEligibilityCheckResult(dto.getEligibilityCheckResult());

                checkRepo.save(check);
                break;
            }
        }
        // Create eligibility check record


        // Update application status based on eligibility result
        app.setHousingApplicationStatus(
                dto.getEligibilityCheckResult() == EligibilityCheckResult.ELIGIBLE
                        ? HousingApplicationStatus.APPROVED
                        : HousingApplicationStatus.REJECTED
        );
        appRepo.save(app);
    }

    @Override
    public EligibilityCheckDTO getEligibilityCheckById(Long id) {
        EligibilityCheck check = checkRepo.findById(id)
                .orElseThrow(() -> new EligibilityCheckNotFoundException("Check record not found."));
        return convertToDTO(check);
    }

    @Override
    public List<EligibilityCheckDTO> getAllEligibilityChecks() {
        return checkRepo.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    private EligibilityCheckDTO convertToDTO(EligibilityCheck check) {
        EligibilityCheckDTO dto = new EligibilityCheckDTO();
        dto.setEligibilityCheckId(check.getEligibilityCheckId());
        dto.setHousingApplicationId(check.getHousingApplication().getHousingApplicationId());
        dto.setOfficerId(check.getOfficerId());
        dto.setCitizenDocumentId(check.getCitizenDocumentId());
        dto.setEligibilityCheckDate(check.getEligibilityCheckDate());
        dto.setEligibilityCheckNotes(check.getEligibilityCheckNotes());
        dto.setEligibilityCheckResult(check.getEligibilityCheckResult());
        return dto;
    }



    public Long getEligibilityCheckId(Long housingApplicationId, String status) {
        String dbStatus = checkRepo.findByHousingApplicationIdStatus(housingApplicationId);

        if (Objects.equals(dbStatus, status)) {
            return housingApplicationId;
        }

        return null;
    }

    @Override
    public void updateDocumentStatus(CitizenDocumentDTO citizenDocumentDTO) {
        authClient.updateDocStatus(citizenDocumentDTO.getCitizenDocumentId());
    }
}

