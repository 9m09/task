package org.cts.housingaid.housing_application_service.serviceimpl;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.cts.housingaid.housing_application_service.dao.HousingApplicationRepository;
import org.cts.housingaid.housing_application_service.dto.*;
import org.cts.housingaid.housing_application_service.entity.HousingApplication;
import org.cts.housingaid.housing_application_service.enums.HousingApplicationStatus;
import org.cts.housingaid.housing_application_service.exception.HousingApplicationNotFoundException;
import org.cts.housingaid.housing_application_service.openfeign.AuthClient;
import org.cts.housingaid.housing_application_service.openfeign.HousingProjectClient;
import org.cts.housingaid.housing_application_service.service.HousingApplicationService;
import org.springframework.stereotype.Service;
import org.modelmapper.ModelMapper;

import java.util.List;
import java.util.stream.Collectors;

import static java.lang.Long.valueOf;

@Slf4j
@Service
@AllArgsConstructor
public class HousingApplicationServiceImpl implements HousingApplicationService {
    private final HousingApplicationRepository repository;
    private final HousingProjectClient projectClient;
    private final AuthClient authClient;
    private final ModelMapper modelMapper;

    @Override
    public void createHousingApplication(HousingApplicationRequestDTO dto) {
        // Fetch data from Feign clients
        CitizenDTO citizen = authClient.getCitizenById(dto.getCitizenId());
        HousingProjectDTO project = projectClient.getHousingProject(dto.getHousingProjectId());
//        UsersDTO user = authClient.getUserById(dto.getCitizenId()); // link citizen to user

        HousingApplication entity = new HousingApplication();
        entity.setCitizenId(dto.getCitizenId());
        entity.setHousingProjectId(dto.getHousingProjectId());
        entity.setHousingApplicantName(citizen.getCitizenName());
        entity.setHousingSchemeName(project.getHousingProjectTitle());

        entity.setHousingUnitType(dto.getHousingUnitType());
        entity.setHousingCapacity(dto.getHousingCapacity());


        repository.save(entity);
    }

    @Override
    public HousingApplicationDTO getHousingApplicationById(Long id) {
        HousingApplication app = repository.findById(id)
                .orElseThrow(() -> new HousingApplicationNotFoundException("Application ID " + id + " not found."));
        return convertToDTO(app);
    }

    @Override
    public List<HousingApplicationDTO> getHousingApplicationsByStatus(HousingApplicationStatus status) {
        return repository.findByHousingApplicationStatus(status).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<HousingApplicationDTO> getAllHousingApplications() {
        return repository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    private HousingApplicationDTO convertToDTO(HousingApplication app) {
        HousingApplicationDTO dto = new HousingApplicationDTO();
        dto.setHousingApplicationId(app.getHousingApplicationId());
        dto.setCitizenId(app.getCitizenId());
        dto.setHousingProjectId(app.getHousingProjectId());
        dto.setHousingApplicationSubmittedDate(app.getHousingApplicationSubmittedDate());
        dto.setHousingApplicationStatus(app.getHousingApplicationStatus());
        dto.setHousingUnitType(app.getHousingUnitType());
        dto.setHousingCapacity(app.getHousingCapacity());
        
        // Populate applicant name from citizen if not set
        if (app.getHousingApplicantName() != null && !app.getHousingApplicantName().isEmpty()) {
            dto.setHousingApplicantName(app.getHousingApplicantName());
        } else {
            try {
                CitizenDTO citizen = authClient.getCitizenById(app.getCitizenId());
                dto.setHousingApplicantName(citizen.getCitizenName());
            } catch (Exception e) {
                log.warn("Failed to fetch citizen name for ID: {}", app.getCitizenId());
                dto.setHousingApplicantName("Citizen #" + app.getCitizenId());
            }
        }
        
        // Populate scheme name from project if not set
        if (app.getHousingSchemeName() != null && !app.getHousingSchemeName().isEmpty()) {
            dto.setHousingSchemeName(app.getHousingSchemeName());
        } else {
            try {
                HousingProjectDTO project = projectClient.getHousingProject(app.getHousingProjectId());
                dto.setHousingSchemeName(project.getHousingProjectTitle());
            } catch (Exception e) {
                log.warn("Failed to fetch project name for ID: {}", app.getHousingProjectId());
                dto.setHousingSchemeName("Project #" + app.getHousingProjectId());
            }
        }
        
        return dto;
    }
    public Long getHousingApplication(Long citizenId, String status) {
        log.info("Checking housing application status for Citizen ID: {} with expected status: {}", citizenId, status);

        // 1. Get all application IDs for the citizen
        List<Long> applicationIds = repository.findApplicationIdsByCitizenId(citizenId);

        // Handle case where citizen has no applications at all
        if (applicationIds == null || applicationIds.isEmpty()) {
            log.warn("No applications found in database for citizen ID: {}", citizenId);
            return null; // Returning null is better than 0 for Feign clients to detect "Not Found"
        }

        // 2. Iterate and find the one that matches the status
        for (Long id : applicationIds) {
            String currentStatus = repository.findStatus(id);

            if (status.equalsIgnoreCase(currentStatus)) {
                log.info("Found matching application. ID: {}, Status: {}", id, currentStatus);
                return id;
            }
        }

        // 3. If loop finishes without a match
        log.warn("Citizen {} has applications, but none are in '{}' status", citizenId, status);
        return null;
    }
    @Override
    public long getTotalCount() {
        return repository.count();
    }

    @Override
    public long countByStatus(String statusString) {
        try {
            // Converts "APPROVED" -> HousingApplicationStatus.APPROVED
            HousingApplicationStatus status = HousingApplicationStatus.valueOf(statusString.toUpperCase());
            return repository.countByHousingApplicationStatus(status);
        } catch (IllegalArgumentException | NullPointerException e) {
            return 0; // Return 0 if the status string is invalid
        }
    }

    @Override
    public void updateStatus(String housingApplicationStatus, Long housingApplicationId) {
        HousingApplication housingApplication=repository.findById(housingApplicationId).get();
        housingApplication.setHousingApplicationStatus(HousingApplicationStatus.valueOf(housingApplicationStatus));

    }
}

