package org.cts.housingaid.housing_application_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HousingApplicationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
