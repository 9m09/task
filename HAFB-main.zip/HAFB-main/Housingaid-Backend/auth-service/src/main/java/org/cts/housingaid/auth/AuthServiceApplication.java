package org.cts.housingaid.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;


@SpringBootApplication(scanBasePackages = "org.cts")
@EnableDiscoveryClient
public class AuthServiceApplication {

	public static void main(String[] args) {
		// Launches the specific Identity & Citizen microservice context
		SpringApplication.run(AuthServiceApplication.class, args);

		// Updated log message to reflect the specific service name
		System.out.println("Auth Service Started");
	}

}