package org.cts.housingaid.auth.config;

import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.cts.housingaid.auth.entity.AuditLog;
import org.cts.housingaid.auth.dto.AuditLogDTO;

@Configuration
public class AppConfig {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();
        
        // Custom mapping for AuditLog -> AuditLogDTO
        modelMapper.addMappings(new PropertyMap<AuditLog, AuditLogDTO>() {
            @Override
            protected void configure() {
                map().setUserId(source.getUsers().getUserId());
            }
        });
        
        return modelMapper;
    }
}
