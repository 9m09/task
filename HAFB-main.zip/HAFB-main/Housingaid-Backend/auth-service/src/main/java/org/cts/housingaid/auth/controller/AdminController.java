package org.cts.housingaid.auth.controller;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
//import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.cts.housingaid.auth.dto.UsersCreateDTO;
import org.cts.housingaid.auth.dto.UsersProfileDTO;
import org.cts.housingaid.auth.enums.UserStatus;
import org.cts.housingaid.auth.service.UsersService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

import java.util.List;

@RestController
@PreAuthorize("hasRole('ADMIN')")
@RequestMapping("/auths/admin")
@AllArgsConstructor
public class AdminController {

    private final UsersService usersService;

    @GetMapping("/get-all-users")
    public ResponseEntity<List<UsersCreateDTO>> getAllUsers(){
        List<UsersCreateDTO> list = usersService.getAllUsers();
        return ResponseEntity.status(HttpStatus.OK).body(list);
    }

    @PostMapping("/create-user")
    public ResponseEntity<String> createUser(@Valid @RequestBody UsersCreateDTO usersCreateDTO){
        usersService.createUser(usersCreateDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body("User registered successfully");
    }

    @PutMapping("/update-user/{id}")
    public ResponseEntity<String> updateUser(@PathVariable Long id, @Valid @RequestBody UsersCreateDTO usersCreateDTO){
        usersCreateDTO.setUserId(id);
        usersService.updateUser(usersCreateDTO);
        return ResponseEntity.status(HttpStatus.OK).body("User updated successfully");
    }

    @DeleteMapping("/delete-user/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long id){
        usersService.deleteUser(id);
        return ResponseEntity.status(HttpStatus.OK).body("User deleted successfully");
    }

    @PreAuthorize("hasAnyRole('ADMIN','OFFICER')")
    @GetMapping("/search-user/{id}")
    public ResponseEntity<UsersCreateDTO> searchUserById(@PathVariable Long id){
        UsersCreateDTO user = usersService.getUserById(id);
        return ResponseEntity.status(HttpStatus.OK).body(user);
    }

    @PutMapping("/update-user-status/{id}")
    public ResponseEntity<String> updateUserStatus(@PathVariable Long id, @RequestParam UserStatus userStatus){
        usersService.updateUserStatus(id, userStatus);
        return ResponseEntity.status(HttpStatus.OK).body("User status updated successfully");
    }

}