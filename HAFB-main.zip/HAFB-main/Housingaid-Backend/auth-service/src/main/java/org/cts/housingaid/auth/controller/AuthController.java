package org.cts.housingaid.auth.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.cts.housingaid.auth.dto.*;
import org.cts.housingaid.auth.enums.AuditLogAction;
import org.cts.housingaid.auth.service.AuditLogService;
import org.cts.housingaid.auth.service.AuthService;
import org.cts.housingaid.auth.service.RegistrationService;
import org.cts.housingaid.auth.service.UsersService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auths/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final UsersService usersService;
    private final RegistrationService registrationService;
    private final AuditLogService auditLogService;

    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest request){

        String token = authService.login(
                request.getEmail(),
                request.getPassword()
        );
        AuditLogDTO dto=new AuditLogDTO();
        dto.setUserId(usersService.getUserId(request.getEmail()));
        dto.setAuditLogAction(AuditLogAction.LOGIN);
        dto.setAuditLogResource("/auths/auth/login");
        auditLogService.createAuditLog(dto);
        return new LoginResponse(token);
    }
    @PostMapping("/register-citizen")
    public ResponseEntity<CitizenRegistrationDTO> registerCitizen(@Valid @RequestBody CitizenRegistrationDTO dto){
        CitizenRegistrationDTO result = registrationService.registerCitizen(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(result);
    }
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/register")
    public ResponseEntity<String> createUser(@Valid @RequestBody UsersCreateDTO usersCreateDTO){
        usersService.createUser(usersCreateDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body("User registered successfully");
    }
}
