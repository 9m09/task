package org.cts.housingaid.auth.controller;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.cts.housingaid.auth.dao.UsersRepository;
import org.cts.housingaid.auth.dto.CitizenDTO;
import org.cts.housingaid.auth.dto.CitizenRegistrationDTO;
import org.cts.housingaid.auth.entity.Citizen;
import org.cts.housingaid.auth.entity.Users;
import org.cts.housingaid.auth.enums.CitizenStatus;
import org.cts.housingaid.auth.exception.CitizenNotFoundException;
import org.cts.housingaid.auth.service.CitizenService;
import org.cts.housingaid.auth.service.RegistrationService;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/auths/citizen")
@AllArgsConstructor
public class CitizenController {

    private final CitizenService citizenService;
    private final UsersRepository usersRepository;
    private final ModelMapper modelMapper;

    @PreAuthorize("hasAnyRole('ADMIN','CITIZEN','OFFICER')")
    @GetMapping("/get-all-citizens")
    public ResponseEntity<List<CitizenDTO>> getAllCitizens(){
        List<CitizenDTO> list = citizenService.getAllCitizens();
        return ResponseEntity.status(HttpStatus.OK).body(list);
    }

    @PreAuthorize("hasRole('CITIZEN')")
    @GetMapping("/me")
    public ResponseEntity<CitizenDTO> getCurrentCitizen() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        Optional<Users> optionalUser = usersRepository.findByUserEmail(email);
        if (optionalUser.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        Users user = optionalUser.get();
        try {
            CitizenDTO citizen = citizenService.getCitizenByUserId(user.getUserId());
            return ResponseEntity.status(HttpStatus.OK).body(citizen);
        } catch (CitizenNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    @PreAuthorize("hasRole('CITIZEN')")
    @PostMapping("/complete-profile")
    public ResponseEntity<CitizenDTO> completeProfile(@Valid @RequestBody CitizenRegistrationDTO dto) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        Optional<Users> optionalUser = usersRepository.findByUserEmail(email);
        if (optionalUser.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        Users user = optionalUser.get();
        try {
            CitizenDTO existing = citizenService.getCitizenByUserId(user.getUserId());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(existing);
        } catch (CitizenNotFoundException ignored) {
            // Create citizen profile because it does not exist yet
        }
        Citizen citizen = new Citizen();
        citizen.setUser(user);
        citizen.setCitizenDOB(dto.getCitizenDOB());
        citizen.setCitizenName(dto.getUserName());
        citizen.setCitizenGender(dto.getCitizenGender());
        citizen.setCitizenAddress(dto.getCitizenAddress());
        citizen.setCitizenContactInfo(dto.getCitizenContactInfo());
        citizen.setCitizenStatus(CitizenStatus.PENDING);
        Citizen saved = citizenService.saveCitizen(citizen);
        CitizenDTO result = modelMapper.map(saved, CitizenDTO.class);
        result.setUserId(saved.getUser().getUserId());
        return ResponseEntity.status(HttpStatus.CREATED).body(result);
    }

    @PreAuthorize("hasAnyRole('ADMIN','OFFICER','CITIZEN')")
    @GetMapping("/search-citizen/{id}")
    public ResponseEntity<CitizenDTO> getCitizenById(@PathVariable Long id){
        CitizenDTO citizen = citizenService.getCitizenById(id);
        return ResponseEntity.status(HttpStatus.OK).body(citizen);
    }

    @PutMapping("/update-citizen/{id}")
    public ResponseEntity<String> updateCitizen(@PathVariable Long id, @Valid @RequestBody CitizenDTO citizenDTO){
        citizenDTO.setCitizenId(id);
        citizenService.updateCitizen(citizenDTO);
        return ResponseEntity.status(HttpStatus.OK).body("Citizen updated successfully");
    }


}