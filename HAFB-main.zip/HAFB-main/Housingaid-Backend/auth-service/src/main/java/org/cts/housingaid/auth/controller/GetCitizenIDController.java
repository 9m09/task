package org.cts.housingaid.auth.controller;

import lombok.RequiredArgsConstructor;
import org.cts.housingaid.auth.service.CitizenDocumentService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@PreAuthorize("hasAnyRole('ADMIN','OFFICER')")
@RequiredArgsConstructor
@RequestMapping("/auths/document")
public class GetCitizenIDController {
    private final CitizenDocumentService citizenDocumentService;

    @GetMapping("/get-citizenId/{citizenDocumentId}")
    public Long getCitizenID(@PathVariable Long citizenDocumentId){
        return citizenDocumentService.getCitizenId(citizenDocumentId);
    }
}
