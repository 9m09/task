package org.cts.housingaid.auth.controller;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.cts.housingaid.auth.dto.UsersCreateDTO;
import org.cts.housingaid.auth.dto.UsersProfileDTO;
import org.cts.housingaid.auth.service.UsersService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auths/users")
@AllArgsConstructor
public class UsersController {

    private final UsersService usersService;

    @GetMapping("/profile")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<UsersProfileDTO> getProfile(Authentication authentication){
        String email = authentication.getName();
        UsersProfileDTO user = usersService.getUserByEmail(email);
        return ResponseEntity.status(HttpStatus.OK).body(user);
    }

    @PutMapping("/update")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<String> updateUser(){
        return ResponseEntity.status(HttpStatus.OK).body("User updated successfully");
    }

}
