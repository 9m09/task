package org.cts.housingaid.auth.dao;

import org.cts.housingaid.auth.entity.CitizenDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CitizenDocumentRepository extends JpaRepository<CitizenDocument, Long> {

    List<CitizenDocument> findAllByCitizenCitizenId(Long citizenId);
}