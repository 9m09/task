package org.cts.housingaid.auth.dao;

import org.cts.housingaid.auth.entity.Users;
import org.cts.housingaid.auth.enums.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UsersRepository extends JpaRepository<Users, Long> {


    Optional<Users> findByUserEmail(String userEmail);


    Optional<Users> findByUserName(String userName);

    Optional<Users> findByUserRole(UserRole userRole);

    @Query("select u.userId from Users u where u.userEmail = :email")
    Long getUserID(@Param("email") String email);
}
