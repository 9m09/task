package org.cts.housingaid.auth.dto;

public class UsersProfileDTO {
    private Long userPassword;
    private String userName;
    private String userEmail;
    private String userPhone;
}
