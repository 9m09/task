package org.cts.housingaid.auth.dto;

public class UsersUpdateDTO {
    private String userName;
    private String userPassword;
    private String userEmail;
    private String userPhone;
}



