package org.cts.housingaid.auth.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.cts.housingaid.auth.enums.AuditLogAction;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ToString.Exclude
    @Column(name = "auditLogId")
    private Long auditLogId;

    @ToString.Exclude
    @ManyToOne
    @JoinColumn(name = "userId", nullable = false)
    private Users users;

    @Enumerated(EnumType.STRING)
    private AuditLogAction auditLogAction;

    private String auditLogResource;
}