package org.cts.housingaid.auth.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.cts.housingaid.auth.enums.CitizenGender;
import org.cts.housingaid.auth.enums.CitizenStatus;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Citizen {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long citizenId;
    private String citizenName;
    private LocalDate citizenDOB;
    @Enumerated(EnumType.STRING)
    private CitizenGender citizenGender;
    private String citizenAddress;
    private String citizenContactInfo;
    @Enumerated(EnumType.STRING)
    private CitizenStatus citizenStatus;
    @ToString.Exclude
    @OneToOne
    @JoinColumn(name = "userId")
    private Users user;
    @ToString.Exclude
    @OneToMany(mappedBy = "citizen", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<CitizenDocument> documents;

}