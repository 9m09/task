package org.cts.housingaid.auth.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.cts.housingaid.auth.enums.CitizenDocumentDocType;
import org.cts.housingaid.auth.enums.CitizenDocumentVerificationStatus;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class CitizenDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long citizenDocumentId;

    @Enumerated(EnumType.STRING)
    private CitizenDocumentDocType citizenDocumentDocType;

    private String citizenDocumentFileUri;

    private LocalDateTime citizenDocumentUploadedDate;

    @Enumerated(EnumType.STRING)
    private CitizenDocumentVerificationStatus citizenDocumentVerificationStatus;

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "citizenId", nullable = false)
    private Citizen citizen;

//    private Long eligibilityCheckId;

}