package org.cts.housingaid.auth.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.cts.housingaid.auth.enums.UserRole;
import org.cts.housingaid.auth.enums.UserStatus;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Users {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    private String userPassword;

    private String userName;

    @Enumerated(EnumType.STRING)
    private UserRole userRole;

    @Column(name = "userEmail", nullable = false, unique = true) // Forced match
    private String userEmail;

    private String userPhone;

    @Enumerated(EnumType.STRING)
    private UserStatus userStatus = UserStatus.ACTIVE;


}