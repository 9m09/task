package org.cts.housingaid.auth.enums;

public enum AuditLogAction {
    LOGIN,
    LOGOUT,
    CREATE,
    UPDATE,
    DELETE,
    VERIFY,
    REJECT,
    AUDITREVIEW,
    COMPLIANCECHECK
}
