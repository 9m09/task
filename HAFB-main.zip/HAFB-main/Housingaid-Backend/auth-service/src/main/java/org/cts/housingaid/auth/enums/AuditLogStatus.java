package org.cts.housingaid.auth.enums;

public enum AuditLogStatus {
    LOGGEDIN, LOGGEDOUT
}
