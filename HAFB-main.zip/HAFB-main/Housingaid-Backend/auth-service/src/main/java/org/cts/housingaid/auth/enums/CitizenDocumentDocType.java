package org.cts.housingaid.auth.enums;

public enum CitizenDocumentDocType {
    IDPROOF,INCOMECERTIFICATE


}