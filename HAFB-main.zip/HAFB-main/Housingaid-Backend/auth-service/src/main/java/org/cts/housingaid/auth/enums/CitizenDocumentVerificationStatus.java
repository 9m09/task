package org.cts.housingaid.auth.enums;

public enum CitizenDocumentVerificationStatus {
    PENDING,VERIFIED,REJECTED

}