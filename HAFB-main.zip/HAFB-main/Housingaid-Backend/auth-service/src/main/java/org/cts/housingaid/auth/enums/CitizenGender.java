package org.cts.housingaid.auth.enums;

public enum CitizenGender {
    MALE,FEMALE,OTHER
}