package org.cts.housingaid.auth.enums;

public enum CitizenStatus {
    ACTIVE,INACTIVE,SUSPENDED,PENDING
}