package org.cts.housingaid.auth.enums;

public enum HousingUnitType {
    APARTMENT, SHELTER
}
