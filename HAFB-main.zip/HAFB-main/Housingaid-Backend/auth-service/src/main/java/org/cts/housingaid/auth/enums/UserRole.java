package org.cts.housingaid.auth.enums;

public enum UserRole {
    CITIZEN,OFFICER,MANAGER,ADMIN,COMPLIANCE,AUDITOR
}