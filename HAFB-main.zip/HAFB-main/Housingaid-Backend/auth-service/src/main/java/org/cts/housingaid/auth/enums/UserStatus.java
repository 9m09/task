package org.cts.housingaid.auth.enums;

public enum UserStatus {
    ACTIVE ,INACTIVE,PENDING,SUSPENDED
}
