package org.cts.housingaid.auth.exception;

import org.cts.housingaid.auth.util.ExceptionConstants;

/**
 * Custom Exception for the Identity & Citizen Microservice.
 * Thrown when an audit record search by ID fails within the
 * security tracking database of this service.
 */
public class AuditLogNotFoundException extends RuntimeException {

    // Default constructor using the local service's constant
    public AuditLogNotFoundException() {
        super(ExceptionConstants.AUDIT_LOG_NOT_FOUND);
    }

    // Constructor for custom error messages
    public AuditLogNotFoundException(String message) {
        super(message);
    }
}