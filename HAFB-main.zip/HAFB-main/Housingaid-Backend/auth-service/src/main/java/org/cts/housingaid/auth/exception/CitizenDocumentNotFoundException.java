package org.cts.housingaid.auth.exception;

import org.cts.housingaid.auth.util.ExceptionConstants;
public class CitizenDocumentNotFoundException extends RuntimeException {

    public CitizenDocumentNotFoundException() {
        super(ExceptionConstants.CITIZEN_DOCUMENT_NOT_FOUND);
    }
    public CitizenDocumentNotFoundException(String message) {
        super(message);
    }
}