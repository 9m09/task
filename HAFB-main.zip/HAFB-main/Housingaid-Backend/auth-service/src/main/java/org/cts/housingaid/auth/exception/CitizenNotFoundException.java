package org.cts.housingaid.auth.exception;
import org.cts.housingaid.auth.util.ExceptionConstants;
public class CitizenNotFoundException extends RuntimeException {

    public CitizenNotFoundException() {
        super(ExceptionConstants.CITIZEN_NOT_FOUND);
    }
    public CitizenNotFoundException(String message) {
        super(message);
    }
}