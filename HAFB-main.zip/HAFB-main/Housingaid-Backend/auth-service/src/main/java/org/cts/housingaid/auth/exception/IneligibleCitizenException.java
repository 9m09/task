package org.cts.housingaid.auth.exception;

public class IneligibleCitizenException extends RuntimeException {
    public IneligibleCitizenException(String message) {
        super(message);
    }
}
