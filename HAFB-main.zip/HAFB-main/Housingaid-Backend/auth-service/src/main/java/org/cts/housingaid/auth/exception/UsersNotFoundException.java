package org.cts.housingaid.auth.exception;

import org.cts.housingaid.auth.util.ExceptionConstants;

/**
 * Custom Exception for the Identity & Citizen Microservice.
 * Thrown when a user search by ID or Email fails within the
 * identity-specific database.
 */
public class UsersNotFoundException extends RuntimeException {

    // Default constructor using the local constant
    public UsersNotFoundException() {
        super(ExceptionConstants.USER_NOT_FOUND);
    }

    // Constructor for custom error messages
    public UsersNotFoundException(String message) {
        super(message);
    }
}