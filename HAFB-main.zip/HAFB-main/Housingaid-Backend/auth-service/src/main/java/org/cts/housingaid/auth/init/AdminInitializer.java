package org.cts.housingaid.auth.init;

import jakarta.annotation.PostConstruct;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.cts.housingaid.auth.dao.UsersRepository;
import org.cts.housingaid.auth.entity.Users;
import org.cts.housingaid.auth.enums.UserRole;
import org.cts.housingaid.auth.enums.UserStatus;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

//@Configuration
@Component
@RequiredArgsConstructor
//@NoArgsConstructor
public class AdminInitializer {

    private final UsersRepository usersRepository;
    private final PasswordEncoder passwordEncoder;

    @PostConstruct
    public void init() {
//             check if admin already exists
            if (usersRepository.findByUserRole(UserRole.ADMIN).isEmpty()) {
                Users admin = new Users();
                admin.setUserName("Admin");
                admin.setUserEmail("admin@gmail.com");
                admin.setUserPassword(passwordEncoder.encode("admin123"));
                admin.setUserRole(UserRole.ADMIN);
                admin.setUserStatus(UserStatus.ACTIVE);
                admin.setUserPhone("1234567890");
                usersRepository.save(admin);

                System.out.println("Admin created successfully");
            }
        };
    }
