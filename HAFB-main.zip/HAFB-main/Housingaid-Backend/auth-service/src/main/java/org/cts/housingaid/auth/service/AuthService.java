package org.cts.housingaid.auth.service;

public interface AuthService {

    String login(String email, String password);
}
