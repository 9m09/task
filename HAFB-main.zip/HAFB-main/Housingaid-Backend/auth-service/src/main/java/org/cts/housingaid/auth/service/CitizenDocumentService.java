package org.cts.housingaid.auth.service;

import org.cts.housingaid.auth.dto.CitizenDocumentDTO;
import org.cts.housingaid.auth.exception.CitizenDocumentNotFoundException;
import org.cts.housingaid.auth.exception.CitizenNotFoundException;

import java.util.List;

public interface CitizenDocumentService {

    CitizenDocumentDTO uploadDocument(Long citizenId, CitizenDocumentDTO citizenDocumentDTO) throws CitizenNotFoundException;

    void deleteDocument(Long citizenDocumentId, Long citizenId) throws CitizenDocumentNotFoundException, CitizenNotFoundException;

    CitizenDocumentDTO updateDocumentAfterRejection(Long citizenId, Long citizenDocumentId, CitizenDocumentDTO citizenDocumentDTO) throws CitizenDocumentNotFoundException;

    List<CitizenDocumentDTO> getAllDocumentsByCitizen(Long citizenId) throws CitizenNotFoundException;

    void updateDocStatus(String citizenStatus,Long citizenDocumentId);

    Long getCitizenId(Long citizenDocumentId);
}