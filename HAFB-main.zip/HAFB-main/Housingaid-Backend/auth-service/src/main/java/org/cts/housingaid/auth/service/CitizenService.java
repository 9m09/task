package org.cts.housingaid.auth.service;

import org.cts.housingaid.auth.dto.CitizenDTO;
import org.cts.housingaid.auth.entity.Citizen;
import org.cts.housingaid.auth.exception.CitizenNotFoundException;

import java.util.List;

public interface CitizenService {

    void updateCitizen(CitizenDTO citizenDTO) throws CitizenNotFoundException;

    CitizenDTO getCitizenById(Long citizenId) throws CitizenNotFoundException;

    CitizenDTO getCitizenByUserId(Long userId) throws CitizenNotFoundException;

    void deleteCitizen(Long citizenId) throws CitizenNotFoundException;

    List<CitizenDTO> getAllCitizens() throws CitizenNotFoundException;

    Citizen saveCitizen(Citizen citizen);

}