package org.cts.housingaid.auth.service;

import org.cts.housingaid.auth.dto.CitizenRegistrationDTO;

public interface RegistrationService {

    CitizenRegistrationDTO registerCitizen(CitizenRegistrationDTO citizenRegistrationDTO);

}