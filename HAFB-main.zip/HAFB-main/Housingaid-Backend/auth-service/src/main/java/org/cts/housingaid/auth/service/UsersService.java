package org.cts.housingaid.auth.service;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import org.cts.housingaid.auth.dto.UsersCreateDTO;
import org.cts.housingaid.auth.dto.UsersProfileDTO;
import org.cts.housingaid.auth.enums.UserStatus;
import org.cts.housingaid.auth.exception.UsersNotFoundException;

import java.util.List;

public interface UsersService {

    void updateUser(UsersCreateDTO usersCreateDTO) throws UsersNotFoundException;

    void createUser(UsersCreateDTO usersCreateDTO);

    List<UsersCreateDTO> getAllUsers() throws UsersNotFoundException;

    UsersCreateDTO getUserById(Long userId) throws UsersNotFoundException;

    void updateUserStatus(Long userId, UserStatus userStatus) throws UsersNotFoundException;

    void deleteUser(Long userId) throws UsersNotFoundException;

    UsersProfileDTO getUserByEmail(String email);

   Long getUserId(String email);


//    UsersUpdateDTO updateUser(String email)
}