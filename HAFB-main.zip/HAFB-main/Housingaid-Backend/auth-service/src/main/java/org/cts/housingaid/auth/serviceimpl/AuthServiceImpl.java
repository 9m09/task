package org.cts.housingaid.auth.serviceimpl;

import lombok.RequiredArgsConstructor;
import org.cts.housingaid.auth.JWTService.JwtService;
import org.cts.housingaid.auth.dao.UsersRepository;
import org.cts.housingaid.auth.entity.Users;
import org.cts.housingaid.auth.service.AuthService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final AuthenticationManager authenticationManager;
    private final UsersRepository userRepository;
    private final JwtService jwtService;

    @Override
    public String login(String email, String password) {

        // 🔥 Step 1: authenticate using Spring Security
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(email, password)
        );

        // 🔥 Step 2: fetch user
        Users user = userRepository.findByUserEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // 🔥 Step 3: generate JWT
        return jwtService.generateToken(
                user.getUserEmail(),
                user.getUserRole().name(),
                user.getUserName(),
                user.getUserId()
        );
    }
}

