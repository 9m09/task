package org.cts.housingaid.auth.serviceimpl;

import lombok.AllArgsConstructor;
import org.cts.housingaid.auth.dao.CitizenDocumentRepository;
import org.cts.housingaid.auth.dao.CitizenRepository;
import org.cts.housingaid.auth.dto.CitizenDocumentDTO;
import org.cts.housingaid.auth.entity.Citizen;
import org.cts.housingaid.auth.entity.CitizenDocument;
import org.cts.housingaid.auth.enums.CitizenDocumentVerificationStatus;
import org.cts.housingaid.auth.exception.CitizenDocumentNotFoundException;
import org.cts.housingaid.auth.exception.CitizenNotFoundException;
import org.cts.housingaid.auth.service.CitizenDocumentService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

import static org.cts.housingaid.auth.util.ExceptionConstants.*;

@Service
@AllArgsConstructor
public class CitizenDocumentServiceImpl implements CitizenDocumentService {

    private final CitizenRepository citizenRepository;
    private final CitizenDocumentRepository citizenDocumentRepository;
    private final ModelMapper modelMapper;

    @Override
    public CitizenDocumentDTO uploadDocument(Long citizenId, CitizenDocumentDTO citizenDocumentDTO) throws CitizenNotFoundException {

        Citizen citizen = citizenRepository.findById(citizenId)
                .orElseThrow(() -> new CitizenNotFoundException(CITIZEN_NOT_FOUND));

        CitizenDocument citizenDocument = modelMapper.map(citizenDocumentDTO, CitizenDocument.class);
        citizenDocument.setCitizenDocumentVerificationStatus(CitizenDocumentVerificationStatus.PENDING);
        citizenDocument.setCitizen(citizen);
        citizenDocument.setCitizenDocumentUploadedDate(LocalDateTime.now());
        citizenDocument.setCitizenDocumentVerificationStatus(CitizenDocumentVerificationStatus.PENDING);

        CitizenDocument savedDocument = citizenDocumentRepository.save(citizenDocument);

        return modelMapper.map(savedDocument, CitizenDocumentDTO.class);
    }

    @Override
    public void deleteDocument(Long citizenDocumentId, Long citizenId) throws CitizenDocumentNotFoundException, CitizenNotFoundException {

        CitizenDocument citizenDocument = citizenDocumentRepository.findById(citizenDocumentId)
                .orElseThrow(() -> new CitizenDocumentNotFoundException(CITIZEN_DOCUMENT_NOT_FOUND));

        if(!citizenDocument.getCitizen().getCitizenId().equals(citizenId)){
            throw new IllegalStateException(DOCUMENT_NOT_OWNED_BY_CITIZEN);
        }

        if(citizenDocument.getCitizenDocumentVerificationStatus() != CitizenDocumentVerificationStatus.PENDING){
            throw new IllegalStateException(DOCUMENT_NOT_DELETABLE);
        }

        citizenDocumentRepository.delete(citizenDocument);
    }

    @Override
    public CitizenDocumentDTO updateDocumentAfterRejection(Long citizenId, Long citizenDocumentId, CitizenDocumentDTO citizenDocumentDTO) throws CitizenDocumentNotFoundException {

        CitizenDocument citizenDocument = citizenDocumentRepository.findById(citizenDocumentId)
                .orElseThrow(() -> new CitizenDocumentNotFoundException(CITIZEN_DOCUMENT_NOT_FOUND));

        if(!citizenDocument.getCitizen().getCitizenId().equals(citizenId)){
            throw new IllegalStateException(DOCUMENT_NOT_OWNED_BY_CITIZEN);
        }

        if(citizenDocument.getCitizenDocumentVerificationStatus() != CitizenDocumentVerificationStatus.REJECTED){
            throw new IllegalStateException(DOCUMENT_NOT_DELETABLE);
        }

        citizenDocument.setCitizenDocumentFileUri(citizenDocumentDTO.getCitizenDocumentFileUri());
        citizenDocument.setCitizenDocumentUploadedDate(LocalDateTime.now());
        citizenDocument.setCitizenDocumentVerificationStatus(CitizenDocumentVerificationStatus.PENDING);

        CitizenDocument updatedDocument = citizenDocumentRepository.save(citizenDocument);

        return modelMapper.map(updatedDocument, CitizenDocumentDTO.class);
    }

    @Override
    public List<CitizenDocumentDTO> getAllDocumentsByCitizen(Long citizenId) throws CitizenNotFoundException {

        citizenRepository.findById(citizenId)
                .orElseThrow(() -> new CitizenNotFoundException(CITIZEN_NOT_FOUND));

        List<CitizenDocument> documents = citizenDocumentRepository.findAllByCitizenCitizenId(citizenId);

        return documents.stream().map(doc -> modelMapper.map(doc, CitizenDocumentDTO.class)).toList();
    }

    @Override
    public void updateDocStatus(String citizenStatus, Long citizenDocumentId) {
        CitizenDocument citizenDocument=citizenDocumentRepository.findById(citizenDocumentId).get();
        citizenDocument.setCitizenDocumentVerificationStatus(CitizenDocumentVerificationStatus.valueOf(citizenStatus));
        citizenDocumentRepository.save(citizenDocument);
    }


    @Override
    public Long getCitizenId(Long citizenDocumentId) {
        CitizenDocument citizenDocument=citizenDocumentRepository.findById(citizenDocumentId).get();
        Citizen citizen=citizenDocument.getCitizen();
        return citizen.getCitizenId();
    }

}