package org.cts.housingaid.auth.serviceimpl;

import lombok.AllArgsConstructor;
import org.cts.housingaid.auth.dao.CitizenRepository;
import org.cts.housingaid.auth.dao.UsersRepository;
import org.cts.housingaid.auth.dto.CitizenDTO;
import org.cts.housingaid.auth.entity.Citizen;
import org.cts.housingaid.auth.entity.Users;
import org.cts.housingaid.auth.exception.CitizenNotFoundException;
import org.cts.housingaid.auth.service.CitizenService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static org.cts.housingaid.auth.util.ExceptionConstants.CITIZEN_NOT_FOUND;
import static org.cts.housingaid.auth.util.ExceptionConstants.EMPTY_DATA;

@Service
@AllArgsConstructor
public class CitizenServiceImpl implements CitizenService {

    private final CitizenRepository citizenRepository;
    private final UsersRepository usersRepository;
    private final ModelMapper modelMapper;

    @Override
    public void updateCitizen(CitizenDTO citizenDTO) throws CitizenNotFoundException {

        Optional<Citizen> optionalCitizen = citizenRepository.findById(citizenDTO.getCitizenId());

        if(optionalCitizen.isEmpty()){
            throw new CitizenNotFoundException(CITIZEN_NOT_FOUND);
        }

        Citizen existingCitizen = optionalCitizen.get();

        modelMapper.map(citizenDTO, existingCitizen);

        citizenRepository.save(existingCitizen);
    }

    private CitizenDTO convertToDto(Citizen citizen) {
        CitizenDTO dto = modelMapper.map(citizen, CitizenDTO.class);
        if (citizen.getUser() != null) {
            dto.setUserId(citizen.getUser().getUserId());
        }
        return dto;
    }

    @Override
    public CitizenDTO getCitizenById(Long citizenId) throws CitizenNotFoundException {

        Citizen citizen = citizenRepository.findById(citizenId)
                .orElseThrow(() -> new CitizenNotFoundException(CITIZEN_NOT_FOUND));

        return convertToDto(citizen);
    }

    @Override
    public CitizenDTO getCitizenByUserId(Long userId) throws CitizenNotFoundException {
        Citizen citizen = citizenRepository.findByUserUserId(userId)
                .orElseThrow(() -> new CitizenNotFoundException(CITIZEN_NOT_FOUND));
        return convertToDto(citizen);
    }

    @Override
    public void deleteCitizen(Long citizenId) throws CitizenNotFoundException {

        Citizen citizen = citizenRepository.findById(citizenId)
                .orElseThrow(() -> new CitizenNotFoundException(CITIZEN_NOT_FOUND));

        Users users = citizen.getUser();

        usersRepository.delete(users);
    }

    @Override
    public List<CitizenDTO> getAllCitizens() throws CitizenNotFoundException {

        List<Citizen> citizens = citizenRepository.findAll();

        if(citizens.isEmpty()){
            throw new CitizenNotFoundException(EMPTY_DATA);
        }

        return citizens.stream().map(this::convertToDto).toList();
    }

    @Override
    public Citizen saveCitizen(Citizen citizen) {
        return citizenRepository.save(citizen);
    }
}