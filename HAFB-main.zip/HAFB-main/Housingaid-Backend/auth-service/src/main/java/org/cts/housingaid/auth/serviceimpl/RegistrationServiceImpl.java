package org.cts.housingaid.auth.serviceimpl;
import lombok.AllArgsConstructor;
import org.cts.housingaid.auth.dao.CitizenRepository;
import org.cts.housingaid.auth.dao.UsersRepository;
import org.cts.housingaid.auth.dto.CitizenRegistrationDTO;
import org.cts.housingaid.auth.entity.Citizen;
import org.cts.housingaid.auth.entity.Users;
import org.cts.housingaid.auth.enums.CitizenStatus;
import org.cts.housingaid.auth.enums.UserRole;
import org.cts.housingaid.auth.enums.UserStatus;
import org.cts.housingaid.auth.exception.UserAlreadyExistsException;
import org.cts.housingaid.auth.service.RegistrationService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static org.cts.housingaid.auth.util.ExceptionConstants.USER_ALREADY_EXISTS;
@Service
@AllArgsConstructor
public class RegistrationServiceImpl implements RegistrationService {
    private final UsersRepository usersRepository;
    private final CitizenRepository citizenRepository;
    private final PasswordEncoder passwordEncoder;
    @Override
    @Transactional
    public CitizenRegistrationDTO registerCitizen(CitizenRegistrationDTO citizenRegistrationDTO){
        if(usersRepository.findByUserEmail(citizenRegistrationDTO.getUserEmail()).isPresent()){
            throw new UserAlreadyExistsException(USER_ALREADY_EXISTS);}

        Users users = new Users();
        users.setUserName(citizenRegistrationDTO.getUserName());
        users.setUserEmail(citizenRegistrationDTO.getUserEmail());users.setUserPassword(passwordEncoder.encode(citizenRegistrationDTO.getUserPassword()));
        users.setUserPhone(citizenRegistrationDTO.getCitizenContactInfo());
        users.setUserRole(UserRole.CITIZEN);
        users.setUserStatus(UserStatus.ACTIVE);
        Users savedUsers = usersRepository.save(users);

        Citizen citizen = new Citizen();
        citizen.setUser(savedUsers);
        citizen.setCitizenDOB(citizenRegistrationDTO.getCitizenDOB());
        citizen.setCitizenName(citizenRegistrationDTO.getUserName());
        citizen.setCitizenGender(citizenRegistrationDTO.getCitizenGender());
        citizen.setCitizenAddress(citizenRegistrationDTO.getCitizenAddress());
        citizen.setCitizenContactInfo(citizenRegistrationDTO.getCitizenContactInfo());
        citizen.setCitizenStatus(CitizenStatus.PENDING);
        Citizen savedCitizen = citizenRepository.save(citizen);
//        citizenRegistrationDTO.setUserId(Math.toIntExact(savedUsers.getUserId()));
//        citizenRegistrationDTO.setCitizenId(Math.toIntExact(savedCitizen.getCitizenId()));
        return citizenRegistrationDTO;
    }

}