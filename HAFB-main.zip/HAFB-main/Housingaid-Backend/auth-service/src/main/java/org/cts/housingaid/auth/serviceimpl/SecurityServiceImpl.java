package org.cts.housingaid.auth.serviceimpl;

import org.cts.housingaid.auth.dao.UsersRepository;
import org.cts.housingaid.auth.entity.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor

public class SecurityServiceImpl implements UserDetailsService {

    private final UsersRepository userRepository;

    @Override 
    public UserDetails loadUserByUsername(String email)
            throws UsernameNotFoundException {

        Users user = userRepository.findByUserEmail(email)
                .orElseThrow(() ->
                        new UsernameNotFoundException("User not found"));

       return User.builder()
        .username(user.getUserEmail())
        .password(user.getUserPassword())
        .roles(user.getUserRole().name())
        .build();
    }
}
