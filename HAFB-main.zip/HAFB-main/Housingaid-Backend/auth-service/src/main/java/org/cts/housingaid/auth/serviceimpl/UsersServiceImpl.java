package org.cts.housingaid.auth.serviceimpl;

import lombok.AllArgsConstructor;
import org.cts.housingaid.auth.dao.UsersRepository;
import org.cts.housingaid.auth.dto.UsersCreateDTO;
import org.cts.housingaid.auth.dto.UsersProfileDTO;
import org.cts.housingaid.auth.entity.Users;
import org.cts.housingaid.auth.enums.UserStatus;
import org.cts.housingaid.auth.exception.UsersNotFoundException;
import org.cts.housingaid.auth.JWTService.JwtService;
import org.cts.housingaid.auth.service.UsersService;
import org.modelmapper.ModelMapper;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static org.cts.housingaid.auth.util.ExceptionConstants.EMPTY_DATA;
import static org.cts.housingaid.auth.util.ExceptionConstants.USER_NOT_FOUND;

@Service
@AllArgsConstructor
public class UsersServiceImpl implements UsersService {

    private final UsersRepository usersRepository;
    private final ModelMapper modelMapper;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;

    @Override
    public void updateUser(UsersCreateDTO usersCreateDTO) throws UsersNotFoundException {

        Optional<Users> optionalUsers = usersRepository.findById(usersCreateDTO.getUserId());
        if(optionalUsers.isEmpty()){
            throw new UsersNotFoundException(USER_NOT_FOUND);
        }
        Users existingUsers = optionalUsers.get();
        modelMapper.map(usersCreateDTO, existingUsers);
        usersRepository.save(existingUsers);
    }

    @Override
    public void createUser(UsersCreateDTO usersCreateDTO){

        if(usersRepository.findByUserEmail(usersCreateDTO.getUserEmail()).isPresent()){
            throw new RuntimeException("User already exists with given email");
        }

        Users users = modelMapper.map(usersCreateDTO, Users.class);
        users.setUserPassword(passwordEncoder.encode(usersCreateDTO.getUserPassword()));

        usersRepository.save(users);
    }

    @Override
    public List<UsersCreateDTO> getAllUsers() throws UsersNotFoundException {

        List<Users> users = usersRepository.findAll();
        if(users.isEmpty()){
            throw new UsersNotFoundException(EMPTY_DATA);
        }
        return users.stream().map(user -> modelMapper.map(user, UsersCreateDTO.class)).toList();
    }

    @Override
    public UsersCreateDTO getUserById(Long userId) throws UsersNotFoundException {
        Users users = usersRepository.findById(userId).orElseThrow(() -> new UsersNotFoundException(USER_NOT_FOUND));
        return modelMapper.map(users, UsersCreateDTO.class);
    }

    @Override
    public void updateUserStatus(Long userId, UserStatus userStatus) throws UsersNotFoundException {
        Users users = usersRepository.findById(userId).orElseThrow(() -> new UsersNotFoundException(USER_NOT_FOUND));
        users.setUserStatus(userStatus);
        usersRepository.save(users);
    }

    @Override
    public void deleteUser(Long userId) throws UsersNotFoundException {

        Users users = usersRepository.findById(userId).orElseThrow(() -> new UsersNotFoundException(USER_NOT_FOUND));
        usersRepository.delete(users);
    }

    @Override
    public UsersProfileDTO getUserByEmail(String email) {
        Users user = usersRepository.findByUserEmail(email)
                .orElseThrow(() -> new UsersNotFoundException(USER_NOT_FOUND));

        return modelMapper.map(user, UsersProfileDTO.class);
    }

    @Override
    public Long getUserId(String email) {
        return usersRepository.getUserID(email);
    }


}