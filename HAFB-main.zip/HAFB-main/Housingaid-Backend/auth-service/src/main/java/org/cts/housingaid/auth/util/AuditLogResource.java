package org.cts.housingaid.auth.util;

import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cts.housingaid.auth.enums.AuditLogStatus;

import java.time.LocalDateTime;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class AuditLogResource {

    private int usersId;

    private AuditLogStatus auditLogStatus;

    private LocalDateTime logInDateAndTime;

    private LocalDateTime logOutDateAndTime;
}