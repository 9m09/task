package org.cts.housingaid.auth.util;

public class ExceptionConstants {

    public static final String CITIZEN_NOT_FOUND = "Citizen not found with the given details.";
    public static final String CITIZEN_DOCUMENT_NOT_FOUND = "Citizen document not found.";
    public static final String AUDIT_LOG_NOT_FOUND = "Audit log not found.";
    public static final String USER_NOT_FOUND = "User not found.";
    public static final String EMPTY_DATA = "No data available in database.";
    public static final String INTERNAL_ERROR = "Something went wrong. Please try again.";
    public static final String USER_ALREADY_EXISTS = "User already exists with given email.";
    public static final String DOCUMENT_NOT_OWNED_BY_CITIZEN = "The document does not belong to the specified citizen.";
    public static final String DOCUMENT_NOT_DELETABLE = "Document cannot be deleted after verification.";


    private ExceptionConstants() {
    }
}