package org.cts.housingaid.identity_citizen_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdentityCitizenServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
