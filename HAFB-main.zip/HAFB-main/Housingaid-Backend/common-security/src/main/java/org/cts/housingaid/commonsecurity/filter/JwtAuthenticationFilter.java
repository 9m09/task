package org.cts.housingaid.commonsecurity.filter;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.cts.housingaid.commonsecurity.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.util.List;


@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    protected void doFilterInternal(
            jakarta.servlet.http.HttpServletRequest request,
            jakarta.servlet.http.HttpServletResponse response,
            jakarta.servlet.FilterChain filterChain)
            throws java.io.IOException, jakarta.servlet.ServletException {

        String authHeader = request.getHeader("Authorization");

        if(request.getRequestURI().startsWith("/actuator/")){
            filterChain.doFilter(request, response);
            return;
        }

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        String token = authHeader.substring(7);

        try {
            var claims = jwtUtil.validateToken(token);

            String username = claims.getSubject();
            String role = claims.get("role", String.class);
            String prefixedRole = role.startsWith("ROLE_") ? role : "ROLE_" + role; // if we have saved role as "ADMIN", we need to 
                                                                                            // prefix it 
                                                                                        // with "ROLE_" to make it compatible with Spring 
                                                                                    //Security's  authority format. If it's already prefixed
                                                                                    // , we can use it as is.

            var authorities = List.of(new SimpleGrantedAuthority(prefixedRole)); // to create a list of authorities from the role claim in 
                                                                                    // the JWT. Spring Security expects a collection of 
                            // GrantedAuthority objects, so we create a SimpleGrantedAuthority with the prefixed role and put it in a list.

          
            
            var authToken = new UsernamePasswordAuthenticationToken(
                            username,
                            null,
                            authorities
                    );

        SecurityContextHolder.getContext()
                .setAuthentication(authToken);
            // storing the auth info in the security context for later use in controllers

        } catch (Exception e) {
            response.setStatus(401);
            return;
        }

        filterChain.doFilter(request, response);
    }

}
