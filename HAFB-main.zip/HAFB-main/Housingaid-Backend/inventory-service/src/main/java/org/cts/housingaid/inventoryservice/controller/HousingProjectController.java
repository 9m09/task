package org.cts.housingaid.inventoryservice.controller;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.cts.housingaid.inventoryservice.dto.HousingProjectDTO;
import org.cts.housingaid.inventoryservice.service.HousingProjectService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/inventory/housing-project")
@AllArgsConstructor
public class HousingProjectController {

    private final HousingProjectService housingProjectService;

    @PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN','MANAGER','OFFICER','AUDITOR')")
    @GetMapping("/get-all-housing-projects")
    public ResponseEntity<List<HousingProjectDTO>> getAllHousingProjects(){
        List<HousingProjectDTO> list = housingProjectService.getAllHousingProjects();
        return ResponseEntity.status(HttpStatus.OK).body(list);
    }

    @PreAuthorize("hasAnyRole('CITIZEN','COMPLIANCE','ADMIN','MANAGER','OFFICER','AUDITOR')")
    @GetMapping("/get-active-housing-projects")
    public ResponseEntity<List<HousingProjectDTO>> getActiveHousingProjects(){
        List<HousingProjectDTO> list = housingProjectService.getActiveHousingProjects();
        return ResponseEntity.status(HttpStatus.OK).body(list);
    }

    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    @PostMapping("/create-housing-project")
    public ResponseEntity<String> createHousingProject(@Valid @RequestBody HousingProjectDTO housingProjectDTO){
        housingProjectService.createHousingProject(housingProjectDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body("Housing Project created successfully");
    }

    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    @PutMapping("/update-housing-project/{id}")
    public ResponseEntity<String> updateHousingProject(@PathVariable Long id, @Valid @RequestBody HousingProjectDTO housingProjectDTO){
        housingProjectDTO.setHousingProjectId(id);
        housingProjectService.updateHousingProject(housingProjectDTO);
        return ResponseEntity.status(HttpStatus.OK).body("Housing Project updated successfully");
    }

    @PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN','MANAGER','OFFICER')")
    @GetMapping("/search-housing-project")
    public ResponseEntity<List<HousingProjectDTO>> searchHousingProject(@RequestParam(required = false) Long housingProjectId, @RequestParam(required = false) String housingProjectTitle){
        List<HousingProjectDTO> list = housingProjectService.getSearchedByHousingProjectIdORHousingProjectTitle(housingProjectId, housingProjectTitle);
        return ResponseEntity.status(HttpStatus.OK).body(list);
    }

    @PreAuthorize("hasAnyRole('AUDITOR','ADMIN','MANAGER')")
    @GetMapping("/count")
    public long getTotalProjects() {
        return housingProjectService.getTotalProjects();
    }

    @PreAuthorize("hasAnyRole('AUDITOR','ADMIN','MANAGER')")
    @GetMapping("/count/{status}")
    public long getCountByStatus(@PathVariable String status) {
        return housingProjectService.countByStatus(status);
    }

    @PreAuthorize("hasAnyRole('AUDITOR','ADMIN','MANAGER')")
    @GetMapping("/budget/sum")
    public Double getTotalBudget() {
        return housingProjectService.getTotalBudget();
    }

    @PreAuthorize("hasAnyRole('ADMIN','OFFICER','MANAGER','CITIZEN')")
    @GetMapping("/get-housing-project/{housingProjectId}")
    public HousingProjectDTO getHousingProject(@PathVariable Long housingProjectId){
        return housingProjectService.getHousingProject(housingProjectId);
    }

    @PreAuthorize("hasAnyRole('ADMIN','OFFICER')")
    @PutMapping("/update-no-of-houses")
    public void updateNoOfHouses(@RequestParam Long housingProjectId){
        System.out.println("projectId "+housingProjectId);
        housingProjectService.updateNoOfHouses(housingProjectId);
    }

    @PreAuthorize("hasAnyRole('ADMIN','OFFICER','AUDITOR')")
    @GetMapping("/check-available")
    public boolean checkAvailability(@RequestParam Long housingProjectId){
        return housingProjectService.checkAvailability(housingProjectId);
    }

}