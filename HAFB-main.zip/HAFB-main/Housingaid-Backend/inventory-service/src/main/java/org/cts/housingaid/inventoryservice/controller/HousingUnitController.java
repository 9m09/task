package org.cts.housingaid.inventoryservice.controller;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.cts.housingaid.inventoryservice.dto.HousingUnitDTO;
import org.cts.housingaid.inventoryservice.enums.HousingUnitType;
import org.cts.housingaid.inventoryservice.service.HousingUnitService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@PreAuthorize("hasAnyRole('MANAGER','ADMIN')")
@RequestMapping("/inventory/housing-unit")
@AllArgsConstructor
public class HousingUnitController {

    private final HousingUnitService housingUnitService;

    @PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN','MANAGER')")
    @GetMapping("/get-all-housing-units")
    public ResponseEntity<List<HousingUnitDTO>> getAllHousingUnits(){
        List<HousingUnitDTO> list = housingUnitService.getAllHousingUnits();
        return ResponseEntity.status(HttpStatus.OK).body(list);
    }

    @PostMapping("/create-housing-unit")
    public ResponseEntity<String> createHousingUnit(@Valid @RequestBody HousingUnitDTO housingUnitDTO){
        housingUnitService.createHousingUnit(housingUnitDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body("Housing Unit created successfully");
    }

    @PutMapping("/update-housing-unit/{id}")
    public ResponseEntity<String> updateHousingUnit(@PathVariable Long id, @Valid @RequestBody HousingUnitDTO housingUnitDTO){
        housingUnitDTO.setHousingUnitId(id);
        housingUnitService.updateHousingUnit(housingUnitDTO);
        return ResponseEntity.status(HttpStatus.OK).body("Housing Unit updated successfully");
    }

    @GetMapping("/search-housing-unit")
    public ResponseEntity<List<HousingUnitDTO>> searchHousingUnit(@RequestParam(required = false) Long housingUnitId, @RequestParam(required = false) String housingUnitLocation, @RequestParam(required = false) HousingUnitType housingUnitType){
        List<HousingUnitDTO> list = housingUnitService.getSearchedByHousingUnitIdOrHousingUnitLocationOrHousingUnitType(housingUnitId, housingUnitLocation, housingUnitType);
        return ResponseEntity.status(HttpStatus.OK).body(list);
    }

    @PreAuthorize("hasAnyRole('MANAGER','ADMIN','OFFICER')")
    @GetMapping("/get-id")
    public List<Long> getHousingUnitId(@RequestParam(value = "housingProjectId", required = true) Long housingProjectId) {
        System.out.println("Inside controller. Received ID: " + housingProjectId);
        return housingUnitService.getHousingUnitId(housingProjectId);
    }

    @PreAuthorize("hasAnyRole('MANAGER','ADMIN','OFFICER')")
    @GetMapping("/find-status")
    public String findStatus(@RequestParam  Long housingUnitId){
        System.out.println("inside controller find-status");
        return housingUnitService.findStatus(housingUnitId);
    } // housingUnit Status --> AVAILABLE

    @PreAuthorize("hasAnyRole('MANAGER','ADMIN','OFFICER')")
    @PutMapping("/update")
    public void updateHousingStatus(@RequestParam String housingStatus,@RequestParam Long housingUnitId){
        System.out.println("inside update controller");
        housingUnitService.updateHousingStatus(housingStatus,housingUnitId);
    }
    @PreAuthorize("hasAnyRole('MANAGER','ADMIN','OFFICER')")
    @GetMapping("/get-by-id")
    public HousingUnitDTO getHousingUnitById(@RequestParam Long housingUnitId){
        return housingUnitService.getHousingUnitById(housingUnitId);
    }
}