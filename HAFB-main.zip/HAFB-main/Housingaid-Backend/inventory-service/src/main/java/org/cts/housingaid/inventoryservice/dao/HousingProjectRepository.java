package org.cts.housingaid.inventoryservice.dao;

import org.cts.housingaid.inventoryservice.entity.HousingProject;
import org.cts.housingaid.inventoryservice.enums.HousingProjectStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HousingProjectRepository extends JpaRepository<HousingProject, Long> {

    @Query("select hp from HousingProject hp where hp.housingProjectId = :id or hp.housingProjectTitle = :title")
    List<HousingProject> findByHousingProjectIdOrHousingProjectTitle(@Param("id") Long housingProjectId, @Param("title") String housingProjectTitle);
    @Query("SELECT SUM(ha.housingProjectBudget) from HousingProject ha")
    Double sumAllBudgets();

    long countByHousingProjectStatus(HousingProjectStatus status);

    List<HousingProject> findByHousingProjectStatusNot(HousingProjectStatus housingProjectStatus);
}