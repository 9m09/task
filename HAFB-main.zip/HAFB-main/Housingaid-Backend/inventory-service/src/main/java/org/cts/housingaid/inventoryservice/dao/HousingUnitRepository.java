package org.cts.housingaid.inventoryservice.dao;

import org.cts.housingaid.inventoryservice.entity.HousingUnit;
import org.cts.housingaid.inventoryservice.enums.HousingUnitType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HousingUnitRepository extends JpaRepository<HousingUnit, Long> {

    @Query("select hu from HousingUnit hu where hu.housingUnitId = :id or hu.housingUnitLocation = :location or hu.housingUnitType = :type")
    List<HousingUnit> findByHousingUnitIdOrHousingUnitLocationOrHousingUnitType(@Param("id") Long housingUnitId, @Param("location") String housingUnitLocation, @Param("type") HousingUnitType housingUnitType);

    @Query("select hu.housingUnitId from HousingUnit hu where hu.housingProject.housingProjectId = :housingProject")
    List<Long> findByHousingUnitBYProjectId(@Param("housingProject") Long housingProject);

    @Query("select hu.housingUnitStatus from HousingUnit hu where hu.housingUnitId = :housingUnitId")
    String findStatus(@Param("housingUnitId") Long housingUnitId);

}