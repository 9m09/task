package org.cts.housingaid.inventoryservice.dao;

import org.cts.housingaid.inventoryservice.entity.Resources;
import org.cts.housingaid.inventoryservice.enums.ResourcesStatus;
import org.cts.housingaid.inventoryservice.enums.ResourcesType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ResourcesRepository extends JpaRepository<Resources, Long> {

    List<Resources> findByResourcesIdOrResourcesTypeOrResourcesStatus(@Param("id") Long resourcesId, @Param("type") ResourcesType resourcesType, @Param("status") ResourcesStatus resourcesStatus);

}