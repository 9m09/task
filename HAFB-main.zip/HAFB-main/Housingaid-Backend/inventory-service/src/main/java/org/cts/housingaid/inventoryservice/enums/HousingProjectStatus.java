  package org.cts.housingaid.inventoryservice.enums;

public enum HousingProjectStatus {
    PLANNED, UNDERPROGRESS, COMPLETED
}
