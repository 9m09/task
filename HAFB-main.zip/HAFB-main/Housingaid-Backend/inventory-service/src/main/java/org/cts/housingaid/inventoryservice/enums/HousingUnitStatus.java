package org.cts.housingaid.inventoryservice.enums;

public enum HousingUnitStatus {
    AVAILABLE,ALLOCATED,MAINTENANCE
}