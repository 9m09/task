package org.cts.housingaid.inventoryservice.enums;

public enum HousingUnitType {
    APARTMENT, SHELTER
}
