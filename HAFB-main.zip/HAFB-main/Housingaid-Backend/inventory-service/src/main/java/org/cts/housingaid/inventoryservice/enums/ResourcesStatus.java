package org.cts.housingaid.inventoryservice.enums;

public enum ResourcesStatus {
    ALLOCATED, INUSE, AVAILABLE
}
