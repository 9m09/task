package org.cts.housingaid.inventoryservice.enums;

public enum ResourcesType {
    FUNDS, MATERIALS
}
