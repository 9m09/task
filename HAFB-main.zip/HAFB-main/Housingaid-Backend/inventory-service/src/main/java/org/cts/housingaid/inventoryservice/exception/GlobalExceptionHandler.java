package org.cts.housingaid.inventoryservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private Map<String,Object> buildResponse(String message) {
        Map<String,Object> response=new HashMap<>();
        response.put("timestamp", LocalDateTime.now());
        response.put("status", HttpStatus.NOT_FOUND.value());
        response.put("error", HttpStatus.NOT_FOUND.getReasonPhrase());
        response.put("message",message);
        return response;
    }

    @ExceptionHandler(HousingProjectNotFoundException.class)
    public ResponseEntity<?> handleProjectNotFound (HousingProjectNotFoundException ex) {
        return new ResponseEntity<>(buildResponse(ex.getMessage()), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(HousingUnitNotFoundException.class)
    public ResponseEntity<?> handleUnitNotFound(HousingUnitNotFoundException ex) {
        return new ResponseEntity<>(buildResponse(ex.getMessage()), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(ResourcesNotFoundException.class)
    public ResponseEntity<?> handleResourceNotFound(ResourcesNotFoundException ex) {
        return new ResponseEntity<>(buildResponse(ex.getMessage()),HttpStatus.NOT_FOUND);
    }
}