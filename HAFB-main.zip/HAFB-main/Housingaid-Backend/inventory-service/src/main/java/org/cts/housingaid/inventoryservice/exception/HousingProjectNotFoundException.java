package org.cts.housingaid.inventoryservice.exception;

import org.cts.housingaid.inventoryservice.util.ExceptionConstants;

public class HousingProjectNotFoundException extends RuntimeException {

    public HousingProjectNotFoundException() {
        super(ExceptionConstants.HOUSING_PROJECT_NOT_FOUND);
    }
    public HousingProjectNotFoundException(String message) {
        super(message);
    }
}