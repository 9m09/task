package org.cts.housingaid.inventoryservice.exception;

import org.cts.housingaid.inventoryservice.util.ExceptionConstants;

public class HousingUnitNotFoundException extends RuntimeException {

    public HousingUnitNotFoundException() {
        super(ExceptionConstants.HOUSING_UNIT_NOT_FOUND);
    }
    public HousingUnitNotFoundException(String message) {
        super(message);
    }
}