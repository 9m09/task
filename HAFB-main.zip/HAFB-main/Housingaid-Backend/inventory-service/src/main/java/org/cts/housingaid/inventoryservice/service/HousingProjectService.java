package org.cts.housingaid.inventoryservice.service;

import org.cts.housingaid.inventoryservice.dto.HousingProjectDTO;
import org.cts.housingaid.inventoryservice.exception.HousingProjectNotFoundException;

import java.util.List;

public interface HousingProjectService {

    void updateHousingProject(HousingProjectDTO housingProjectDTO) throws HousingProjectNotFoundException;

    void createHousingProject(HousingProjectDTO housingProjectDTO);

    List<HousingProjectDTO> getSearchedByHousingProjectIdORHousingProjectTitle(Long housingProjectId, String housingProjectTitle) throws HousingProjectNotFoundException;

    List<HousingProjectDTO> getAllHousingProjects() throws HousingProjectNotFoundException;

    List<HousingProjectDTO> getActiveHousingProjects();

    long getTotalProjects();

    long countByStatus(String status);

    Double getTotalBudget();

    HousingProjectDTO getHousingProject(Long housingProjectId);

    void updateNoOfHouses(Long housingProjectId);

    boolean checkAvailability(Long housingProjectId);
}