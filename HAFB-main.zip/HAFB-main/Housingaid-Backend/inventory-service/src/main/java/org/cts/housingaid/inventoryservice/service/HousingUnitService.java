package org.cts.housingaid.inventoryservice.service;

import org.cts.housingaid.inventoryservice.dto.HousingUnitDTO;
import org.cts.housingaid.inventoryservice.enums.HousingUnitType;
import org.cts.housingaid.inventoryservice.exception.HousingUnitNotFoundException;

import java.util.List;

public interface HousingUnitService {

    void updateHousingUnit(HousingUnitDTO housingUnitDTO) throws HousingUnitNotFoundException;

    void createHousingUnit(HousingUnitDTO housingUnitDTO);

    List<HousingUnitDTO> getSearchedByHousingUnitIdOrHousingUnitLocationOrHousingUnitType(Long housingUnitId, String housingUnitLocation, HousingUnitType housingUnitType) throws HousingUnitNotFoundException;

    List<HousingUnitDTO> getAllHousingUnits() throws HousingUnitNotFoundException;

    void updateHousingStatus(String housingStatus, Long housingUnitId);

    String findStatus(Long housingUnitId);

    List<Long> getHousingUnitId(Long housingProjectId);

    HousingUnitDTO getHousingUnitById(Long housingUnitId);
}