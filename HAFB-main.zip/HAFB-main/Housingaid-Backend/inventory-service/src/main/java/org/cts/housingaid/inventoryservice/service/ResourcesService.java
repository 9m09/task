package org.cts.housingaid.inventoryservice.service;

import org.cts.housingaid.inventoryservice.dto.ResourcesDTO;
import org.cts.housingaid.inventoryservice.enums.ResourcesStatus;
import org.cts.housingaid.inventoryservice.enums.ResourcesType;
import org.cts.housingaid.inventoryservice.exception.HousingProjectNotFoundException;
import org.cts.housingaid.inventoryservice.exception.ResourcesNotFoundException;

import java.util.List;

public interface ResourcesService {

    void updateResources(ResourcesDTO resourcesDTO) throws ResourcesNotFoundException, HousingProjectNotFoundException;

    void createResources(ResourcesDTO resourcesDTO) throws HousingProjectNotFoundException;

    List<ResourcesDTO> getSearchedByResourcesIdOrResourcesTypeOrResourcesStatus(Long resourcesId, ResourcesType resourcesType, ResourcesStatus resourcesStatus) throws ResourcesNotFoundException;

    List<ResourcesDTO> getAllResources() throws ResourcesNotFoundException;

}