package org.cts.housingaid.inventoryservice.serviceimpl;

import lombok.AllArgsConstructor;
import org.cts.housingaid.inventoryservice.dao.HousingProjectRepository;
import org.cts.housingaid.inventoryservice.dto.HousingProjectDTO;
import org.cts.housingaid.inventoryservice.entity.HousingProject;
import org.cts.housingaid.inventoryservice.enums.HousingProjectStatus;
import org.cts.housingaid.inventoryservice.exception.HousingProjectNotFoundException;
import org.cts.housingaid.inventoryservice.service.HousingProjectService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static org.cts.housingaid.inventoryservice.util.ExceptionConstants.EMPTY_DATA;
import static org.cts.housingaid.inventoryservice.util.ExceptionConstants.HOUSING_PROJECT_NOT_FOUND;

@Service
@AllArgsConstructor
public class HousingProjectServiceImpl implements HousingProjectService {

    private final HousingProjectRepository housingProjectRepository;
    private final ModelMapper modelMapper;

    @Override
    public void updateHousingProject(HousingProjectDTO housingProjectDTO) throws HousingProjectNotFoundException {
        Optional<HousingProject> optionalHousingProject = housingProjectRepository.findById(housingProjectDTO.getHousingProjectId());
        if(optionalHousingProject.isEmpty()){
            throw new HousingProjectNotFoundException(HOUSING_PROJECT_NOT_FOUND);
        }
        HousingProject existingProject = optionalHousingProject.get();
        modelMapper.map(housingProjectDTO, existingProject);
        housingProjectRepository.save(existingProject);
    }

    @Override
    public void createHousingProject(HousingProjectDTO housingProjectDTO) {
        HousingProject housingProject = modelMapper.map(housingProjectDTO, HousingProject.class);
        housingProject.setAllocatedHouses(0L);
        housingProjectRepository.save(housingProject);
    }

    @Override
    public List<HousingProjectDTO> getSearchedByHousingProjectIdORHousingProjectTitle(Long housingProjectId, String housingProjectTitle) throws HousingProjectNotFoundException {
        List<HousingProject> housingProjects = housingProjectRepository.findByHousingProjectIdOrHousingProjectTitle(housingProjectId, housingProjectTitle);
        if(housingProjects.isEmpty()){
            throw new HousingProjectNotFoundException(EMPTY_DATA);
        }
        return housingProjects.stream().map(project -> modelMapper.map(project, HousingProjectDTO.class)).toList();
    }

    @Override
    public List<HousingProjectDTO> getAllHousingProjects() throws HousingProjectNotFoundException {
        List<HousingProject> housingProjects = housingProjectRepository.findAll();
        if(housingProjects.isEmpty()){
            throw new HousingProjectNotFoundException(EMPTY_DATA);
        }

        return housingProjects.stream().map(project -> modelMapper.map(project, HousingProjectDTO.class)).toList();
    }

    @Override
    public List<HousingProjectDTO> getActiveHousingProjects() {
        List<HousingProject> housingProjects = housingProjectRepository.findByHousingProjectStatusNot(HousingProjectStatus.COMPLETED);
        return housingProjects.stream().map(project -> modelMapper.map(project, HousingProjectDTO.class)).toList();
    }

    @Override
    public long getTotalProjects() {
        return housingProjectRepository.count();
    }

    @Override
    public long countByStatus(String statusString) {
        try {
            // Converts "COMPLETED" -> ProjectStatus.COMPLETED
            HousingProjectStatus status = HousingProjectStatus.valueOf(statusString.toUpperCase());
            return housingProjectRepository.countByHousingProjectStatus(status);
        } catch (IllegalArgumentException | NullPointerException e) {
            return 0;
        }
    }

    @Override
    public Double getTotalBudget() {
        Double sum = housingProjectRepository.sumAllBudgets();
        return (sum != null) ? sum : 0.0;
    }

    @Override
    public HousingProjectDTO getHousingProject(Long housingProjectId) {
        return modelMapper.map(housingProjectRepository.findById(housingProjectId).get(),HousingProjectDTO.class);
    }

    @Override
    public void updateNoOfHouses(Long housingProjectId) {
        HousingProject housingProject=housingProjectRepository.findById(housingProjectId).get();
        housingProject.setAllocatedHouses(housingProject.getAllocatedHouses()+1);
    }

    @Override
    public boolean checkAvailability(Long housingProjectId) {
        HousingProject housingProject=housingProjectRepository.findById(housingProjectId).get();
        if(housingProject.getAllocatedHouses() < housingProject.getNumberOfHouses()){
            return true;
        }
        return false;
    }

}