package org.cts.housingaid.notificationservice.Client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="allocation-service",configuration = FeignClientInterceptor.class)
public interface AllocationClient {
    @GetMapping("/allocation/allocations/total")
    public long getTotalAllocations();

    @GetMapping("/allocation/allocations/count/{status}")
    public long getCountByStatus(@PathVariable("status") String status);


}
