package org.cts.housingaid.notificationservice.Client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Component
@FeignClient(name="application-service",configuration = FeignClientInterceptor.class)
public interface HousingApplicationClient {
    @GetMapping("/application/housing-application/count/status/{status}")
    public long getCountByStatus(@PathVariable("status") String status);

    @GetMapping("/application/housing-application/get-total-count")
    public long getTotalCount();
}
