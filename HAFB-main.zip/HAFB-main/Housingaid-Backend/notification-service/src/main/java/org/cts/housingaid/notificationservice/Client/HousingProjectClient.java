package org.cts.housingaid.notificationservice.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="INVENTORY-SERVICE",configuration = FeignClientInterceptor.class)
public interface HousingProjectClient {
    @GetMapping("/inventory/housing-project/count")
    public long getTotalProjects();

    @GetMapping("/inventory/housing-project/count/{status}")
    public long getCountByStatus(@PathVariable("status") String status);

    @GetMapping("/inventory/housing-project/budget/sum")
    public Double getTotalBudget();


}
