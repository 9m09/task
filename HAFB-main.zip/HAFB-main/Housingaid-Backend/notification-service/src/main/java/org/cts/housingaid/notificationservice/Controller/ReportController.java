package org.cts.housingaid.notificationservice.Controller;


import org.cts.housingaid.notificationservice.DTO.ReportDTO;
import org.cts.housingaid.notificationservice.ENUMS.ReportScope;
import org.cts.housingaid.notificationservice.Entity.Report;
import org.cts.housingaid.notificationservice.Service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@PreAuthorize("hasAnyRole('AUDITOR','ADMIN')")
@RequestMapping("/notification/reports")
//@CrossOrigin(origins = "*")
public class ReportController {

        @Autowired
        private ReportService service;

        @GetMapping("/generate/{scope}")
        public ResponseEntity<ReportDTO> generateReport(@PathVariable ReportScope scope) {
            Report report = service.generateReport(scope);
            return ResponseEntity.status(HttpStatus.CREATED).body(mapToDTO(report));
        }

        @GetMapping("/get-reportof-{id}")
        public ResponseEntity<Report> getOne(@PathVariable Long id) {
            return ResponseEntity.ok(service.getById(id));
        }

        @GetMapping("/get-all-reports")
        public List<ReportDTO> all() {

            return service.getAll().stream()
                    .map(this::mapToDTO)
                    .collect(Collectors.toList());
        }

        @DeleteMapping("/Delete-reportof-{id}")
        public ResponseEntity<String> delete(@PathVariable Long id){
            service.delete(id);
            return ResponseEntity.ok("Report deleted successfully");

    }
    private ReportDTO mapToDTO(Report report) {
        if (report == null) return null;

        ReportDTO dto = new ReportDTO();
         dto.setReportId(report.getReportId());
         dto.setScope(report.getScope());
         dto.setMetrics(report.getMetrics());
         dto.setGeneratedDate(report.getGeneratedDate());
         return dto;
    }


}