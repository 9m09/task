package org.cts.housingaid.notificationservice.DAO;

import org.cts.housingaid.notificationservice.Entity.Report;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReportRepository extends JpaRepository<Report, Long> {

}