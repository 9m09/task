package org.cts.housingaid.notificationservice.DTO;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cts.housingaid.notificationservice.ENUMS.ReportScope;

import java.time.LocalDateTime;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReportDTO {

    private Long reportId;
    private ReportScope scope;
    private String metrics;
    private LocalDateTime generatedDate;

}