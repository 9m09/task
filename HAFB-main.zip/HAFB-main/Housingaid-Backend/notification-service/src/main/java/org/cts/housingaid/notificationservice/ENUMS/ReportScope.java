package org.cts.housingaid.notificationservice.ENUMS;

public enum ReportScope {
    ALLOCATION,HOUSINGAPPLICATION,HOUSINGPROJECT

}