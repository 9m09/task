package org.cts.housingaid.notificationservice.Exception;

//import org.cts.housingaid.util.ExceptionConstants;

public class ReportNotFoundException extends RuntimeException {

    public ReportNotFoundException(String message) {
        super(message);
    }
}