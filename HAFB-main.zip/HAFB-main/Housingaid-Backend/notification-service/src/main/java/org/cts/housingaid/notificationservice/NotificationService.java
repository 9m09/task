package org.cts.housingaid.notificationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication(scanBasePackages = "org.cts")
@EnableFeignClients
@EnableDiscoveryClient
public class NotificationService {

    public static void main(String[] args) {

        SpringApplication.run(NotificationService.class, args);
        System.out.println("Notification Service started");
    }

}
