package org.cts.housingaid.notificationservice.Service;

//import org.cts.ENUMS.notificationservice.ReportScope;

//import java.util.List;

import org.cts.housingaid.notificationservice.ENUMS.ReportScope;
import org.cts.housingaid.notificationservice.Entity.Report;

import java.util.List;

public interface ReportService {


    Report generateReport(ReportScope scope);

    List<Report> getAll();

    Report getById(Long id);

    void delete(Long id);
}
