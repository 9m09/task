package org.cts.housingaid.notificationservice.ServiceImpl;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.cts.housingaid.notificationservice.Client.AllocationClient;
import org.cts.housingaid.notificationservice.Client.HousingApplicationClient;
import org.cts.housingaid.notificationservice.Client.HousingProjectClient;
import org.cts.housingaid.notificationservice.ENUMS.ReportScope;
import org.cts.housingaid.notificationservice.Entity.Report;
import org.cts.housingaid.notificationservice.Exception.ReportNotFoundException;
import org.cts.housingaid.notificationservice.Service.ReportService;
import org.cts.housingaid.notificationservice.DAO.ReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReportServiceImpl implements ReportService {


    private final HousingApplicationClient appClient;

    private final AllocationClient allocationClient;

    private final HousingProjectClient projectClient;

    private final ReportRepository reportRepo;

    @Override
    public Report generateReport(ReportScope scope) {
        StringBuilder metrics = new StringBuilder();

        try {
            switch (scope) {
                case HOUSINGAPPLICATION:
                    long totalApp = appClient.getTotalCount();
                    long approved = appClient.getCountByStatus("APPROVED");
                    long pending = appClient.getCountByStatus("PENDING");
                    long rejected = appClient.getCountByStatus("REJECTED");
                    long underreview =appClient.getCountByStatus("UNDERREVIEW");
                    metrics.append(String.format("Total Apps: %d | Approved: %d | Pending: %d | Rejected: %d | underreview: %d",
                            totalApp, approved, pending, rejected,underreview));
                    break;

                case ALLOCATION:
                    long totalAlloc = allocationClient.getTotalAllocations();
                    long allocated = allocationClient.getCountByStatus("ALLOCATED");
                    long notallocated = allocationClient.getCountByStatus("NOTALLOCATED");
                    metrics.append(String.format("Total Records: %d | Allocated: %d | NotAllocated: %d", totalAlloc, allocated, notallocated));
                    break;

                case HOUSINGPROJECT:
                    long totalProj = projectClient.getTotalProjects();
                    long progress = projectClient.getCountByStatus("UNDERPROGRESS");
                    long planned = projectClient.getCountByStatus("PLANNED");
                    long completed = projectClient.getCountByStatus("COMPLETED");
                    Double budget = projectClient.getTotalBudget();
                    metrics.append(String.format("Projects: %d | Under Progress: %d | planned: %d | completed: %d | Total Budget: %.2f",
                            totalProj, progress, planned, completed, budget != null ? budget : 0.0));
                    break;
            }
        } catch (Exception e) {
            // Fallback strategy: If a network call fails, we still save the report but note the error.
            metrics.append("Data temporarily unavailable due to downstream service timeout.");
        }

        Report report = new Report();
        report.setScope(scope);
        report.setMetrics(metrics.toString());
        report.setGeneratedDate(LocalDateTime.now());

        return reportRepo.save(report);
    }

    @Override
    public List<Report> getAll() {
        return reportRepo.findAll();
    }

    @Override
    public Report getById(Long id) {
        return reportRepo.findById(id)
                .orElseThrow(() -> new ReportNotFoundException("Report not found with ID: " + id));
    }

    @Override
    public void delete(Long id) {
        if (!reportRepo.existsById(id)) {
            throw new ReportNotFoundException("Delete failed: ID " + id + " does not exist.");
        }
        reportRepo.deleteById(id);
    }
} 