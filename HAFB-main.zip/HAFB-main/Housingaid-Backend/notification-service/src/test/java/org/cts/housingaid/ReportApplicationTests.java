package org.cts.housingaid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportApplicationTests {

    @Test
    void contextLoads() {
    }

}
