# HousingAid Project - Complete Documentation

**Date:** May 12, 2026  
**Project:** Affordable Housing Management System  
**Frontend Framework:** Angular 17+ (Standalone Components)  
**State Management:** Angular Signals  
**Authentication:** JWT Token-based

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Project Architecture & Structure](#project-architecture--structure)
3. [Tech Stack](#tech-stack)
4. [Application Startup Flow](#application-startup-flow)
5. [Authentication System](#authentication-system)
6. [Security Architecture](#security-architecture)
7. [Manager Module - In Depth](#manager-module---in-depth)
8. [Housing Units Module](#housing-units-module)
9. [Theme System (Dark/Light Mode)](#theme-system-darklight-mode)
10. [Complete User Flow](#complete-user-flow)
11. [Data Models](#data-models)
12. [Service Architecture](#service-architecture)

---

## Project Overview

### What is HousingAid?

HousingAid is a **government housing management system** that automates the process of:

- **Citizens** applying for affordable housing
- **Officers** reviewing applications and checking eligibility
- **Managers** managing housing projects and resources (funds, materials)
- **Admins** overseeing the whole system and managing users
- **Compliance teams** auditing and tracking everything
- **Auditors** generating reports on the housing allocation program

### User Roles

1. **CITIZEN** - Apply for housing, upload documents, track applications
2. **OFFICER** - Review applications, check eligibility, manage allocations
3. **MANAGER** - Create projects, manage resources and housing units
4. **ADMIN** - User management, workflow configuration, audit logs
5. **COMPLIANCE** - Track compliance records and conduct audits
6. **AUDITOR** - Generate reports and review programs

---

## Project Architecture & Structure

### Folder Structure

```
src/
  app/
    ├── core/                      # Core services, guards, interceptors
    │   ├── guards/
    │   │   └── auth.guard.ts      # Route protection
    │   ├── interceptors/
    │   │   └── auth.interceptor.ts # JWT attachment to requests
    │   ├── services/
    │   │   ├── api.services.ts    # All backend API calls
    │   │   ├── auth.service.ts    # Login, logout, token management
    │   │   ├── toast.service.ts   # Notifications
    │   │   └── theme.service.ts   # Dark/light mode
    │   ├── models/
    │   │   └── models.ts          # TypeScript interfaces
    │   └── utils/
    │       └── jwt-decode.ts      # JWT decoding utility
    │
    ├── features/                   # Feature modules (role-specific)
    │   ├── auth/
    │   │   └── home.component.ts  # Login & Register page
    │   ├── admin/                 # Admin pages
    │   ├── citizen/               # Citizen pages
    │   ├── officer/               # Officer pages
    │   ├── manager/               # Manager pages (Projects, Resources)
    │   ├── allocation/            # Allocation pages
    │   ├── compliance/            # Compliance pages
    │   ├── auditor/               # Auditor pages
    │   ├── dashboard/             # Dashboard page
    │   └── layout/                # Dashboard layout (sidebar, topbar)
    │
    ├── shared/                     # Reusable components
    │   └── components/
    │       ├── status-badge.component.ts
    │       └── toast-container.component.ts
    │
    ├── app.component.ts           # Root component
    ├── app.routes.ts              # Route definitions
    └── app.config.ts              # App configuration
  │
  ├── environments/
  │   └── environment.ts           # API endpoint configuration
  │
  ├── styles.css                   # Global styles (dark + light themes)
  ├── main.ts                      # Bootstrap entry point
  └── index.html                   # HTML template

```

---

## Tech Stack

### Frontend Technologies

| Technology | Purpose |
|---|---|
| **Angular 17+** | Frontend framework with standalone components |
| **RxJS** | Reactive programming for async operations |
| **Angular Signals** | Reactive state management (replaces BehaviorSubject) |
| **TypeScript** | Type-safe JavaScript |
| **FormsModule** | Two-way data binding with `[(ngModel)]` |
| **CommonModule** | Structural directives (`*ngIf`, `*ngFor`) |
| **HttpClient** | HTTP requests to backend |

### Key Features

- **Standalone Components** - No NgModules needed
- **Lazy Loading** - Routes loaded on demand
- **JWT Authentication** - Secure token-based auth
- **Role-Based Access Control** - Different menus per role
- **Dark/Light Theme** - CSS variables for theming
- **Session Persistence** - localStorage/sessionStorage for tokens
- **HTTP Interceptor** - Automatic JWT attachment to requests
- **Route Guards** - Protection for dashboard routes

---

## Application Startup Flow

### Step 1: Browser loads the app

**File:** `src/index.html`

```html
<!doctype html>
<html lang="en">
  <head>
    <title>HousingAid — Affordable Housing Management</title>
    <base href="/">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&..." rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="favicon.ico">
  </head>
  <body>
    <app-root></app-root>  <!-- Angular will replace this with root component -->
  </body>
</html>
```

**What happens:**
- Browser loads `index.html`
- `<app-root></app-root>` is a placeholder element
- Angular will dynamically render the root component here

---

### Step 2: Angular bootstraps

**File:** `src/main.ts`

```typescript
import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';

bootstrapApplication(AppComponent, appConfig)
  .catch((err) => console.error(err));
```

**What happens:**
- `bootstrapApplication()` initializes Angular
- Loads `AppComponent` as the root component
- Applies `appConfig` which contains:
  - Route definitions
  - HTTP client configuration
  - HTTP interceptors
  - Dependency injection providers

---

### Step 3: Root component initializes

**File:** `src/app/app.component.ts`

```typescript
import { Component, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ToastContainerComponent } from './shared/components/toast-container.component';
import { ThemeService } from './core/services/theme.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, ToastContainerComponent],
  template: `
    <router-outlet />
    <app-toast-container />
  `
})
export class AppComponent {
  private themeService = inject(ThemeService);  // Load theme preference
}
```

**What happens:**
- `ThemeService` is injected (loads user's dark/light preference from localStorage)
- `<router-outlet />` is where page content will be rendered
- `<app-toast-container />` displays notification messages

---

### Step 4: Router evaluates URL and decides which component to load

**File:** `src/app/app.routes.ts`

```typescript
export const routes: Routes = [
  {
    path: '',  // Root path: http://localhost:4200/
    loadComponent: () => import('./features/auth/home.component').then(m => m.HomeComponent)
    // ↑ Loads login/register page for unauthenticated users
  },
  {
    path: 'dashboard',  // Protected path: http://localhost:4200/dashboard
    canActivate: [authGuard],  // ← Security check: must be logged in
    loadComponent: () => import('./features/layout/layout.component').then(m => m.LayoutComponent),
    children: [
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      { path: 'home', loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent) },

      // Citizen routes
      { path: 'citizen-apply', loadComponent: () => import('./features/citizen/citizen-apply.component').then(m => m.CitizenApplyComponent) },
      { path: 'citizen-docs', loadComponent: () => import('./features/citizen/citizen-docs.component').then(m => m.CitizenDocsComponent) },
      { path: 'citizen-track', loadComponent: () => import('./features/citizen/citizen-track.component').then(m => m.CitizenTrackComponent) },
      { path: 'citizen-profile', loadComponent: () => import('./features/citizen/citizen-profile.component').then(m => m.CitizenProfileComponent) },

      // Officer routes
      { path: 'officer-applications', loadComponent: () => import('./features/officer/officer-applications.component').then(m => m.OfficerApplicationsComponent) },
      { path: 'officer-eligibility/:applicationId', loadComponent: () => import('./features/officer/officer-eligibility.component').then(m => m.OfficerEligibilityComponent) },
      { path: 'officer-eligibility', loadComponent: () => import('./features/officer/officer-eligibility.component').then(m => m.OfficerEligibilityComponent) },
      { path: 'officer-units', loadComponent: () => import('./features/officer/officer-units.component').then(m => m.OfficerUnitsComponent) },

      // Manager routes
      { path: 'manager-projects', loadComponent: () => import('./features/manager/manager-projects.component').then(m => m.ManagerProjectsComponent) },
      { path: 'manager-resources', loadComponent: () => import('./features/manager/manager-resources.component').then(m => m.ManagerResourcesComponent) },
      { path: 'manager-units', loadComponent: () => import('./features/officer/officer-units.component').then(m => m.OfficerUnitsComponent) },

      // Allocation routes
      { path: 'allocation-allocate', loadComponent: () => import('./features/allocation/allocation-allocate.component').then(m => m.AllocationAllocateComponent) },
      { path: 'allocation-finalize/:applicationId', loadComponent: () => import('./features/allocation/allocation-finalize.component').then(m => m.AllocationFinalizeComponent) },
      { path: 'allocation-table', loadComponent: () => import('./features/allocation/allocation-table.component').then(m => m.AllocationTableComponent) },

      // Compliance routes
      { path: 'compliance-records', loadComponent: () => import('./features/compliance/compliance-records.component').then(m => m.ComplianceRecordsComponent) },
      { path: 'compliance-audits', loadComponent: () => import('./features/compliance/compliance-audits.component').then(m => m.ComplianceAuditsComponent) },
      { path: 'compliance-new-audit', loadComponent: () => import('./features/compliance/compliance-new-audit.component').then(m => m.ComplianceNewAuditComponent) },

      // Auditor routes
      { path: 'auditor-reports', loadComponent: () => import('./features/auditor/auditor-reports.component').then(m => m.AuditorReportsComponent) },
      { path: 'auditor-review', loadComponent: () => import('./features/auditor/auditor-review.component').then(m => m.AuditorReviewComponent) },

      // Admin routes
      { path: 'admin-users', loadComponent: () => import('./features/admin/admin-users.component').then(m => m.AdminUsersComponent) },
      { path: 'admin-logs', loadComponent: () => import('./features/admin/admin-logs.component').then(m => m.AdminLogsComponent) },
      { path: 'admin-workflows', loadComponent: () => import('./features/admin/admin-workflows.component').then(m => m.AdminWorkflowsComponent) },
    ]
  },
  { path: '**', redirectTo: '' }  // Catch-all: unknown routes redirect to home
];
```

**Decision tree:**

```
App starts
  ↓
Check current URL path
  ├─ path = '' (root, /)
  │  └─ Load HomeComponent (login page)
  │
  ├─ path = '/dashboard/...' (protected)
  │  └─ Check authGuard
  │     ├─ User has valid token? 
  │     │  ├─ YES → Load LayoutComponent + child route
  │     │  └─ NO  → Redirect to / (login)
  │     └─ Child routes map to feature pages
  │
  └─ path = unknown
     └─ Redirect to / (home)
```

---

## Authentication System

### Overview

Authentication in HousingAid consists of 4 layers:

1. **Login/Register UI** - User interface for credentials
2. **Auth Service** - Token management and user state
3. **Route Guard** - Protect dashboard routes
4. **HTTP Interceptor** - Attach JWT to all requests

---

### Layer 1: Login & Register Page

**File:** `src/app/features/auth/home.component.ts`

```typescript
@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="home-page">
      <!-- Header with theme toggle -->
      <nav class="home-nav">
        <div class="home-logo">
          <div class="home-logo-icon">🏠</div>
          HousingAid
        </div>
        <button class="btn btn-ghost btn-sm" (click)="toggleTheme()">
          {{ theme() === 'dark' ? '☀️ Light Mode' : '🌙 Dark Mode' }}
        </button>
      </nav>

      <!-- Auth card with tabs -->
      <div class="auth-card-wrapper">
        <div class="auth-tabs">
          <button class="auth-tab" [class.active]="activeTab==='login'" (click)="activeTab='login'">Login</button>
          <button class="auth-tab" [class.active]="activeTab==='register'" (click)="activeTab='register'">Register</button>
        </div>

        <!-- LOGIN FORM -->
        <div *ngIf="activeTab === 'login'">
          <div class="form-group">
            <label class="form-label">Email</label>
            <input class="form-input" type="email" [(ngModel)]="loginEmail" placeholder="officer@housingaid.gov" />
          </div>
          <div class="form-group">
            <label class="form-label">Password</label>
            <input class="form-input" type="password" [(ngModel)]="loginPassword" placeholder="••••••••"
                   (keydown.enter)="handleLogin()" />
          </div>
          <button class="btn btn-primary w-full" (click)="handleLogin()" [disabled]="loading()">
            {{ loading() ? 'Signing in...' : 'Sign In' }}
          </button>
        </div>

        <!-- REGISTER FORM -->
        <div *ngIf="activeTab === 'register'">
          <div class="form-group">
            <label class="form-label">Full Name</label>
            <input class="form-input" [(ngModel)]="reg.userName" placeholder="Arjun Mehta" />
          </div>
          <div class="form-group">
            <label class="form-label">Email</label>
            <input class="form-input" type="email" [(ngModel)]="reg.userEmail" placeholder="arjun@example.com" />
          </div>
          <div class="form-group">
            <label class="form-label">Password</label>
            <input class="form-input" type="password" [(ngModel)]="reg.userPassword" placeholder="Min 8 characters" />
          </div>
          <div class="form-group">
            <label class="form-label">Gender</label>
            <select class="form-select" [(ngModel)]="reg.citizenGender">
              <option value="MALE">Male</option>
              <option value="FEMALE">Female</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Contact Info</label>
            <input class="form-input" [(ngModel)]="reg.citizenContactInfo" placeholder="+91 98765 43210" />
          </div>
          <div class="form-group">
            <label class="form-label">Address</label>
            <input class="form-input" [(ngModel)]="reg.citizenAddress" placeholder="123 Main Street, City" />
          </div>
          <div class="form-group">
            <label class="form-label">Date of Birth</label>
            <input class="form-input" type="date" [(ngModel)]="reg.citizenDOB" />
          </div>
          <button class="btn btn-primary w-full" (click)="handleRegister()" [disabled]="loading()">
            {{ loading() ? 'Registering...' : 'Create Account' }}
          </button>
        </div>
      </div>
    </div>
  `
})
export class HomeComponent {
  private auth = inject(AuthService);
  private router = inject(Router);
  private toast = inject(ToastService);
  private themeService = inject(ThemeService);

  theme = this.themeService.theme;
  activeTab: 'login' | 'register' = 'login';
  loading = signal(false);

  loginEmail = '';
  loginPassword = '';

  reg = {
    userName: '',
    userEmail: '',
    userPassword: '',
    citizenContactInfo: '',
    citizenAddress: '',
    citizenDOB: '',
    citizenGender: 'MALE' as any
  };

  toggleTheme(): void {
    this.themeService.toggle();
  }

  handleLogin(): void {
    // Validate inputs
    if (!this.loginEmail || !this.loginPassword) {
      this.toast.error('Please enter email and password');
      return;
    }

    // Show loading state
    this.loading.set(true);

    // Call auth service
    this.auth.login({ email: this.loginEmail, password: this.loginPassword }).subscribe({
      next: () => {
        // Success
        this.toast.success('Welcome back!');
        this.router.navigate(['/dashboard']);
      },
      error: (e) => {
        // Error
        this.toast.error(e.error?.message || 'Invalid credentials');
        this.loading.set(false);
      }
    });
  }

  handleRegister(): void {
    // Extract form values
    const { userName, userEmail, userPassword, citizenContactInfo, citizenAddress, citizenDOB, citizenGender } = this.reg;

    // Validate required fields
    if (!userName || !userEmail || !userPassword || !citizenAddress || !citizenDOB) {
      this.toast.error('Please fill all required fields');
      return;
    }

    // Show loading state
    this.loading.set(true);

    // Call auth service
    this.auth.registerCitizen({ userName, userEmail, userPassword, citizenContactInfo, citizenAddress, citizenDOB, citizenGender }).subscribe({
      next: () => {
        // Success
        this.toast.success('Account created! Please log in.');
        this.activeTab = 'login';  // Switch to login tab
        this.loading.set(false);
      },
      error: (e) => {
        // Error
        this.toast.error(e.error?.message || 'Registration failed');
        this.loading.set(false);
      }
    });
  }
}
```

**Key points:**
- `[(ngModel)]` binds form inputs to component state
- `activeTab` controls which form is visible
- `loading` signal shows spinner and disables button
- Form validation before API calls
- Error/success toasts for user feedback

---

### Layer 2: Auth Service

**File:** `src/app/core/services/auth.service.ts`

```typescript
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { AppUser, LoginRequest, LoginResponse, CitizenRegistrationDTO, UsersCreateDTO } from '../models/models';
import { jwtDecode } from '../utils/jwt-decode';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly BASE = `${environment.apiUrl}/auths/auth`;
  private _user = new BehaviorSubject<AppUser | null>(this.loadUser());
  user$ = this._user.asObservable();

  constructor(private http: HttpClient, private router: Router) {}

  // ============ GETTERS ============
  get currentUser(): AppUser | null { 
    return this._user.value; 
  }

  get token(): string | null { 
    return this._user.value?.token ?? null; 
  }

  get isLoggedIn(): boolean { 
    return !!this._user.value; 
  }

  // ============ LOGIN ============
  login(req: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.BASE}/login`, req).pipe(
      tap(res => {
        // Step 1: Decode JWT to extract user info
        const decoded = jwtDecode(res.token);
        
        // Step 2: Extract role, removing "ROLE_" prefix from backend
        const role = decoded?.role?.replace('ROLE_', '') as any;
        
        // Step 3: Extract email (with fallback chain)
        const email = decoded?.email ?? decoded?.sub ?? req.email;
        
        // Step 4: Extract name (with fallback chain)
        const name = decoded?.userName ?? decoded?.name ?? decoded?.given_name ?? decoded?.preferred_username ?? decoded?.sub;
        
        // Step 5: Create user object
        const user: AppUser = {
          token: res.token,
          role,
          email,
          name,
          userId: decoded?.userId
        };
        
        // Step 6: Save to sessionStorage (persists until browser tab closes)
        sessionStorage.setItem('ha_user', JSON.stringify(user));
        
        // Step 7: Update app state (so all components know user is logged in)
        this._user.next(user);
      })
    );
  }

  // ============ REGISTER ============
  registerCitizen(dto: CitizenRegistrationDTO): Observable<CitizenRegistrationDTO> {
    return this.http.post<CitizenRegistrationDTO>(`${this.BASE}/register-citizen`, dto);
  }

  registerUser(dto: UsersCreateDTO): Observable<string> {
    return this.http.post(`${this.BASE}/register`, dto, { responseType: 'text' });
  }

  // ============ LOGOUT ============
  logout(): void {
    // Step 1: Remove token from storage
    sessionStorage.removeItem('ha_user');
    
    // Step 2: Clear app state
    this._user.next(null);
    
    // Step 3: Redirect to login page
    this.router.navigate(['/']);
  }

  // ============ HELPERS ============
  private loadUser(): AppUser | null {
    try {
      // Try to load user from sessionStorage
      const raw = sessionStorage.getItem('ha_user');
      return raw ? JSON.parse(raw) : null;
    } catch {
      // If parsing fails, return null
      return null;
    }
  }
}
```

**Key points:**
- `_user` is a BehaviorSubject that holds the current user
- `loadUser()` restores session on page refresh
- `login()` decodes JWT and saves user to sessionStorage
- `registerCitizen()` creates a new user account
- `logout()` clears everything and redirects to login

---

### Layer 3: Route Guard

**File:** `src/app/core/guards/auth.guard.ts`

```typescript
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  // Check if user is logged in
  if (auth.isLoggedIn) {
    return true;  // Allow navigation
  }

  // Not logged in, redirect to login page
  router.navigate(['/']);
  return false;  // Block navigation
};
```

**What it does:**
- Applied to `/dashboard` route: `canActivate: [authGuard]`
- Checks if `auth.isLoggedIn` is true
- If yes: navigation proceeds
- If no: user is redirected to `/` (login page)

---

### Layer 4: HTTP Interceptor

**File:** `src/app/core/interceptors/auth.interceptor.ts`

```typescript
import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const token = auth.token;

  // If token exists, add it to request header
  if (token) {
    req = req.clone({ 
      setHeaders: { 
        Authorization: `Bearer ${token}` 
      } 
    });
  }

  // Send request to backend
  return next(req);
};
```

**What it does:**
- Runs on EVERY HTTP request
- Checks if JWT token exists
- If yes: adds `Authorization: Bearer <token>` header
- Means all API services automatically send the token without extra code

---

## Security Architecture

### Complete Security Flow

```
┌─────────────────────────────────────────────────────────────┐
│                   AUTHENTICATION FLOW                       │
└─────────────────────────────────────────────────────────────┘

1. USER LOGS IN
   ├─ Enters email/password in LoginComponent
   ├─ Clicks "Sign In"
   └─ handleLogin() validates and calls AuthService.login()

2. AUTH SERVICE SENDS CREDENTIALS
   ├─ POST /auths/auth/login { email, password }
   ├─ Backend validates credentials
   ├─ Backend generates JWT token if valid
   └─ Returns { token: "eyJhbGc..." }

3. JWT DECODED & USER EXTRACTED
   ├─ jwtDecode(token) extracts payload
   ├─ Payload contains: { role: "OFFICER", email: "...", userId: 123 }
   └─ Create AppUser object with extracted data

4. TOKEN STORED IN SESSION
   ├─ sessionStorage.setItem('ha_user', JSON.stringify(user))
   ├─ Persists until browser tab closes
   └─ Can be restored on page refresh via loadUser()

5. ROUTE GUARD PROTECTS DASHBOARD
   ├─ User navigates to /dashboard
   ├─ authGuard runs: if (auth.isLoggedIn) return true
   ├─ isLoggedIn checks if _user.value exists
   └─ YES → Dashboard loads, NO → Redirect to login

6. HTTP INTERCEPTOR ATTACHES TOKEN
   ├─ Component calls API service (e.g., HousingProjectService)
   ├─ API service calls this.http.get(...)
   ├─ authInterceptor runs automatically
   ├─ Gets token from AuthService
   ├─ Clones request with Authorization header
   └─ Sends to backend with header: "Authorization: Bearer <token>"

7. BACKEND VALIDATES TOKEN
   ├─ Backend receives request with JWT header
   ├─ Backend validates JWT signature
   ├─ Backend extracts user info from token
   ├─ Backend checks user's role
   ├─ Backend processes request (if authorized)
   └─ Returns response

8. LOGOUT CLEARS EVERYTHING
   ├─ User clicks "Sign Out"
   ├─ logout() removes token from sessionStorage
   ├─ logout() clears _user state
   ├─ logout() redirects to /
   └─ All stored data cleared
```

### Why This is Secure

| Layer | Security Mechanism | Benefit |
|---|---|---|
| **JWT Token** | Server-signed, cannot be forged | Verifies user identity |
| **HTTPS (in production)** | Encrypted transport | Token not intercepted in transit |
| **sessionStorage** | Cleared on browser close | Token not persistent after logout |
| **authGuard** | Route protection | Prevents unauthorized access to dashboard |
| **authInterceptor** | Automatic token attachment | Developer can't forget to send token |
| **Backend validation** | Token signature + role check | Ensures only authorized users access resources |

---

## Manager Module - In Depth

### Overview

The manager module allows managers to:
- Create and manage housing projects
- Manage resources (funds and materials)
- Track project budgets and timelines
- Manage housing units

### 1. Manager Projects Component

**File:** `src/app/features/manager/manager-projects.component.ts`

#### Imports

```typescript
import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HousingProjectService } from '../../core/services/api.services';
import { ToastService } from '../../core/services/toast.service';
import { HousingProjectDTO } from '../../core/models/models';
import { StatusBadgeComponent } from '../../shared/components/status-badge.component';
```

- `signal` - reactive state management
- `HousingProjectService` - API calls for projects
- `ToastService` - notifications
- `HousingProjectDTO` - TypeScript type for a project
- `StatusBadgeComponent` - reusable badge component

#### Component Class

```typescript
@Component({
  selector: 'app-manager-projects',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <!-- PAGE HEADER -->
      <div class="page-header">
        <h1>Housing Projects</h1>
        <p>Create and manage housing development projects</p>
        <button class="btn btn-primary" (click)="showForm = !showForm">
          {{ showForm ? '✕ Cancel' : '+ New Project' }}
        </button>
      </div>

      <!-- STATS ROW -->
      <div class="grid-3 mb-4">
        <div class="stat-card amber">
          <div class="stat-icon">🏗</div>
          <div class="stat-value">{{ total() }}</div>
          <div class="stat-label">Total Projects</div>
        </div>
        <div class="stat-card green">
          <div class="stat-icon">💰</div>
          <div class="stat-value">₹{{ (budget() / 1e6).toFixed(1) }}M</div>
          <div class="stat-label">Total Budget</div>
        </div>
        <div class="stat-card blue">
          <div class="stat-icon">🔨</div>
          <div class="stat-value">{{ inProgress() }}</div>
          <div class="stat-label">In Progress</div>
        </div>
      </div>

      <!-- CREATE/EDIT FORM -->
      <div class="card mb-4" *ngIf="showForm">
        <div class="card-title">
          {{ editingId ? 'Update Project' : 'New Housing Project' }}
        </div>
        
        <div class="form-group">
          <label class="form-label">Project Title</label>
          <input class="form-input" 
                 [(ngModel)]="form.housingProjectTitle" 
                 placeholder="Affordable Housing Scheme Phase 1" />
        </div>

        <div class="form-group">
          <label class="form-label">Description</label>
          <textarea class="form-textarea" 
                    [(ngModel)]="form.housingProjectDescription" 
                    placeholder="Project description…"></textarea>
        </div>

        <div class="grid-2">
          <div class="form-group">
            <label class="form-label">Number of Houses</label>
            <input class="form-input" type="number" 
                   [(ngModel)]="form.numberOfHouses" min="1" />
          </div>
          <div class="form-group">
            <label class="form-label">Budget (₹)</label>
            <input class="form-input" type="number" 
                   [(ngModel)]="form.housingProjectBudget" min="1" />
          </div>
        </div>

        <div class="grid-2">
          <div class="form-group">
            <label class="form-label">Start Date</label>
            <input class="form-input" type="date" 
                   [(ngModel)]="form.housingProjectStartDate" />
          </div>
          <div class="form-group">
            <label class="form-label">End Date</label>
            <input class="form-input" type="date" 
                   [(ngModel)]="form.housingProjectEndDate" />
          </div>
        </div>

        <div class="form-group">
          <label class="form-label">Status</label>
          <select class="form-select" [(ngModel)]="form.housingProjectStatus">
            <option value="PLANNED">Planned</option>
            <option value="UNDERPROGRESS">Under Progress</option>
            <option value="COMPLETED">Completed</option>
          </select>
        </div>

        <div class="modal-footer">
          <button class="btn btn-ghost" (click)="cancelEdit()">Cancel</button>
          <button class="btn btn-primary" (click)="save()" [disabled]="saving()">
            <span *ngIf="saving()" class="spinner"></span>
            {{ saving() ? 'Saving...' : (editingId ? 'Update' : 'Create Project') }}
          </button>
        </div>
      </div>

      <!-- SEARCH -->
      <div class="search-bar mb-4">
        <input class="search-input" 
               [(ngModel)]="searchTitle" 
               placeholder="Search by title…" 
               (input)="filterProjects()" />
        <button class="btn btn-ghost" (click)="load()">↻ Refresh</button>
      </div>

      <!-- PROJECTS LIST -->
      <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
      <div *ngIf="!loading() && filtered().length === 0" class="empty-state">
        <div class="empty-state-icon">🏗</div>
        <p>No projects found</p>
      </div>

      <div *ngIf="!loading()" style="display:flex;flex-direction:column;gap:12px">
        <div *ngFor="let p of filtered()" class="card">
          <div style="display:flex;justify-content:space-between;align-items:flex-start">
            <div style="flex:1">
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
                <span style="font-family:var(--font-mono);font-size:11px;color:var(--text3)">#{{ p.housingProjectId }}</span>
                <app-status-badge [status]="p.housingProjectStatus" />
              </div>
              <div style="font-family:var(--font-head);font-size:16px;font-weight:700;margin-bottom:4px">
                {{ p.housingProjectTitle }}
              </div>
              <div style="font-size:12px;color:var(--text2);max-width:600px">
                {{ p.housingProjectDescription }}
              </div>
            </div>
            <button class="btn btn-ghost btn-sm" (click)="startEdit(p)">✏ Edit</button>
          </div>

          <div style="display:flex;gap:32px;margin-top:16px;padding-top:12px;border-top:1px solid var(--border)">
            <div class="info-row">
              <span class="info-label">Houses</span>
              <span class="info-value">{{ p.numberOfHouses }}</span>
            </div>
            <div class="info-row">
              <span class="info-label">Budget</span>
              <span class="info-value">₹{{ p.housingProjectBudget.toLocaleString() }}</span>
            </div>
            <div class="info-row">
              <span class="info-label">Start</span>
              <span class="info-value">{{ p.housingProjectStartDate }}</span>
            </div>
            <div class="info-row">
              <span class="info-label">End</span>
              <span class="info-value">{{ p.housingProjectEndDate }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ManagerProjectsComponent implements OnInit {
  private projectSvc = inject(HousingProjectService);
  private toast = inject(ToastService);

  // ============ STATE ============
  loading = signal(true);
  saving = signal(false);
  all = signal<HousingProjectDTO[]>([]);
  filtered = signal<HousingProjectDTO[]>([]);
  total = signal(0);
  budget = signal(0);
  inProgress = signal(0);
  showForm = false;
  searchTitle = '';
  editingId: number | null = null;

  form: HousingProjectDTO = this.blankForm();

  // ============ DEFAULT FORM FACTORY ============
  blankForm(): HousingProjectDTO {
    return {
      numberOfHouses: 10,
      housingProjectTitle: '',
      housingProjectDescription: '',
      housingProjectStartDate: new Date().toISOString().slice(0,10),
      housingProjectEndDate: '',
      housingProjectBudget: 1000000,
      housingProjectStatus: 'PLANNED'
    };
  }

  // ============ LIFECYCLE ============
  ngOnInit(): void {
    this.load();
    this.loadStats();
  }

  // ============ LOAD DATA ============
  load(): void {
    this.loading.set(true);
    this.projectSvc.getAll().subscribe({
      next: p => {
        this.all.set(p);
        this.filtered.set(p);
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  loadStats(): void {
    this.projectSvc.getTotalCount().subscribe(n => this.total.set(n));
    this.projectSvc.getTotalBudget().subscribe(b => this.budget.set(b ?? 0));
    this.projectSvc.getCountByStatus('UNDERPROGRESS').subscribe(n => this.inProgress.set(n));
  }

  // ============ SEARCH ============
  filterProjects(): void {
    const q = this.searchTitle.toLowerCase();
    this.filtered.set(this.all().filter(p => 
      p.housingProjectTitle.toLowerCase().includes(q)
    ));
  }

  // ============ EDIT ============
  startEdit(p: HousingProjectDTO): void {
    this.editingId = p.housingProjectId ?? null;
    this.form = { ...p };  // Copy project into form
    this.showForm = true;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  cancelEdit(): void {
    this.editingId = null;
    this.form = this.blankForm();
    this.showForm = false;
  }

  // ============ SAVE ============
  save(): void {
    // Validate required fields
    if (!this.form.housingProjectTitle || !this.form.housingProjectEndDate) {
      this.toast.error('Please fill all required fields');
      return;
    }

    this.saving.set(true);

    // Choose between create or update
    const req = this.editingId
      ? this.projectSvc.update(this.editingId, this.form)
      : this.projectSvc.create(this.form);

    req.subscribe({
      next: () => {
        this.toast.success(this.editingId ? 'Project updated!' : 'Project created!');
        this.cancelEdit();
        this.load();          // Refresh list
        this.loadStats();     // Refresh stats
        this.saving.set(false);
      },
      error: (e) => {
        this.toast.error(e.error?.message || 'Save failed');
        this.saving.set(false);
      }
    });
  }
}
```

#### Key State Signals

| Signal | Type | Purpose |
|---|---|---|
| `loading` | boolean | Shows spinner while fetching data |
| `saving` | boolean | Shows spinner while creating/updating |
| `all` | HousingProjectDTO[] | Complete list of projects |
| `filtered` | HousingProjectDTO[] | Filtered list after search |
| `total` | number | Total number of projects |
| `budget` | number | Total budget sum |
| `inProgress` | number | Count of in-progress projects |

#### Key Methods

| Method | What it does |
|---|---|
| `ngOnInit()` | Load data on component mount |
| `load()` | Fetch all projects from backend |
| `loadStats()` | Fetch project statistics |
| `filterProjects()` | Local search filter |
| `startEdit()` | Open form for editing |
| `cancelEdit()` | Close form and reset |
| `save()` | Create or update project |

---

### 2. Housing Projects API Service

**File:** `src/app/core/services/api.services.ts` (excerpt)

```typescript
@Injectable({ providedIn: 'root' })
export class HousingProjectService {
  private base = `${API}/inventory/housing-project`;
  constructor(private http: HttpClient) {}

  // Get all projects
  getAll(): Observable<HousingProjectDTO[]> {
    return this.http.get<HousingProjectDTO[]>(`${this.base}/get-all-housing-projects`);
  }

  // Create new project
  create(dto: HousingProjectDTO): Observable<string> {
    return this.http.post(`${this.base}/create-housing-project`, dto, { responseType: 'text' });
  }

  // Update existing project
  update(id: number, dto: HousingProjectDTO): Observable<string> {
    return this.http.put(`${this.base}/update-housing-project/${id}`, dto, { responseType: 'text' });
  }

  // Search projects
  search(id?: number, title?: string): Observable<HousingProjectDTO[]> {
    let params = new HttpParams();
    if (id) params = params.set('housingProjectId', id);
    if (title) params = params.set('housingProjectTitle', title);
    return this.http.get<HousingProjectDTO[]>(`${this.base}/search-housing-project`, { params });
  }

  // Get total count
  getTotalCount(): Observable<number> {
    return this.http.get<number>(`${this.base}/count`);
  }

  // Get count by status
  getCountByStatus(status: string): Observable<number> {
    return this.http.get<number>(`${this.base}/count/${status}`);
  }

  // Get total budget
  getTotalBudget(): Observable<number> {
    return this.http.get<number>(`${this.base}/budget/sum`);
  }

  // Get project by ID
  getById(id: number): Observable<HousingProjectDTO> {
    return this.http.get<HousingProjectDTO>(`${this.base}/get-housing-project/${id}`);
  }

  // Get active projects only
  getActiveProjects(): Observable<HousingProjectDTO[]> {
    return this.http.get<HousingProjectDTO[]>(`${this.base}/get-active-housing-projects`);
  }

  // Check if project is available
  checkAvailability(id: number): Observable<boolean> {
    return this.http.get<boolean>(`${this.base}/check-available`, { params: { housingProjectId: id } });
  }
}
```

---

## Housing Units Module

### Overview

The housing units component allows managers and officers to:
- Browse all housing units
- Create new units
- Manage unit status (Available → Allocated → Maintenance)
- Link units to projects and resources

**File:** `src/app/features/officer/officer-units.component.ts`

```typescript
@Component({
  selector: 'app-officer-units',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <div class="page-header">
        <h1>Housing Units</h1>
        <p>Browse and manage individual housing units</p>
        <button class="btn btn-primary" (click)="showForm = !showForm">
          {{ showForm ? '✕ Cancel' : '+ Add Unit' }}
        </button>
      </div>

      <!-- Add unit form -->
      <div class="card mb-4" *ngIf="showForm">
        <div class="card-title">New Housing Unit</div>
        
        <div class="grid-2">
          <div class="form-group">
            <label class="form-label">Location</label>
            <input class="form-input" [(ngModel)]="form.housingUnitLocation" placeholder="Block A, City" />
          </div>
          <div class="form-group">
            <label class="form-label">Type</label>
            <select class="form-select" [(ngModel)]="form.housingUnitType">
              <option value="APARTMENT">Apartment</option>
              <option value="SHELTER">Shelter</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Capacity</label>
            <input class="form-input" type="number" [(ngModel)]="form.housingUnitCapacity" min="1" />
          </div>
          <div class="form-group">
            <label class="form-label">Status</label>
            <select class="form-select" [(ngModel)]="form.housingUnitStatus">
              <option value="AVAILABLE">Available</option>
              <option value="ALLOCATED">Allocated</option>
              <option value="MAINTENANCE">Maintenance</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Resource ID</label>
            <input class="form-input" type="number" [(ngModel)]="form.resourcesId" />
          </div>
          <div class="form-group">
            <label class="form-label">Project ID</label>
            <input class="form-input" type="number" [(ngModel)]="form.housingProjectId" />
          </div>
        </div>

        <button class="btn btn-primary" (click)="createUnit()" [disabled]="saving()">
          {{ saving() ? 'Saving...' : 'Create Unit' }}
        </button>
      </div>

      <!-- Search filters -->
      <div class="search-bar mb-4">
        <input class="search-input" [(ngModel)]="searchLocation" placeholder="Filter by location…" />
        <select class="form-select" style="width:160px" [(ngModel)]="searchType">
          <option value="">All Types</option>
          <option value="APARTMENT">Apartment</option>
          <option value="SHELTER">Shelter</option>
        </select>
        <button class="btn btn-ghost" (click)="searchUnits()">Search</button>
        <button class="btn btn-ghost" (click)="load()">↻ Reset</button>
      </div>

      <!-- Units grid -->
      <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
      <div *ngIf="!loading() && units().length === 0" class="empty-state">
        <div class="empty-state-icon">🏠</div>
        <p>No housing units found</p>
      </div>

      <div class="grid-3" *ngIf="!loading() && units().length > 0">
        <div *ngFor="let u of units()" class="card">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
            <div>
              <div style="font-family:var(--font-mono);font-size:11px;color:var(--text3)">#{{ u.housingUnitId }}</div>
              <div style="font-weight:600;font-size:14px;margin-top:2px">{{ u.housingUnitType }}</div>
            </div>
            <app-status-badge [status]="u.housingUnitStatus" />
          </div>

          <div class="info-grid">
            <div class="info-row">
              <span class="info-label">Location</span>
              <span class="info-value">{{ u.housingUnitLocation }}</span>
            </div>
            <div class="info-row">
              <span class="info-label">Capacity</span>
              <span class="info-value">{{ u.housingUnitCapacity }} persons</span>
            </div>
            <div class="info-row">
              <span class="info-label">Project</span>
              <span class="info-value">#{{ u.housingProjectId }}</span>
            </div>
            <div class="info-row">
              <span class="info-label">Resource</span>
              <span class="info-value">#{{ u.resourcesId }}</span>
            </div>
          </div>

          <div style="margin-top:12px;display:flex;gap:6px">
            <select class="form-select" style="flex:1;font-size:12px;padding:5px 8px" [(ngModel)]="u.housingUnitStatus">
              <option value="AVAILABLE">Available</option>
              <option value="ALLOCATED">Allocated</option>
              <option value="MAINTENANCE">Maintenance</option>
            </select>
            <button class="btn btn-ghost btn-sm" (click)="updateStatus(u)">Update</button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class OfficerUnitsComponent implements OnInit {
  private unitSvc = inject(HousingUnitService);
  private toast = inject(ToastService);

  loading = signal(true);
  saving = signal(false);
  units = signal<HousingUnitDTO[]>([]);
  showForm = false;
  searchLocation = '';
  searchType = '';

  form: HousingUnitDTO = {
    housingUnitLocation: '',
    housingUnitType: 'APARTMENT',
    housingUnitCapacity: 1,
    housingUnitStatus: 'AVAILABLE',
    resourcesId: 1,
    housingProjectId: 1
  };

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading.set(true);
    this.unitSvc.getAll().subscribe({
      next: u => {
        this.units.set(u);
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  searchUnits(): void {
    this.loading.set(true);
    this.unitSvc.search(undefined, this.searchLocation || undefined, (this.searchType as any) || undefined).subscribe({
      next: u => {
        this.units.set(u);
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  createUnit(): void {
    this.saving.set(true);
    this.unitSvc.create(this.form).subscribe({
      next: () => {
        this.toast.success('Unit created!');
        this.showForm = false;
        this.load();
        this.saving.set(false);
      },
      error: (e) => {
        this.toast.error(e.error?.message || 'Create failed');
        this.saving.set(false);
      }
    });
  }

  updateStatus(u: HousingUnitDTO): void {
    this.unitSvc.updateStatus(u.housingUnitStatus, u.housingUnitId!).subscribe({
      next: () => this.toast.success('Status updated'),
      error: () => this.toast.error('Update failed')
    });
  }
}
```

---

## Theme System (Dark/Light Mode)

### Overview

The app supports dark and light modes with:
- Theme toggle button on login and dashboard
- CSS variables for all colors
- Persistent theme preference in localStorage
- System preference detection

### Theme Service

**File:** `src/app/core/services/theme.service.ts`

```typescript
import { Injectable, signal, WritableSignal } from '@angular/core';

export type ThemeMode = 'dark' | 'light';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private readonly storageKey = 'housingaid-theme';
  readonly theme: WritableSignal<ThemeMode> = signal<ThemeMode>(this.loadTheme());

  constructor() {
    this.applyTheme(this.theme());
  }

  toggle(): void {
    const nextTheme: ThemeMode = this.theme() === 'dark' ? 'light' : 'dark';
    this.theme.set(nextTheme);
    this.saveTheme(nextTheme);
    this.applyTheme(nextTheme);
  }

  set(theme: ThemeMode): void {
    this.theme.set(theme);
    this.saveTheme(theme);
    this.applyTheme(theme);
  }

  private applyTheme(theme: ThemeMode): void {
    const html = document.documentElement;
    html.classList.toggle('theme-light', theme === 'light');
    html.classList.toggle('theme-dark', theme === 'dark');
  }

  private loadTheme(): ThemeMode {
    const saved = localStorage.getItem(this.storageKey) as ThemeMode | null;
    if (saved === 'light' || saved === 'dark') {
      return saved;
    }

    if (window.matchMedia?.('(prefers-color-scheme: light)').matches) {
      return 'light';
    }

    return 'dark';
  }

  private saveTheme(theme: ThemeMode): void {
    localStorage.setItem(this.storageKey, theme);
  }
}
```

#### How it works

1. **On service creation:**
   - `loadTheme()` checks localStorage for saved theme
   - If not found, checks system preference via `matchMedia`
   - Falls back to 'dark' by default

2. **When user toggles:**
   - `toggle()` switches between dark and light
   - Saves preference to localStorage
   - Applies theme by adding CSS class to `<html>`

3. **CSS application:**
   - `theme-dark` class applies dark colors
   - `theme-light` class applies light colors

### Global Styles

**File:** `src/styles.css` (excerpt)

```css
:root {
  /* Dark mode defaults (root level) */
  --bg:        #0d0f14;
  --bg2:       #141720;
  --surface:   #222636;
  --border:    #2e3348;
  --text:      #e8eaf0;
  --text2:     #9aa3be;
  --text3:     #5c6480;
  --amber:     #f5a623;
  --green:     #3ddc97;
  --red:       #ff5f5f;
  --blue:      #5b8dee;
}

html.theme-light {
  color-scheme: light;
  /* Light mode overrides */
  --bg:        #f5f7fb;
  --bg2:       #ffffff;
  --surface:   #ffffff;
  --border:    #d6dce7;
  --text:      #111827;
  --text2:     #4b5563;
  --text3:     #6b7280;
  --amber:     #d97706;
  --green:     #15803d;
  --red:       #b91c1c;
  --blue:      #2563eb;
}

html.theme-dark {
  color-scheme: dark;
}
```

### Usage in components

```typescript
// In any component
private themeService = inject(ThemeService);

theme = this.themeService.theme;  // Get current theme signal

toggleTheme(): void {
  this.themeService.toggle();     // Toggle between dark/light
}
```

In template:
```html
<button (click)="toggleTheme()">
  {{ theme() === 'dark' ? '☀️ Light Mode' : '🌙 Dark Mode' }}
</button>
```

---

## Complete User Flow

### Scenario: Citizen applies for housing

```
1. CITIZEN VISITS APP
   ├─ Opens http://localhost:4200/
   ├─ Router loads HomeComponent (login page)
   ├─ Citizen has no token in sessionStorage
   └─ Login page appears

2. CITIZEN REGISTERS (if new)
   ├─ Clicks "Register as Citizen"
   ├─ activeTab switches to 'register'
   ├─ Fills in form:
   │  ├─ Full Name: "Rajesh Kumar"
   │  ├─ Email: "rajesh@example.com"
   │  ├─ Password: "SecurePass123"
   │  ├─ Contact: "+91 98765 43210"
   │  ├─ Address: "123 Main St, Delhi"
   │  ├─ DOB: "1990-05-15"
   │  └─ Gender: "MALE"
   ├─ Clicks "Create Account"
   ├─ AuthService sends POST to backend
   ├─ Backend creates citizen user
   ├─ Success toast shows: "Account created! Please log in."
   ├─ Form switches back to login
   └─ Citizen now has credentials

3. CITIZEN LOGS IN
   ├─ Enters email and password
   ├─ Clicks "Sign In"
   ├─ handleLogin() validates
   ├─ AuthService.login() sends credentials
   ├─ Backend validates and returns JWT
   ├─ authInterceptor decodes JWT
   ├─ User object saved to sessionStorage
   ├─ Router navigates to /dashboard
   └─ LayoutComponent loads

4. DASHBOARD LOADS
   ├─ authGuard checks: auth.isLoggedIn? YES
   ├─ LayoutComponent renders
   ├─ Shows sidebar with CITIZEN menu:
   │  ├─ Dashboard
   │  ├─ Apply for Housing
   │  ├─ Upload Documents
   │  ├─ Track Application
   │  └─ My Profile
   ├─ Shows topbar with:
   │  ├─ Page title
   │  ├─ Theme toggle
   │  └─ Profile avatar
   ├─ Router redirects to /dashboard/home
   ├─ DashboardComponent loads
   └─ Dashboard shows statistics

5. CITIZEN APPLIES FOR HOUSING
   ├─ Clicks sidebar: "Apply for Housing"
   ├─ Router navigates to /dashboard/citizen-apply
   ├─ CitizenApplyComponent loads
   ├─ Component fetches active projects from backend
   ├─ authInterceptor adds JWT to request
   ├─ Backend returns projects
   ├─ Component renders project list
   ├─ Citizen selects a project
   ├─ Form appears with:
   │  ├─ Housing unit type (Apartment/Shelter)
   │  ├─ Capacity needed
   │  └─ Documents upload
   ├─ Citizen fills and submits
   ├─ API call creates HousingApplication
   ├─ Backend stores application
   ├─ Success toast: "Application submitted!"
   └─ Application now in system

6. CITIZEN UPLOADS DOCUMENTS
   ├─ Clicks sidebar: "Upload Documents"
   ├─ Router navigates to /dashboard/citizen-docs
   ├─ CitizenDocsComponent loads
   ├─ Component lists pending applications
   ├─ Citizen selects application
   ├─ Upload file interface appears
   ├─ Citizen chooses file (ID, Address proof, etc.)
   ├─ Clicks "Upload"
   ├─ File sent to backend
   ├─ Backend stores document
   └─ Success message

7. OFFICER REVIEWS APPLICATION
   ├─ Officer logs in
   ├─ LayoutComponent shows OFFICER menu
   ├─ Officer clicks "Applications"
   ├─ OfficerApplicationsComponent loads
   ├─ Fetches all citizen applications
   ├─ Officer sees Rajesh's application
   ├─ Clicks on application
   ├─ Router navigates to /dashboard/officer-eligibility/123
   ├─ OfficerEligibilityComponent loads with applicationId=123
   ├─ Reviews eligibility criteria:
   │  ├─ Income level
   │  ├─ Family size
   │  ├─ Documents status
   │  └─ Previous applications
   ├─ Marks as ELIGIBLE or REJECTED
   ├─ Application updated in backend
   └─ Citizen receives notification

8. MANAGER CREATES HOUSING PROJECT
   ├─ Manager logs in
   ├─ LayoutComponent shows MANAGER menu
   ├─ Manager clicks "Projects"
   ├─ ManagerProjectsComponent loads
   ├─ Fetches all projects and stats
   ├─ Manager sees dashboard with:
   │  ├─ Total Projects: 5
   │  ├─ Total Budget: ₹50M
   │  └─ In Progress: 2
   ├─ Manager clicks "+ New Project"
   ├─ Form appears
   ├─ Fills in project details:
   │  ├─ Title: "Eco-Friendly Housing Phase 1"
   │  ├─ Houses: 100
   │  ├─ Budget: ₹500,000,000
   │  ├─ Start Date: 2026-06-01
   │  ├─ End Date: 2028-12-31
   │  └─ Status: PLANNED
   ├─ Clicks "Create Project"
   ├─ API sends to backend
   ├─ Backend creates project and returns ID
   ├─ Component refreshes list and stats
   ├─ New project appears in grid
   └─ Success toast

9. CITIZEN TRACKS APPLICATION
   ├─ Citizen clicks "Track Application"
   ├─ CitizenTrackComponent loads
   ├─ Fetches user's applications
   ├─ Shows:
   │  ├─ Application ID: 123
   │  ├─ Status: APPROVED (green badge)
   │  ├─ Submitted: 2026-04-15
   │  ├─ Reviewed: 2026-04-25
   │  └─ Allocated Unit: Block A, Apt 201
   ├─ Citizen can see the housing unit allocated
   └─ Track progress over time

10. AUDITOR GENERATES REPORT
    ├─ Auditor logs in
    ├─ LayoutComponent shows AUDITOR menu
    ├─ Auditor clicks "Generate Report"
    ├─ AuditorReportsComponent loads
    ├─ Can generate reports on:
    │  ├─ Total applications processed
    │  ├─ Approval rate by region
    │  ├─ Average processing time
    │  ├─ Units allocated
    │  └─ Budget utilization
    ├─ Selects date range
    ├─ Clicks "Generate"
    ├─ API fetches aggregated data
    ├─ Backend compiles report
    ├─ Report displays with charts
    └─ Auditor can export PDF

11. CITIZEN LOGS OUT
    ├─ Clicks "Sign Out" button
    ├─ auth.logout() removes token from sessionStorage
    ├─ _user state cleared
    ├─ Router redirects to /
    ├─ HomeComponent (login page) appears
    └─ User back at login screen
```

---

## Data Models

### Core DTOs (Data Transfer Objects)

**File:** `src/app/core/models/models.ts`

```typescript
// ============ AUTHENTICATION ============
export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  token: string;
}

export interface AppUser {
  token: string;
  role: UserRole;
  email: string;
  name: string;
  userId?: number;
}

export type UserRole = 'CITIZEN' | 'OFFICER' | 'MANAGER' | 'ADMIN' | 'COMPLIANCE' | 'AUDITOR';

// ============ HOUSING PROJECTS ============
export interface HousingProjectDTO {
  housingProjectId?: number;
  numberOfHouses: number;
  housingProjectTitle: string;
  housingProjectDescription?: string;
  housingProjectStartDate: string;
  housingProjectEndDate: string;
  housingProjectBudget: number;
  housingProjectStatus: HousingProjectStatus;
}

export type HousingProjectStatus = 'PLANNED' | 'UNDERPROGRESS' | 'COMPLETED';

// ============ HOUSING UNITS ============
export interface HousingUnitDTO {
  housingUnitId?: number;
  housingUnitLocation: string;
  housingUnitType: HousingUnitType;
  housingUnitCapacity: number;
  housingUnitStatus: HousingUnitStatus;
  resourcesId: number;
  housingProjectId: number;
}

export type HousingUnitType = 'APARTMENT' | 'SHELTER';
export type HousingUnitStatus = 'AVAILABLE' | 'ALLOCATED' | 'MAINTENANCE';

// ============ RESOURCES ============
export interface ResourcesDTO {
  resourcesId?: number;
  resourcesType: ResourcesType;
  resourcesStatus: ResourcesStatus;
  resourcesQuantity: number;
  housingProjectId: number;
}

export type ResourcesType = 'FUNDS' | 'MATERIALS';
export type ResourcesStatus = 'AVAILABLE' | 'ALLOCATED' | 'INUSE';

// ============ APPLICATIONS ============
export interface HousingApplicationDTO {
  housingApplicationId?: number;
  citizenId: number;
  housingProjectId: number;
  housingApplicantName?: string;
  housingSchemeName?: string;
  housingApplicationSubmittedDate?: string;
  housingApplicationStatus?: HousingApplicationStatus;
  housingUnitType?: HousingUnitType;
}

export type HousingApplicationStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'ALLOCATED';
```

---

## Service Architecture

### API Service Organization

**File:** `src/app/core/services/api.services.ts`

All backend API calls are organized by domain:

```typescript
// ========== AUTHENTICATION ==========
// Handled by AuthService

// ========== HOUSING PROJECTS ==========
@Injectable({ providedIn: 'root' })
export class HousingProjectService {
  // CRUD + aggregation methods
}

// ========== HOUSING UNITS ==========
@Injectable({ providedIn: 'root' })
export class HousingUnitService {
  // CRUD + status management
}

// ========== RESOURCES ==========
@Injectable({ providedIn: 'root' })
export class ResourcesService {
  // CRUD + allocation tracking
}

// ========== APPLICATIONS ==========
@Injectable({ providedIn: 'root' })
export class HousingApplicationService {
  // CRUD + status tracking
}

// ========== ELIGIBILITY ==========
@Injectable({ providedIn: 'root' })
export class EligibilityService {
  // Eligibility checks + criteria validation
}

// ========== ALLOCATIONS ==========
@Injectable({ providedIn: 'root' })
export class AllocationService {
  // Allocation logic + finalization
}

// ========== COMPLIANCE ==========
@Injectable({ providedIn: 'root' })
export class ComplianceAuditService {
  // Audit trails + compliance records
}

// ========== USERS (ADMIN) ==========
@Injectable({ providedIn: 'root' })
export class UsersService {
  // User CRUD + role management
}

// ========== AUDIT LOGS (ADMIN) ==========
@Injectable({ providedIn: 'root' })
export class AuditLogService {
  // Log retrieval + filtering
}
```

---

## Key Takeaways

### Architecture Highlights

1. **Standalone Components** - No NgModules, lighter and simpler
2. **Signals for State** - Reactive state management with `signal()`
3. **Route-based Code Splitting** - Each page is lazy-loaded
4. **JWT Authentication** - Secure token-based auth flow
5. **Interceptors** - Automatic JWT attachment to requests
6. **Route Guards** - Protection for authenticated routes
7. **Role-based UI** - Different menus for different roles
8. **Dark/Light Theme** - CSS variables + localStorage persistence
9. **Service Organization** - One service per domain/entity
10. **Reactive Forms** - `[(ngModel)]` for two-way binding

### Security Layers

1. **Frontend Route Guard** - Prevents accessing /dashboard without token
2. **HTTP Interceptor** - Ensures JWT is sent with every request
3. **Backend Validation** - Backend verifies token and role
4. **Session Storage** - Token cleared when browser tab closes
5. **Error Handling** - Failed requests trigger login redirect

### Data Flow

```
Component
  ↓ (user action)
Component Method
  ↓ (calls)
Service Method
  ↓ (calls)
HTTP Request (with JWT via interceptor)
  ↓
Backend API
  ↓
Response
  ↓
Service receives and returns
  ↓
Component receives via subscription
  ↓
Updates UI with signal
  ↓
Template renders new state
```

---

## End of Documentation

This comprehensive guide covers:
- ✅ Project structure and setup
- ✅ Complete authentication flow
- ✅ Security architecture
- ✅ Manager module (projects, resources, units)
- ✅ Theme system (dark/light mode)
- ✅ Complete user journey flows
- ✅ Data models and services
- ✅ Code examples with explanations

**Created:** May 12, 2026  
**Project:** HousingAid - Affordable Housing Management System

