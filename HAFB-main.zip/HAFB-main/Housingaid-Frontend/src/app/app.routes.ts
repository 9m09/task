import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./features/auth/home.component').then(m => m.HomeComponent)
  },
  {
    path: 'dashboard',
    canActivate: [authGuard],
    loadComponent: () => import('./features/layout/layout.component').then(m => m.LayoutComponent),
    children: [
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      { path: 'home', loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent) },

      // Citizen
      { path: 'citizen-apply', loadComponent: () => import('./features/citizen/citizen-apply.component').then(m => m.CitizenApplyComponent) },
      { path: 'citizen-docs', loadComponent: () => import('./features/citizen/citizen-docs.component').then(m => m.CitizenDocsComponent) },
      { path: 'citizen-track', loadComponent: () => import('./features/citizen/citizen-track.component').then(m => m.CitizenTrackComponent) },
      { path: 'citizen-profile', loadComponent: () => import('./features/citizen/citizen-profile.component').then(m => m.CitizenProfileComponent) },

      // Officer
      { path: 'officer-applications', loadComponent: () => import('./features/officer/officer-applications.component').then(m => m.OfficerApplicationsComponent) },
      { path: 'officer-eligibility/:applicationId', loadComponent: () => import('./features/officer/officer-eligibility.component').then(m => m.OfficerEligibilityComponent) },
      { path: 'officer-eligibility', loadComponent: () => import('./features/officer/officer-eligibility.component').then(m => m.OfficerEligibilityComponent) },
      { path: 'officer-units', loadComponent: () => import('./features/officer/officer-units.component').then(m => m.OfficerUnitsComponent) },

      // Manager
      { path: 'manager-projects', loadComponent: () => import('./features/manager/manager-projects.component').then(m => m.ManagerProjectsComponent) },
      { path: 'manager-resources', loadComponent: () => import('./features/manager/manager-resources.component').then(m => m.ManagerResourcesComponent) },
      { path: 'manager-units', loadComponent: () => import('./features/officer/officer-units.component').then(m => m.OfficerUnitsComponent) },

      // Allocation
      { path: 'allocation-allocate', loadComponent: () => import('./features/allocation/allocation-allocate.component').then(m => m.AllocationAllocateComponent) },
      { path: 'allocation-finalize/:applicationId', loadComponent: () => import('./features/allocation/allocation-finalize.component').then(m => m.AllocationFinalizeComponent) },
      { path: 'allocation-table', loadComponent: () => import('./features/allocation/allocation-table.component').then(m => m.AllocationTableComponent) },

      // Compliance
      { path: 'compliance-records', loadComponent: () => import('./features/compliance/compliance-records.component').then(m => m.ComplianceRecordsComponent) },
      { path: 'compliance-audits', loadComponent: () => import('./features/compliance/compliance-audits.component').then(m => m.ComplianceAuditsComponent) },
      { path: 'compliance-new-audit', loadComponent: () => import('./features/compliance/compliance-new-audit.component').then(m => m.ComplianceNewAuditComponent) },

      // Auditor
      { path: 'auditor-reports', loadComponent: () => import('./features/auditor/auditor-reports.component').then(m => m.AuditorReportsComponent) },
      { path: 'auditor-review', loadComponent: () => import('./features/auditor/auditor-review.component').then(m => m.AuditorReviewComponent) },

      // Admin
      { path: 'admin-users', loadComponent: () => import('./features/admin/admin-users.component').then(m => m.AdminUsersComponent) },
      { path: 'admin-logs', loadComponent: () => import('./features/admin/admin-logs.component').then(m => m.AdminLogsComponent) },
      { path: 'admin-workflows', loadComponent: () => import('./features/admin/admin-workflows.component').then(m => m.AdminWorkflowsComponent) },
    ]
  },
  { path: '**', redirectTo: '' }
];
