// ============ AUTH / USERS ============
export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  token: string;
}

export interface UsersCreateDTO {
  userId?: number;
  userName: string;
  userPassword?: string;
  userEmail: string;
  userPhone: string;
  userRole: UserRole;
  userStatus?: UserStatus;
}

export interface CitizenRegistrationDTO {
  userName: string;
  userEmail: string;
  userPassword: string;
  citizenContactInfo: string;
  citizenAddress: string;
  citizenDOB: string;
  citizenGender: CitizenGender;
}

export interface CitizenDTO {
  citizenId?: number;
  citizenName: string;
  citizenDOB: string;
  citizenGender: CitizenGender;
  citizenAddress: string;
  citizenContactInfo: string;
  userId: number;
  citizenStatus?: CitizenStatus;
}

export interface CitizenDocumentDTO {
  citizenDocumentId?: number;
  citizenDocumentDocType: CitizenDocumentDocType;
  citizenDocumentFileUri: string;
  citizenDocumentUploadedDate: string;
  citizenDocumentVerificationStatus: CitizenDocumentVerificationStatus;
}

export interface AuditLogDTO {
  auditLogId?: number;
  userId: number;
  auditLogAction: AuditLogAction;
  auditLogResource?: string;
}

export interface UsersProfileDTO {
  userPassword?: number;
  userName: string;
  userEmail: string;
  userPhone: string;
}

// ============ INVENTORY ============
export interface HousingProjectDTO {
  housingProjectId?: number;
  numberOfHouses: number;
  housingProjectTitle: string;
  housingProjectDescription?: string;
  housingProjectStartDate: string;
  housingProjectEndDate: string;
  housingProjectBudget: number;
  housingProjectStatus: HousingProjectStatus;
}

export interface HousingUnitDTO {
  housingUnitId?: number;
  housingUnitLocation: string;
  housingUnitType: HousingUnitType;
  housingUnitCapacity: number;
  housingUnitStatus: HousingUnitStatus;
  resourcesId: number;
  housingProjectId: number;
}

export interface ResourcesDTO {
  resourcesId?: number;
  resourcesType: ResourcesType;
  resourcesStatus: ResourcesStatus;
  resourcesQuantity: number;
  housingProjectId: number;
}

// ============ APPLICATION ============
export interface HousingApplicationRequestDTO{
  readonly housingApplicationId?: number;
  housingProjectId: number;
  housingUnitType: HousingUnitType;
  housingCapacity: number;
  citizenId: number;
}
export interface HousingApplicationDTO {
  housingApplicationId?: number;
  citizenId: number;
  housingProjectId: number;
  housingApplicantName?: string;
  housingSchemeName?: string;
  housingApplicationSubmittedDate?: string;
  housingApplicationStatus?: HousingApplicationStatus;
  housingUnitType?: HousingUnitType;
  housingCapacity?: number;
}

export interface EligibilityCheckDTO {
  id?: number;
  eligibilityCheckId?: number;
  housingApplicationId: number;
  citizenDocumentId: number;
  officerId: number;
  result?: EligibilityResult;
  eligibilityCheckResult?: EligibilityCheckResult;
  notes?: string;
  eligibilityCheckNotes?: string;
  date?: string;
  eligibilityCheckDate?: string;
}

// ============ ALLOCATION ============
export interface AllocationRequestDTO {
  citizenId: number;
  officerId: number;
  housingProjectId: number;
  allocationMessage?: string;
}

export interface AllocationResponseDTO {
  message: string;
  allocationId: number;
  citizenId: number;
  housingunitId: number;
  housingProjectId: number;
  status: string;
  allocationMessage?: string;
}

// ============ COMPLIANCE ============
export interface ComplianceRecordDTO {
  complianceId?: number;
  entityId: number;
  type: ComplianceEntityType;
  result: ComplianceResult;
  date: string;
  notes: string;
}

export interface AuditDTO {
  auditId?: number;
  officerId: number;
  scope: string;
  findings: string;
  auditDate: string;
  status: AuditStatus;
  remarks?: string;
  date?: string;
}

// ============ REPORTS ============
export interface ReportDTO {
  reportId?: number;
  scope: ReportScope;
  metrics?: string;
  generatedDate?: string;
}

// ============ ENUMS ============
export type UserRole = 'CITIZEN' | 'OFFICER' | 'MANAGER' | 'ADMIN' | 'COMPLIANCE' | 'AUDITOR';
export type UserStatus = 'ACTIVE' | 'INACTIVE' | 'PENDING' | 'SUSPENDED';
export type CitizenGender = 'MALE' | 'FEMALE' | 'OTHER';
export type CitizenStatus = 'ACTIVE' | 'INACTIVE' | 'SUSPENDED' | 'PENDING';
export type CitizenDocumentDocType = 'IDPROOF' | 'INCOMECERTIFICATE';
export type CitizenDocumentVerificationStatus = 'PENDING' | 'VERIFIED' | 'REJECTED';
export type AuditLogAction = 'LOGIN' | 'LOGOUT' | 'CREATE' | 'UPDATE' | 'DELETE' | 'VERIFY' | 'REJECT' | 'AUDITREVIEW' | 'COMPLIANCECHECK';
export type HousingProjectStatus = 'PLANNED' | 'UNDERPROGRESS' | 'COMPLETED';
export type HousingUnitType = 'APARTMENT' | 'SHELTER';
export type HousingUnitStatus = 'AVAILABLE' | 'ALLOCATED' | 'MAINTENANCE';
export type ResourcesType = 'FUNDS' | 'MATERIALS';
export type ResourcesStatus = 'ALLOCATED' | 'INUSE' | 'AVAILABLE';
export type HousingApplicationStatus = 'PENDING' | 'UNDER_REVIEW' | 'APPROVED' | 'REJECTED';
export type EligibilityResult = 'ELIGIBLE' | 'NOTELIGIBLE';
export type EligibilityCheckResult = 'ELIGIBLE' | 'NOTELIGIBLE';
export type AllocationStatus = 'ACTIVE' | 'COMPLETED' | 'CANCELLED';
export type ComplianceEntityType = 'APPLICATION' | 'UNIT' | 'PROJECT';
export type ComplianceResult = 'COMPLIANT' | 'NONCOMPLIANT';
export type AuditStatus = 'PENDING' | 'COMPLETED' | 'FLAGGED';
export type ReportScope = 'ALLOCATION' | 'HOUSINGAPPLICATION' | 'HOUSINGPROJECT';

// ============ APP STATE ============
export interface AppUser {
  token: string;
  role: UserRole;
  email: string;
  name?: string;
  userId?: number;
}
