import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  HousingProjectDTO, HousingUnitDTO, ResourcesDTO,
  HousingApplicationDTO, HousingApplicationRequestDTO, EligibilityCheckDTO,
  AllocationRequestDTO, AllocationResponseDTO,
  ComplianceRecordDTO, AuditDTO, ReportDTO,
  UsersCreateDTO, CitizenDTO, CitizenRegistrationDTO, CitizenDocumentDTO, AuditLogDTO,
  UserStatus, HousingUnitType, HousingUnitStatus,
  ResourcesType, ResourcesStatus, HousingApplicationStatus,
  ReportScope
} from '../models/models';

const API = environment.apiUrl;

// ========== ADMIN / USERS ==========
// ========== ADMIN / USERS ==========
@Injectable({ providedIn: 'root' })
export class UserAdminService {
  private base = `${API}/auths/admin`;
  constructor(private http: HttpClient) {}

  getAllUsers(): Observable<UsersCreateDTO[]> { return this.http.get<UsersCreateDTO[]>(`${this.base}/get-all-users`); }
  createUser(dto: UsersCreateDTO): Observable<string> { return this.http.post(`${this.base}/create-user`, dto, { responseType: 'text' }); }
  updateUser(id: number, dto: UsersCreateDTO): Observable<string> { return this.http.put(`${this.base}/update-user/${id}`, dto, { responseType: 'text' }); }
  deleteUser(id: number): Observable<string> { return this.http.delete(`${this.base}/delete-user/${id}`, { responseType: 'text' }); }
  getUserById(id: number): Observable<UsersCreateDTO> { return this.http.get<UsersCreateDTO>(`${this.base}/search-user/${id}`); }
  updateStatus(id: number, status: UserStatus): Observable<string> {
    return this.http.put(`${this.base}/update-user-status/${id}`, null, { params: { userStatus: status }, responseType: 'text' });
  }
}

// ========== CITIZENS ==========
@Injectable({ providedIn: 'root' })
export class CitizenService {
  private base = `${API}/auths/citizen`;
  constructor(private http: HttpClient) {}

  getAllCitizens(): Observable<CitizenDTO[]> { return this.http.get<CitizenDTO[]>(`${this.base}/get-all-citizens`); }
  getCurrentCitizen(): Observable<CitizenDTO> { return this.http.get<CitizenDTO>(`${this.base}/me`); }
  getCitizenById(id: number): Observable<CitizenDTO> { return this.http.get<CitizenDTO>(`${this.base}/search-citizen/${id}`); }
  updateCitizen(id: number, dto: CitizenDTO): Observable<string> { return this.http.put(`${this.base}/update-citizen/${id}`, dto, { responseType: 'text' }); }
  completeProfile(dto: CitizenRegistrationDTO): Observable<CitizenDTO> { return this.http.post<CitizenDTO>(`${this.base}/complete-profile`, dto); }

  // Documents
  uploadDocument(citizenId: number, dto: CitizenDocumentDTO): Observable<CitizenDocumentDTO> {
    return this.http.post<CitizenDocumentDTO>(`${this.base}/${citizenId}/documents/upload-document`, dto);
  }
  getDocuments(citizenId: number): Observable<CitizenDocumentDTO[]> {
    return this.http.get<CitizenDocumentDTO[]>(`${this.base}/${citizenId}/documents/get-all-documents`);
  }
  deleteDocument(citizenId: number, docId: number): Observable<string> {
    return this.http.delete(`${this.base}/${citizenId}/documents/delete-document/${docId}`, { responseType: 'text' });
  }
  updateDocStatus(status: string, docId: number): Observable<void> {
    return this.http.patch<void>(`${this.base}/0/documents/update-document-staus`, null, { params: { citizenStatus: status, citizenDocumentId: docId } });
  }
}

// ========== AUDIT LOGS ==========
@Injectable({ providedIn: 'root' })
export class AuditLogService {
  private base = `${API}/auths/audit-log`;
  constructor(private http: HttpClient) {}

  getAll(): Observable<AuditLogDTO[]> { return this.http.get<AuditLogDTO[]>(`${this.base}/get-all-audit-logs`); }
  create(dto: AuditLogDTO): Observable<string> { return this.http.post(`${this.base}/create-audit-log`, dto, { responseType: 'text' }); }
  delete(id: number): Observable<string> { return this.http.delete(`${this.base}/delete-audit-log/${id}`, { responseType: 'text' }); }
  getById(id: number): Observable<AuditLogDTO> { return this.http.get<AuditLogDTO>(`${this.base}/search-audit-log/${id}`); }
  getByUser(userId: number): Observable<AuditLogDTO[]> { return this.http.get<AuditLogDTO[]>(`${this.base}/search-audit-log-by-user/${userId}`); }
}

// ========== INVENTORY - PROJECTS ==========
@Injectable({ providedIn: 'root' })
export class HousingProjectService {
  private base = `${API}/inventory/housing-project`;
  constructor(private http: HttpClient) {}

  getAll(): Observable<HousingProjectDTO[]> { return this.http.get<HousingProjectDTO[]>(`${this.base}/get-all-housing-projects`); }
  create(dto: HousingProjectDTO): Observable<string> { return this.http.post(`${this.base}/create-housing-project`, dto, { responseType: 'text' }); }
  update(id: number, dto: HousingProjectDTO): Observable<string> { return this.http.put(`${this.base}/update-housing-project/${id}`, dto, { responseType: 'text' }); }
  search(id?: number, title?: string): Observable<HousingProjectDTO[]> {
    let params = new HttpParams();
    if (id) params = params.set('housingProjectId', id);
    if (title) params = params.set('housingProjectTitle', title);
    return this.http.get<HousingProjectDTO[]>(`${this.base}/search-housing-project`, { params });
  }
  getTotalCount(): Observable<number> { return this.http.get<number>(`${this.base}/count`); }
  getCountByStatus(status: string): Observable<number> { return this.http.get<number>(`${this.base}/count/${status}`); }
  getTotalBudget(): Observable<number> { return this.http.get<number>(`${this.base}/budget/sum`); }
  getById(id: number): Observable<HousingProjectDTO> { return this.http.get<HousingProjectDTO>(`${this.base}/get-housing-project/${id}`); }
  getActiveProjects(): Observable<HousingProjectDTO[]> { return this.http.get<HousingProjectDTO[]>(`${this.base}/get-active-housing-projects`); }
  checkAvailability(id: number): Observable<boolean> { return this.http.get<boolean>(`${this.base}/check-available`, { params: { housingProjectId: id } }); }
}

// ========== INVENTORY - UNITS ==========
@Injectable({ providedIn: 'root' })
export class HousingUnitService {
  private base = `${API}/inventory/housing-unit`;
  constructor(private http: HttpClient) {}

  getAll(): Observable<HousingUnitDTO[]> { return this.http.get<HousingUnitDTO[]>(`${this.base}/get-all-housing-units`); }
  create(dto: HousingUnitDTO): Observable<string> { return this.http.post(`${this.base}/create-housing-unit`, dto, { responseType: 'text' }); }
  update(id: number, dto: HousingUnitDTO): Observable<string> { return this.http.put(`${this.base}/update-housing-unit/${id}`, dto, { responseType: 'text' }); }
  search(id?: number, location?: string, type?: HousingUnitType): Observable<HousingUnitDTO[]> {
    let params = new HttpParams();
    if (id) params = params.set('housingUnitId', id);
    if (location) params = params.set('housingUnitLocation', location);
    if (type) params = params.set('housingUnitType', type);
    return this.http.get<HousingUnitDTO[]>(`${this.base}/search-housing-unit`, { params });
  }
  getIdsByProject(projectId: number): Observable<number[]> {
    return this.http.get<number[]>(`${this.base}/get-id`, { params: { housingProjectId: projectId } });
  }
  findStatus(unitId: number): Observable<string> {
    return this.http.get(`${this.base}/find-status`, { params: { housingUnitId: unitId }, responseType: 'text' });
  }
  updateStatus(status: string, unitId: number): Observable<void> {
    return this.http.put<void>(`${this.base}/update`, null, { params: { housingStatus: status, housingUnitId: unitId } });
  }
  getById(unitId: number): Observable<HousingUnitDTO> {
    return this.http.get<HousingUnitDTO>(`${this.base}/get-by-id`, { params: { housingUnitId: unitId } });
  }
}

// ========== INVENTORY - RESOURCES ==========
@Injectable({ providedIn: 'root' })
export class ResourcesService {
  private base = `${API}/inventory/resources`;
  constructor(private http: HttpClient) {}

  getAll(): Observable<ResourcesDTO[]> { return this.http.get<ResourcesDTO[]>(`${this.base}/get-all-resources`); }
  create(dto: ResourcesDTO): Observable<string> { return this.http.post(`${this.base}/create-resources`, dto, { responseType: 'text' }); }
  update(id: number, dto: ResourcesDTO): Observable<string> { return this.http.put(`${this.base}/update-resources/${id}`, dto, { responseType: 'text' }); }
  search(id?: number, type?: ResourcesType, status?: ResourcesStatus): Observable<ResourcesDTO[]> {
    let params = new HttpParams();
    if (id) params = params.set('resourcesId', id);
    if (type) params = params.set('resourcesType', type);
    if (status) params = params.set('resourcesStatus', status);
    return this.http.get<ResourcesDTO[]>(`${this.base}/search-resources`, { params });
  }
}

// ========== APPLICATIONS ==========
@Injectable({ providedIn: 'root' })
export class HousingApplicationService {
  private base = `${API}/application/housing-application`;
  constructor(private http: HttpClient) {}

  create(dto: HousingApplicationRequestDTO): Observable<string> { return this.http.post(`${this.base}/create`, dto, { responseType: 'text' }); }
  getAll(): Observable<HousingApplicationDTO[]> { return this.http.get<HousingApplicationDTO[]>(`${this.base}/all`); }
  getById(id: number): Observable<HousingApplicationDTO> { return this.http.get<HousingApplicationDTO>(`${this.base}/${id}`); }
  getByStatus(status: HousingApplicationStatus): Observable<HousingApplicationDTO[]> { return this.http.get<HousingApplicationDTO[]>(`${this.base}/status/${status}`); }
  updateStatus(status: string, id: number): Observable<string> {
    return this.http.put(`${this.base}/update-status`, null, { params: { housingApplicationStatus: status, housingApplicationId: id }, responseType: 'text' });
  }
  getTotalCount(): Observable<number> { return this.http.get<number>(`${this.base}/get-total-count`); }
  getCountByStatus(status: string): Observable<number> { return this.http.get<number>(`${this.base}/count/status/${status}`); }
  getApplicationId(citizenId: number, status: string): Observable<number> {
    return this.http.get<number>(`${this.base}/applicationId`, { params: { citizenId, status } });
  }
}

// ========== ELIGIBILITY ==========
@Injectable({ providedIn: 'root' })
export class EligibilityCheckService {
  private base = `${API}/application/eligibility-check`;
  constructor(private http: HttpClient) {}

  submit(dto: EligibilityCheckDTO): Observable<string> { return this.http.post(`${this.base}/submit`, dto, { responseType: 'text' }); }
  getHistory(): Observable<EligibilityCheckDTO[]> { return this.http.get<EligibilityCheckDTO[]>(`${this.base}/history`); }
  getById(id: number): Observable<EligibilityCheckDTO> { return this.http.get<EligibilityCheckDTO>(`${this.base}/${id}`); }
  getResult(appId: number, status: string): Observable<number> {
    return this.http.get<number>(`${this.base}/get-result`, { params: { housingApplicationId: appId, status } });
  }
}

// ========== ALLOCATIONS ==========
@Injectable({ providedIn: 'root' })
export class AllocationService {
  private base = `${API}/allocation/allocations`;
  constructor(private http: HttpClient) {}

  create(dto: AllocationRequestDTO): Observable<AllocationResponseDTO> { return this.http.post<AllocationResponseDTO>(`${this.base}/create`, dto); }
  getAll(): Observable<AllocationResponseDTO[]> { return this.http.get<AllocationResponseDTO[]>(`${this.base}/get-all-Allocation`); }
  getTotal(): Observable<number> { return this.http.get<number>(`${this.base}/total`); }
  getCountByStatus(status: string): Observable<number> { return this.http.get<number>(`${this.base}/count/${status}`); }
}

// ========== COMPLIANCE ==========
@Injectable({ providedIn: 'root' })
export class ComplianceRecordService {
  private base = `${API}/compliance/compliance-record`;
  constructor(private http: HttpClient) {}

  create(dto: ComplianceRecordDTO): Observable<string> { return this.http.post(`${this.base}/create-compliance-record`, dto, { responseType: 'text' }); }
  getAll(): Observable<ComplianceRecordDTO[]> { return this.http.get<ComplianceRecordDTO[]>(`${this.base}/get-all-compliance-records`); }
  search(entityId?: number, type?: string): Observable<ComplianceRecordDTO[]> {
    let params = new HttpParams();
    if (entityId) params = params.set('entityId', entityId);
    if (type) params = params.set('type', type);
    return this.http.get<ComplianceRecordDTO[]>(`${this.base}/search-compliance-record`, { params });
  }
  getDashboard(selection: string = 'ALL'): Observable<any> {
    return this.http.get<any>(`${this.base}/get-compliance-dashboard`, { params: { selection } });
  }
}

// ========== COMPLIANCE AUDITS ==========
@Injectable({ providedIn: 'root' })
export class ComplianceAuditService {
  private base = `${API}/compliance/audit`;
  constructor(private http: HttpClient) {}

  create(dto: AuditDTO): Observable<string> { return this.http.post(`${this.base}/create-audit`, dto, { responseType: 'text' }); }
  update(dto: AuditDTO): Observable<string> { return this.http.put(`${this.base}/update-audit`, dto, { responseType: 'text' }); }
  getAll(): Observable<AuditDTO[]> { return this.http.get<AuditDTO[]>(`${this.base}/get-all-audits`); }
  search(officerId?: number, scope?: string, findings?: string, auditDate?: string, status?: string): Observable<AuditDTO[]> {
    const body = { officerId, scope, findings, auditDate, status };
    return this.http.post<AuditDTO[]>(`${this.base}/search-audit`, body);
  }
}

// ========== REPORTS ==========
@Injectable({ providedIn: 'root' })
export class ReportService {
  private base = `${API}/notification/reports`;
  constructor(private http: HttpClient) {}

  generate(scope: ReportScope): Observable<ReportDTO> { return this.http.get<ReportDTO>(`${this.base}/generate/${scope}`); }
  getById(id: number): Observable<ReportDTO> { return this.http.get<ReportDTO>(`${this.base}/get-reportof-${id}`); }
  getAll(): Observable<ReportDTO[]> { return this.http.get<ReportDTO[]>(`${this.base}/get-all-reports`); }
  delete(id: number): Observable<string> { return this.http.delete(`${this.base}/Delete-reportof-${id}`, { responseType: 'text' }); }
}
