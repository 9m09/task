import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { AppUser, LoginRequest, LoginResponse, CitizenRegistrationDTO, UsersCreateDTO } from '../models/models';
import { jwtDecode } from '../utils/jwt-decode';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly BASE = `${environment.apiUrl}/auths/auth`;
  private _user = new BehaviorSubject<AppUser | null>(this.loadUser());
  user$ = this._user.asObservable();

  constructor(private http: HttpClient, private router: Router) {}

  get currentUser(): AppUser | null { return this._user.value; }
  get token(): string | null { return this._user.value?.token ?? null; }
  get isLoggedIn(): boolean { return !!this._user.value; }

  login(req: LoginRequest): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.BASE}/login`, req).pipe(
      tap(res => {
        const decoded = jwtDecode(res.token);
        const role = decoded?.role?.replace('ROLE_', '') as any;
        const email = decoded?.email ?? decoded?.sub ?? req.email;
        const name = decoded?.userName ?? decoded?.name ?? decoded?.given_name ?? decoded?.preferred_username ?? decoded?.sub;
        const user: AppUser = {
          token: res.token,
          role: role,
          email,
          name,
          userId: decoded?.userId
        };
        sessionStorage.setItem('ha_user', JSON.stringify(user));
        this._user.next(user);
      })
    );
  }

  registerCitizen(dto: CitizenRegistrationDTO): Observable<CitizenRegistrationDTO> {
    return this.http.post<CitizenRegistrationDTO>(`${this.BASE}/register-citizen`, dto);
  }

  registerUser(dto: UsersCreateDTO): Observable<string> {
    return this.http.post(`${this.BASE}/register`, dto, { responseType: 'text' });
  }

  logout(): void {
    sessionStorage.removeItem('ha_user');
    this._user.next(null);
    this.router.navigate(['/']);
  }

  private loadUser(): AppUser | null {
    try {
      const raw = sessionStorage.getItem('ha_user');
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  }
}
