import { Injectable, signal, WritableSignal } from '@angular/core';

export type ThemeMode = 'dark' | 'light';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private readonly storageKey = 'housingaid-theme';
  readonly theme: WritableSignal<ThemeMode> = signal<ThemeMode>(this.loadTheme());

  constructor() {
    this.applyTheme(this.theme());
  }

  toggle(): void {
    const nextTheme: ThemeMode = this.theme() === 'dark' ? 'light' : 'dark';
    this.theme.set(nextTheme);
    this.saveTheme(nextTheme);
    this.applyTheme(nextTheme);
  }

  set(theme: ThemeMode): void {
    this.theme.set(theme);
    this.saveTheme(theme);
    this.applyTheme(theme);
  }

  private applyTheme(theme: ThemeMode): void {
    const html = document.documentElement;
    html.classList.toggle('theme-light', theme === 'light');
    html.classList.toggle('theme-dark', theme === 'dark');
  }

  private loadTheme(): ThemeMode {
    const saved = localStorage.getItem(this.storageKey) as ThemeMode | null;
    if (saved === 'light' || saved === 'dark') {
      return saved;
    }

    if (window.matchMedia?.('(prefers-color-scheme: light)').matches) {
      return 'light';
    }

    return 'dark';
  }

  private saveTheme(theme: ThemeMode): void {
    localStorage.setItem(this.storageKey, theme);
  }
}
