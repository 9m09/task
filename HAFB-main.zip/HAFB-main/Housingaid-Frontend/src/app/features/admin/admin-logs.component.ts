import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuditLogService } from '../../core/services/api.services';
import { ToastService } from '../../core/services/toast.service';
import { AuditLogDTO, AuditLogAction } from '../../core/models/models';

@Component({
  selector: 'app-admin-logs',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-content">
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <h1>Audit Logs</h1>
          <p>Complete audit trail of all system actions</p>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-ghost" (click)="load()">↻ Refresh</button>
        </div>
      </div>



      <!-- Search by user -->
      <div class="search-bar mb-4">
        <input class="search-input" type="number" [(ngModel)]="searchUserId" placeholder="Filter by User ID…" />
        <button class="btn btn-ghost" (click)="searchByUser()">Search</button>
        <button class="btn btn-ghost" (click)="load()">↻ Reset</button>
      </div>

      <!-- Table -->
      <div class="card">
        <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
        <div *ngIf="!loading() && logs().length === 0" class="empty-state">
          <div class="empty-state-icon">📋</div>
          <p>No audit logs found</p>
        </div>
        <div *ngIf="!loading() && logs().length > 0" class="table-wrap">
          <table>
            <thead>
              <tr><th>Log ID</th><th>User ID</th><th>Action</th><th>Resource</th><th>Actions</th></tr>
            </thead>
            <tbody>
              <tr *ngFor="let l of logs()">
                <td class="td-mono">#{{l.auditLogId}}</td>
                <td class="td-mono">#{{l.userId}}</td>
                <td>
                  <span class="badge" [class]="actionBadge(l.auditLogAction)">{{l.auditLogAction}}</span>
                </td>
                <td style="font-size:12px;color:var(--text2);max-width:280px;font-family:var(--font-mono)">
                  {{l.auditLogResource || '—'}}
                </td>
                <td>
                  <button class="btn btn-danger btn-sm" (click)="deleteLog(l)">🗑</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class AdminLogsComponent implements OnInit {
  private logSvc = inject(AuditLogService);
  private toast = inject(ToastService);

  loading = signal(true);
  logs = signal<AuditLogDTO[]>([]);
  searchUserId = '';

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.logSvc.getAll().subscribe({
      next: l => { this.logs.set(l); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  searchByUser(): void {
    if (!this.searchUserId) { this.load(); return; }
    this.loading.set(true);
    this.logSvc.getByUser(Number(this.searchUserId)).subscribe({
      next: l => { this.logs.set(l); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  deleteLog(l: AuditLogDTO): void {
    if (!confirm('Delete this log entry?')) return;
    this.logSvc.delete(l.auditLogId!).subscribe({
      next: () => { this.toast.success('Log deleted'); this.load(); },
      error: () => this.toast.error('Delete failed')
    });
  }

  actionBadge(action: string): string {
    const map: Record<string, string> = {
      LOGIN: 'badge-green', LOGOUT: 'badge-grey',
      CREATE: 'badge-blue', UPDATE: 'badge-amber',
      DELETE: 'badge-red', VERIFY: 'badge-green',
      REJECT: 'badge-red', AUDITREVIEW: 'badge-blue', COMPLIANCECHECK: 'badge-amber'
    };
    return map[action] ?? 'badge-grey';
  }
}
