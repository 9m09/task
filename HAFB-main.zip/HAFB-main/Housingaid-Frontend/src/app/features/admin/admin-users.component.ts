import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserAdminService } from '../../core/services/api.services';
import { ToastService } from '../../core/services/toast.service';
import { UsersCreateDTO, UserRole, UserStatus } from '../../core/models/models';
import { StatusBadgeComponent } from '../../shared/components/status-badge.component';

@Component({
  selector: 'app-admin-users',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <h1>User Management</h1>
          <p>Create and manage system users across all roles</p>
        </div>
        <button class="btn btn-primary" (click)="showForm = !showForm; editingId = null; form = blank()">
          {{ showForm && !editingId ? '✕ Cancel' : '+ Add User' }}
        </button>
      </div>

      <!-- Stats -->
      <div class="grid-4 mb-4">
        <div *ngFor="let role of ['OFFICER','MANAGER','COMPLIANCE','AUDITOR']" class="stat-card blue">
          <div class="stat-value" style="color:var(--blue)">{{countByRole(role)}}</div>
          <div class="stat-label">{{role}}</div>
        </div>
      </div>

      <!-- Form -->
      <div class="card mb-4" *ngIf="showForm">
        <div class="card-title">{{ editingId ? 'Edit User #' + editingId : 'New User' }}</div>
        <div class="grid-2">
          <div class="form-group">
            <label class="form-label">Full Name</label>
            <input class="form-input" [(ngModel)]="form.userName" placeholder="John Smith" />
          </div>
          <div class="form-group">
            <label class="form-label">Email</label>
            <input class="form-input" type="email" [(ngModel)]="form.userEmail" placeholder="john@housingaid.gov" />
          </div>
          <div class="form-group" *ngIf="!editingId">
            <label class="form-label">Password</label>
            <input class="form-input" type="password" [(ngModel)]="form.userPassword" placeholder="Min 6 characters" />
          </div>
          <div class="form-group">
            <label class="form-label">Phone</label>
            <input class="form-input" [(ngModel)]="form.userPhone" placeholder="10 digits" maxlength="10" />
          </div>
          <div class="form-group">
            <label class="form-label">Role</label>
            <select class="form-select" [(ngModel)]="form.userRole">
              <option *ngFor="let r of roles" [value]="r">{{r}}</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Status</label>
            <select class="form-select" [(ngModel)]="form.userStatus">
              <option value="ACTIVE">Active</option>
              <option value="INACTIVE">Inactive</option>
              <option value="PENDING">Pending</option>
              <option value="SUSPENDED">Suspended</option>
            </select>
          </div>
        </div>
        <div class="modal-footer" style="padding-top:0;border:none;margin-top:0">
          <button class="btn btn-ghost" (click)="showForm = false; editingId = null">Cancel</button>
          <button class="btn btn-primary" (click)="save()" [disabled]="saving()">
            <span *ngIf="saving()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
            {{ saving() ? 'Saving...' : (editingId ? 'Update User' : 'Create User') }}
          </button>
        </div>
      </div>

      <!-- Search -->
      <div class="search-bar mb-4">
        <input class="search-input" [(ngModel)]="searchQ" placeholder="Search by name or email…" (input)="filterUsers()" />
        <select class="form-select" style="width:160px" [(ngModel)]="filterRole" (change)="filterUsers()">
          <option value="">All Roles</option>
          <option *ngFor="let r of roles" [value]="r">{{r}}</option>
        </select>
      </div>

      <!-- Table -->
      <div class="card">
        <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
        <div *ngIf="!loading() && filtered().length === 0" class="empty-state">
          <div class="empty-state-icon">👥</div>
          <p>No users found</p>
        </div>
        <div *ngIf="!loading() && filtered().length > 0" class="table-wrap">
          <table>
            <thead>
              <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
              <tr *ngFor="let u of filtered()">
                <td class="td-mono">#{{u.userId}}</td>
                <td style="font-weight:600">{{u.userName}}</td>
                <td style="font-size:12px;color:var(--text2)">{{u.userEmail}}</td>
                <td class="td-mono">{{u.userPhone}}</td>
                <td><span class="badge badge-blue">{{u.userRole}}</span></td>
                <td><app-status-badge [status]="u.userStatus ?? ''" /></td>
                <td>
                  <div style="display:flex;gap:6px">
                    <button class="btn btn-ghost btn-sm" (click)="startEdit(u)">✏</button>
                    <button class="btn btn-danger btn-sm" (click)="deleteUser(u)">🗑</button>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class AdminUsersComponent implements OnInit {
  private userSvc = inject(UserAdminService);
  private toast = inject(ToastService);

  loading = signal(true);
  saving = signal(false);
  users = signal<UsersCreateDTO[]>([]);
  filtered = signal<UsersCreateDTO[]>([]);
  showForm = false;
  editingId: number | null = null;
  searchQ = '';
  filterRole = '';

  roles: UserRole[] = ['CITIZEN', 'OFFICER', 'MANAGER', 'ADMIN', 'COMPLIANCE', 'AUDITOR'];
  form: UsersCreateDTO = this.blank();

  blank(): UsersCreateDTO {
    return { userName: '', userPassword: '', userEmail: '', userPhone: '', userRole: 'OFFICER', userStatus: 'ACTIVE' };
  }

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.userSvc.getAllUsers().subscribe({
      next: u => { this.users.set(u); this.filtered.set(u); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  filterUsers(): void {
    const q = this.searchQ.toLowerCase();
    this.filtered.set(this.users().filter(u =>
      (!q || u.userName.toLowerCase().includes(q) || u.userEmail.toLowerCase().includes(q)) &&
      (!this.filterRole || u.userRole === this.filterRole)
    ));
  }

  countByRole(r: string): number { return this.users().filter(u => u.userRole === r).length; }

  startEdit(u: UsersCreateDTO): void {
    this.editingId = u.userId ?? null;
    this.form = { ...u, userPassword: '' };
    this.showForm = true;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  save(): void {
    if (!this.form.userName || !this.form.userEmail || !this.form.userPhone) {
      this.toast.error('Fill all required fields'); return;
    }
    this.saving.set(true);
    const obs = this.editingId
      ? this.userSvc.updateUser(this.editingId, this.form)
      : this.userSvc.createUser(this.form);
    obs.subscribe({
      next: () => {
        this.toast.success(this.editingId ? 'User updated!' : 'User created!');
        this.showForm = false; this.editingId = null; this.form = this.blank();
        this.load(); this.saving.set(false);
      },
      error: (e) => { this.toast.error(e.error?.message || 'Save failed'); this.saving.set(false); }
    });
  }

  deleteUser(u: UsersCreateDTO): void {
    if (!confirm(`Delete user "${u.userName}"?`)) return;
    this.userSvc.deleteUser(u.userId!).subscribe({
      next: () => { this.toast.success('User deleted'); this.load(); },
      error: () => this.toast.error('Delete failed')
    });
  }
}
