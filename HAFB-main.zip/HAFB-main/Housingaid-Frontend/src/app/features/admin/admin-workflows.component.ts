import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface WorkflowStep {
  icon: string;
  title: string;
  desc: string;
  service: string;
  endpoint: string;
  role: string;
}

@Component({
  selector: 'app-admin-workflows',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="page-content">
      <div class="page-header">
        <h1>System Workflows</h1>
        <p>End-to-end process flows mapped to backend endpoints</p>
      </div>

      <!-- Housing Application Workflow -->
      <div class="card mb-4">
        <div class="card-title">🏠 Housing Application Flow</div>
        <p style="font-size:13px;color:var(--text2);margin-bottom:20px">
          The complete lifecycle from citizen registration to housing allocation.
        </p>
        <div style="display:flex;flex-direction:column;gap:0">
          <div *ngFor="let step of applicationFlow; let i = index; let last = last"
               style="display:flex;gap:16px">
            <!-- connector -->
            <div style="display:flex;flex-direction:column;align-items:center;width:40px;flex-shrink:0">
              <div style="width:36px;height:36px;border-radius:50%;background:var(--amber);color:#0d0f14;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:14px;font-family:var(--font-head);flex-shrink:0">
                {{i+1}}
              </div>
              <div *ngIf="!last" style="width:2px;flex:1;background:var(--border);min-height:20px;margin:4px 0"></div>
            </div>
            <!-- content -->
            <div style="padding-bottom:20px;flex:1">
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;flex-wrap:wrap">
                <span style="font-size:18px">{{step.icon}}</span>
                <span style="font-weight:700;font-size:14px">{{step.title}}</span>
                <span class="badge badge-blue" style="font-size:10px">{{step.service}}</span>
                <span class="badge badge-amber" style="font-size:10px">{{step.role}}</span>
              </div>
              <p style="font-size:13px;color:var(--text2);margin-bottom:6px">{{step.desc}}</p>
              <code style="font-size:11px;font-family:var(--font-mono);color:var(--green);background:rgba(61,220,151,0.08);padding:3px 8px;border-radius:4px">
                {{step.endpoint}}
              </code>
            </div>
          </div>
        </div>
      </div>

      <!-- Compliance Workflow -->
      <div class="card mb-4">
        <div class="card-title">📋 Compliance & Audit Flow</div>
        <div style="display:flex;flex-direction:column;gap:0">
          <div *ngFor="let step of complianceFlow; let i = index; let last = last"
               style="display:flex;gap:16px">
            <div style="display:flex;flex-direction:column;align-items:center;width:40px;flex-shrink:0">
              <div style="width:36px;height:36px;border-radius:50%;background:var(--blue);color:#0d0f14;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:14px;font-family:var(--font-head)">
                {{i+1}}
              </div>
              <div *ngIf="!last" style="width:2px;flex:1;background:var(--border);min-height:20px;margin:4px 0"></div>
            </div>
            <div style="padding-bottom:20px;flex:1">
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;flex-wrap:wrap">
                <span style="font-size:18px">{{step.icon}}</span>
                <span style="font-weight:700;font-size:14px">{{step.title}}</span>
                <span class="badge badge-blue" style="font-size:10px">{{step.service}}</span>
                <span class="badge badge-amber" style="font-size:10px">{{step.role}}</span>
              </div>
              <p style="font-size:13px;color:var(--text2);margin-bottom:6px">{{step.desc}}</p>
              <code style="font-size:11px;font-family:var(--font-mono);color:var(--green);background:rgba(61,220,151,0.08);padding:3px 8px;border-radius:4px">
                {{step.endpoint}}
              </code>
            </div>
          </div>
        </div>
      </div>

      <!-- Microservice map -->
      <div class="card">
        <div class="card-title">🔌 Microservice API Map</div>
        <div class="grid-3" style="gap:12px">
          <div *ngFor="let svc of services"
               style="padding:16px;border:1px solid var(--border);border-radius:8px;background:var(--bg3)">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
              <span style="font-size:20px">{{svc.icon}}</span>
              <span style="font-weight:700;font-family:var(--font-head);font-size:13px">{{svc.name}}</span>
            </div>
            <div style="font-family:var(--font-mono);font-size:11px;color:var(--amber);margin-bottom:8px">
              {{svc.baseUrl}}
            </div>
            <div *ngFor="let ep of svc.endpoints"
                 style="font-size:11px;color:var(--text2);padding:2px 0;border-bottom:1px solid var(--border);display:flex;gap:6px;align-items:center">
              <span style="color:{{ep.method === 'GET' ? 'var(--green)' : ep.method === 'POST' ? 'var(--blue)' : ep.method === 'PUT' ? 'var(--amber)' : 'var(--red)'}};font-weight:700;width:36px;flex-shrink:0">
                {{ep.method}}
              </span>
              <span style="font-family:var(--font-mono)">{{ep.path}}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AdminWorkflowsComponent {
  applicationFlow: WorkflowStep[] = [
    { icon:'👤', title:'Citizen Registration', service:'Auth Service', role:'PUBLIC', endpoint:'POST /auths/auth/register-citizen', desc:'Citizen creates an account with personal details, DOB, and gender.' },
    { icon:'📁', title:'Document Upload', service:'Auth Service', role:'CITIZEN', endpoint:'POST /auths/citizen/{id}/documents/upload-document', desc:'Citizen uploads ID proof and income certificate for verification.' },
    { icon:'📄', title:'Submit Application', service:'Application Service', role:'CITIZEN/OFFICER', endpoint:'POST /application/housing-application/create', desc:'Citizen or officer submits a housing application for a specific project.' },
    { icon:'✅', title:'Eligibility Check', service:'Application Service', role:'OFFICER', endpoint:'POST /application/eligibility-check/submit', desc:'Officer reviews documents and submits eligibility result (ELIGIBLE/NOTELIGIBLE).' },
    { icon:'🏗', title:'Unit Availability', service:'Inventory Service', role:'OFFICER', endpoint:'GET /inventory/housing-unit/find-status', desc:'System checks for available housing units in the target project.' },
    { icon:'🏠', title:'Allocation', service:'Allocation Service', role:'OFFICER/ADMIN', endpoint:'POST /allocation/allocations/create', desc:'Officer creates an allocation linking the citizen to an available unit.' },
    { icon:'📊', title:'Compliance Check', service:'Compliance Service', role:'COMPLIANCE', endpoint:'POST /compliance/compliance-record/create-compliance-record', desc:'Compliance officer records the allocation compliance status.' },
    { icon:'📈', title:'Report Generation', service:'Notification Service', role:'AUDITOR/ADMIN', endpoint:'GET /notification/reports/generate/{scope}', desc:'Auditor generates monthly/quarterly/annual program reports.' },
  ];

  complianceFlow: WorkflowStep[] = [
    { icon:'🔍', title:'Schedule Audit', service:'Compliance Service', role:'COMPLIANCE', endpoint:'POST /compliance/audit/create-audit', desc:'Compliance officer schedules an audit with scope, findings and date.' },
    { icon:'📋', title:'Create Compliance Record', service:'Compliance Service', role:'COMPLIANCE', endpoint:'POST /compliance/compliance-record/create-compliance-record', desc:'Record compliance result (COMPLIANT/NONCOMPLIANT) for an entity.' },
    { icon:'📊', title:'Compliance Dashboard', service:'Compliance Service', role:'COMPLIANCE/ADMIN', endpoint:'GET /compliance/compliance-record/get-compliance-dashboard', desc:'View aggregated compliance data across projects, units and applications.' },
    { icon:'📝', title:'Update Audit Status', service:'Compliance Service', role:'COMPLIANCE', endpoint:'PUT /compliance/audit/update-audit', desc:'Update audit status to COMPLETED or FLAGGED after review.' },
    { icon:'📈', title:'Audit Log', service:'Auth Service', role:'ADMIN', endpoint:'GET /auths/audit-log/get-all-audit-logs', desc:'Admin reviews all system actions logged through the audit trail.' },
  ];

  services = [
    {
      icon:'🔐', name:'Auth Service', baseUrl:'/auths',
      endpoints:[
        {method:'POST', path:'/auth/login'}, {method:'POST', path:'/auth/register-citizen'},
        {method:'GET', path:'/admin/get-all-users'}, {method:'POST', path:'/admin/create-user'},
        {method:'GET', path:'/citizen/get-all-citizens'}, {method:'POST', path:'/citizen/{id}/documents/upload-document'},
        {method:'GET', path:'/audit-log/get-all-audit-logs'},
      ]
    },
    {
      icon:'🏗', name:'Inventory Service', baseUrl:'/inventory',
      endpoints:[
        {method:'GET', path:'/housing-project/get-all-housing-projects'}, {method:'POST', path:'/housing-project/create-housing-project'},
        {method:'GET', path:'/housing-unit/get-all-housing-units'}, {method:'POST', path:'/housing-unit/create-housing-unit'},
        {method:'GET', path:'/resources/get-all-resources'}, {method:'POST', path:'/resources/create-resources'},
      ]
    },
    {
      icon:'📄', name:'Application Service', baseUrl:'/application',
      endpoints:[
        {method:'POST', path:'/housing-application/create'}, {method:'GET', path:'/housing-application/all'},
        {method:'PUT', path:'/housing-application/update-status'}, {method:'POST', path:'/eligibility-check/submit'},
        {method:'GET', path:'/eligibility-check/history'},
      ]
    },
    {
      icon:'🏠', name:'Allocation Service', baseUrl:'/allocation',
      endpoints:[
        {method:'POST', path:'/allocations/create'}, {method:'GET', path:'/allocations/get-all-Allocation'},
        {method:'GET', path:'/allocations/total'}, {method:'GET', path:'/allocations/count/{status}'},
      ]
    },
    {
      icon:'📋', name:'Compliance Service', baseUrl:'/compliance',
      endpoints:[
        {method:'POST', path:'/compliance-record/create-compliance-record'}, {method:'GET', path:'/compliance-record/get-all-compliance-records'},
        {method:'POST', path:'/audit/create-audit'}, {method:'GET', path:'/audit/get-all-audits'},
        {method:'GET', path:'/compliance-record/get-compliance-dashboard'},
      ]
    },
    {
      icon:'📊', name:'Notification Service', baseUrl:'/notification',
      endpoints:[
        {method:'GET', path:'/reports/generate/{scope}'}, {method:'GET', path:'/reports/get-all-reports'},
        {method:'DELETE', path:'/reports/Delete-reportof-{id}'},
      ]
    },
  ];
}
