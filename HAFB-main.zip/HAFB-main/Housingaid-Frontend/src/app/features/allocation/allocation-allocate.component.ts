import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AllocationService, HousingApplicationService, HousingProjectService, CitizenService } from '../../core/services/api.services';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { HousingApplicationDTO, HousingProjectDTO, CitizenDTO, AllocationResponseDTO } from '../../core/models/models';

interface AllocationCandidate {
  applicationId: number;
  citizenId: number;
  citizenName: string;
  projectId: number;
  projectScheme: string;
  housingCapacity?: number;
  unitType?: string;
}

interface AllocationHistory {
  allocationId: number;
  citizenName: string;
  projectScheme: string;
  allocationMessage?: string;
  status: string;
}

@Component({
  selector: 'app-allocation-allocate',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-content">
      <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap">
        <div>
          <h1>Allocation</h1>
          <p>Choose approved applications and allocate housing units.</p>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Allocation Candidates</div>
        <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
        <div *ngIf="!loading() && rows().length === 0" class="empty-state">
          <div class="empty-state-icon">🏠</div>
          <p>No approved applications available for allocation.</p>
        </div>
        <div *ngIf="!loading() && rows().length > 0" class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>S.No</th>
                <th>Citizen Name</th>
                <th>Project Scheme</th>
                <th>Housing Capacity</th>
                <th>Unit Type</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let row of rows(); let i = index">
                <td class="td-mono">{{ i + 1 }}</td>
                <td>{{ row.citizenName }}</td>
                <td>{{ row.projectScheme }}</td>
                <td>{{ row.housingCapacity ?? '-' }}</td>
                <td>{{ row.unitType ?? '-' }}</td>
                <td>
                  <button class="btn btn-primary btn-sm" (click)="redirectToFinalize(row)">
                    Allocate
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="card">
        <div class="card-title">Allocation History</div>
        <div *ngIf="historyLoading()" class="loading-overlay"><span class="spinner"></span></div>
        <div *ngIf="!historyLoading() && historyRows().length === 0" class="empty-state">
          <div class="empty-state-icon">📋</div>
          <p>No allocation history available.</p>
        </div>
        <div *ngIf="!historyLoading() && historyRows().length > 0" class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>S.No</th>
                <th>Citizen Name</th>
                <th>Project Scheme</th>
                <th>Allocation Message</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let row of historyRows(); let i = index">
                <td class="td-mono">{{ i + 1 }}</td>
                <td>{{ row.citizenName }}</td>
                <td>{{ row.projectScheme }}</td>
                <td>{{ row.allocationMessage || '-' }}</td>
                <td>{{ row.status }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `
})
export class AllocationAllocateComponent implements OnInit {
  private allocSvc = inject(AllocationService);
  private projectSvc = inject(HousingProjectService);
  private appSvc = inject(HousingApplicationService);
  private citizenSvc = inject(CitizenService);
  private router = inject(Router);
  private auth = inject(AuthService);
  private toast = inject(ToastService);

  loading = signal(true);
  historyLoading = signal(true);
  submitting = signal(false);
  projects = signal<HousingProjectDTO[]>([]);
  candidates = signal<AllocationCandidate[]>([]);
  rows = signal<AllocationCandidate[]>([]);
  history = signal<AllocationResponseDTO[]>([]);
  historyRows = signal<AllocationHistory[]>([]);

  ngOnInit(): void {
    this.loadData();
    const nav = this.router.getCurrentNavigation();
    if (nav?.extras.state?.['allocatedId']) {
      this.removeCandidate(nav.extras.state['allocatedId']);
      this.loadHistory();
    }
  }

  loadData(): void {
    this.loading.set(true);
    this.historyLoading.set(true);

    this.projectSvc.getAll().subscribe({
      next: projects => {
        this.projects.set(projects);
        this.appSvc.getByStatus('APPROVED').subscribe({
          next: apps => {
            this.citizenSvc.getAllCitizens().subscribe({
              next: citizens => {
                this.buildCandidates(apps, citizens, projects);
                this.loading.set(false);
                this.loadHistory();
              },
              error: () => { this.toast.error('Failed to load citizen data'); this.loading.set(false); }
            });
          },
          error: () => { this.toast.error('Failed to load approved applications'); this.loading.set(false); }
        });
      },
      error: () => { this.toast.error('Failed to load projects'); this.loading.set(false); }
    });
  }

  buildCandidates(apps: HousingApplicationDTO[], citizens: CitizenDTO[], projects: HousingProjectDTO[]): void {
    const rows = apps.map(app => ({
      applicationId: app.housingApplicationId ?? 0,
      citizenId: app.citizenId,
      citizenName: citizens.find(c => c.citizenId === app.citizenId)?.citizenName || `Citizen #${app.citizenId}`,
      projectId: app.housingProjectId,
      projectScheme: projects.find(p => p.housingProjectId === app.housingProjectId)?.housingProjectTitle || `Project #${app.housingProjectId}`,
      housingCapacity: app.housingCapacity,
      unitType: app.housingUnitType
    }));

    this.candidates.set(rows);
    this.rows.set(rows);
  }

  loadHistory(): void {
    this.historyLoading.set(true);
    this.allocSvc.getAll().subscribe({
      next: history => {
        this.history.set(history);
        this.buildHistory(history, this.citizenSvc, this.projects());
        this.historyLoading.set(false);
      },
      error: () => { this.toast.error('Failed to load allocation history'); this.historyLoading.set(false); }
    });
  }

  buildHistory(history: AllocationResponseDTO[], citizenSvc: CitizenService, projects: HousingProjectDTO[]): void {
    citizenSvc.getAllCitizens().subscribe({
      next: citizens => {
        const rows = history.map(h => ({
          allocationId: h.allocationId,
          citizenName: citizens.find(c => c.citizenId === h.citizenId)?.citizenName || `Citizen #${h.citizenId}`,
          projectScheme: projects.find(p => p.housingProjectId === h.housingProjectId)?.housingProjectTitle || `Project #${h.housingProjectId}`,
          allocationMessage: h.allocationMessage,
          status: h.status
        }));
        this.historyRows.set(rows);
      },
      error: () => this.toast.error('Failed to load citizens for history')
    });
  }

  removeCandidate(applicationId: number): void {
    this.candidates.update(c => c.filter(can => can.applicationId !== applicationId));
    this.rows.update(r => r.filter(row => row.applicationId !== applicationId));
  }

  redirectToFinalize(row: AllocationCandidate): void {
    if (!row.applicationId) {
      this.toast.error('Invalid allocation row');
      return;
    }
    this.router.navigate(['/dashboard/allocation-finalize', row.applicationId]);
  }
}
