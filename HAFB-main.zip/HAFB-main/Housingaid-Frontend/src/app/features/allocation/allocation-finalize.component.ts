

import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AllocationService, HousingApplicationService, HousingProjectService, CitizenService } from '../../core/services/api.services';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { HousingApplicationDTO, HousingProjectDTO, CitizenDTO, AllocationRequestDTO } from '../../core/models/models';

@Component({
  selector: 'app-allocation-finalize',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-content">
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px">
        <div>
          <h1>Finalize Allocation</h1>
          <p>Confirm the selected allocation details and send a message to the citizen.</p>
        </div>
        <button class="btn btn-ghost" (click)="goBack()">← Back to List</button>
      </div>

      <div class="card">
        <div class="card-title">Allocation Summary</div>
        <div style="padding:24px;background:rgba(228,243,255,0.8);border:1px solid rgba(132,173,242,0.5);border-radius:16px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:24px;text-align:center">
          <div>
            <div class="text-label">Citizen Name</div>
            <div class="text-strong">{{ citizen?.citizenName || '—' }}</div>
          </div>
          <div>
            <div class="text-label">Unit Type</div>
            <div class="text-strong">{{ application?.housingUnitType || '—' }}</div>
          </div>
          <div>
            <div class="text-label">Capacity</div>
            <div class="text-strong">{{ application?.housingCapacity || '—' }} Persons</div>
          </div>
        </div>

        <div style="margin-top:24px">
          <label class="form-label">Allocation Message</label>
          <textarea class="form-textarea" rows="6" [(ngModel)]="allocationMessage" placeholder="Enter message to be sent to the citizen regarding their allocation..."></textarea>
        </div>

        <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:24px">
          <button class="btn btn-secondary" (click)="goBack()">Cancel</button>
          <button class="btn btn-primary" (click)="submitAllocation()" [disabled]="submitting() || !application">
            <span *ngIf="submitting()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
            {{ submitting() ? 'Submitting...' : 'Submit Allocated' }}
          </button>
        </div>
      </div>
    </div>
  `
})
export class AllocationFinalizeComponent implements OnInit {
  private allocSvc = inject(AllocationService);
  private appSvc = inject(HousingApplicationService);
  private projectSvc = inject(HousingProjectService);
  private citizenSvc = inject(CitizenService);
  private auth = inject(AuthService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  submitting = signal(false);
  application: HousingApplicationDTO | null = null;
  project: HousingProjectDTO | null = null;
  citizen: CitizenDTO | null = null;
  allocationMessage = '';

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const appId = Number(params.get('applicationId'));
      if (!appId) {
        this.toast.error('Invalid allocation selection');
        this.goBack();
        return;
      }
      this.loadApplication(appId);
    });
  }

  loadApplication(applicationId: number): void {
    this.appSvc.getById(applicationId).subscribe({
      next: app => {
        this.application = app;
        this.loadProject(app.housingProjectId);
        this.loadCitizen(app.citizenId);
      },
      error: () => this.toast.error('Failed to load application details')
    });
  }

  loadProject(projectId: number): void {
    this.projectSvc.getById(projectId).subscribe({
      next: project => this.project = project,
      error: () => this.toast.error('Failed to load project details')
    });
  }

  loadCitizen(citizenId: number): void {
    this.citizenSvc.getCitizenById(citizenId).subscribe({
      next: citizen => this.citizen = citizen,
      error: () => this.toast.error('Failed to load citizen details')
    });
  }

  submitAllocation(): void {
    if (!this.application) {
      this.toast.error('No allocation to submit');
      return;
    }

    this.submitting.set(true);
    const request: AllocationRequestDTO = {
      citizenId: this.application.citizenId,
      officerId: this.auth.currentUser?.userId ?? 1,
      housingProjectId: this.application.housingProjectId,
      allocationMessage: this.allocationMessage?.trim()
    };

    this.allocSvc.create(request).subscribe({
      next: () => {
        this.toast.success('Allocation submitted successfully');
        this.submitting.set(false);
        this.router.navigate(['/dashboard/allocation-allocate'], { state: { allocatedId: this.application?.housingApplicationId } });
      },
      error: (e) => {
        this.toast.error(e.error?.message || 'Allocation submission failed');
        this.submitting.set(false);
      }
    });
  }

  goBack(): void {
    this.router.navigate(['/dashboard/allocation-allocate']);
  }
}
