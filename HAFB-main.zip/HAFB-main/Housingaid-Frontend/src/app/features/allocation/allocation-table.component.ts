import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AllocationService } from '../../core/services/api.services';
import { AllocationResponseDTO } from '../../core/models/models';
import { StatusBadgeComponent } from '../../shared/components/status-badge.component';

@Component({
  selector: 'app-allocation-table',
  standalone: true,
  imports: [CommonModule, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <h1>All Allocations</h1>
          <p>Complete history of housing unit allocations</p>
        </div>
        <button class="btn btn-ghost" (click)="load()">↻ Refresh</button>
      </div>

      <!-- Stats -->
      <div class="grid-4 mb-4">
        <div class="stat-card amber">
          <div class="stat-icon">🏠</div>
          <div class="stat-value text-amber">{{allocations().length}}</div>
          <div class="stat-label">Total Allocations</div>
        </div>
        <div class="stat-card green">
          <div class="stat-icon">✅</div>
          <div class="stat-value text-green">{{countByStatus('ACTIVE')}}</div>
          <div class="stat-label">Active</div>
        </div>
        <div class="stat-card blue">
          <div class="stat-icon">📋</div>
          <div class="stat-value" style="color:var(--blue)">{{countByStatus('COMPLETED')}}</div>
          <div class="stat-label">Completed</div>
        </div>
        <div class="stat-card red">
          <div class="stat-icon">✕</div>
          <div class="stat-value text-red">{{countByStatus('CANCELLED')}}</div>
          <div class="stat-label">Cancelled</div>
        </div>
      </div>

      <div class="card">
        <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
        <div *ngIf="!loading() && allocations().length === 0" class="empty-state">
          <div class="empty-state-icon">🏠</div>
          <p>No allocations found</p>
        </div>
        <div *ngIf="!loading() && allocations().length > 0" class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Allocation ID</th>
                <th>Citizen ID</th>
                <th>Unit ID</th>
                <th>Project ID</th>
                <th>Status</th>
                <th>Message</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let a of allocations()">
                <td class="td-mono">#{{a.allocationId}}</td>
                <td class="td-mono">#{{a.citizenId}}</td>
                <td class="td-mono">#{{a.housingunitId}}</td>
                <td class="td-mono">#{{a.housingProjectId}}</td>
                <td><app-status-badge [status]="a.status" /></td>
                <td style="font-size:12px;color:var(--text2)">{{a.message}}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class AllocationTableComponent implements OnInit {
  private allocSvc = inject(AllocationService);

  loading = signal(true);
  allocations = signal<AllocationResponseDTO[]>([]);

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.allocSvc.getAll().subscribe({
      next: a => { this.allocations.set(a); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  countByStatus(s: string): number {
    return this.allocations().filter(a => (a.status ?? '').toUpperCase() === s).length;
  }
}
