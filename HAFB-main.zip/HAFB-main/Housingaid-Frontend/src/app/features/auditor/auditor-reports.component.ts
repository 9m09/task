import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReportService } from '../../core/services/api.services';
import { ToastService } from '../../core/services/toast.service';
import { ReportDTO, ReportScope } from '../../core/models/models';

@Component({
  selector: 'app-auditor-reports',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-content">
      <div class="page-header">
        <h1>Reports</h1>
        <p>Generate and manage system-wide housing aid reports</p>
      </div>

      <!-- Generate panel -->
      <div class="grid-2 mb-4">
        <div class="card">
          <div class="card-title">Generate New Report</div>
          <p style="font-size:13px;color:var(--text2);margin-bottom:16px">
            Select a scope to generate an automated report with current system metrics.
          </p>
          <div class="form-group">
            <label class="form-label">Report Scope</label>
            <select class="form-select" [(ngModel)]="selectedScope">
              <option value="ALLOCATION">ALLOCATION</option>
              <option value="HOUSINGAPPLICATION">HOUSINGAPPLICATION</option>
              <option value="HOUSINGPROJECT">HOUSINGPROJECT</option>
            </select>
          </div>
          <button class="btn btn-primary w-full mt-2" (click)="generate()" [disabled]="generating()">
            <span *ngIf="generating()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
            {{ generating() ? 'Generating...' : '📊 Generate Report' }}
          </button>
        </div>

        <!-- Last generated -->
        <div class="card" *ngIf="lastGenerated()">
          <div class="card-title">Latest Generated</div>
          <div style="padding:16px;background:rgba(61,220,151,0.08);border:1px solid rgba(61,220,151,0.2);border-radius:8px">
            <div style="font-size:18px;font-weight:800;font-family:var(--font-head);margin-bottom:8px;color:var(--green)">
              {{lastGenerated()!.scope}} Report
            </div>
            <div class="info-grid">
              <div class="info-row">
                <span class="info-label">Report ID</span>
                <span class="info-value">#{{lastGenerated()!.reportId}}</span>
              </div>
              <div class="info-row">
                <span class="info-label">Generated</span>
                <span class="info-value">{{lastGenerated()!.generatedDate | date:'medium'}}</span>
              </div>
            </div>
            <div *ngIf="lastGenerated()!.metrics" style="margin-top:12px;padding:10px;background:var(--bg3);border-radius:6px;font-family:var(--font-mono);font-size:12px;color:var(--text2);white-space:pre-wrap">
              {{lastGenerated()!.metrics}}
            </div>
          </div>
        </div>
      </div>

      <!-- All reports -->
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid var(--border)">
          <div class="card-title" style="margin:0;padding:0;border:none">All Reports ({{reports().length}})</div>
          <button class="btn btn-ghost btn-sm" (click)="loadReports()">↻ Refresh</button>
        </div>
        <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
        <div *ngIf="!loading() && reports().length === 0" class="empty-state">
          <div class="empty-state-icon">📊</div>
          <p>No reports generated yet</p>
        </div>
        <div *ngIf="!loading() && reports().length > 0" class="table-wrap">
          <table>
            <thead>
              <tr><th>ID</th><th>Scope</th><th>Generated Date</th><th>Metrics Preview</th><th>Actions</th></tr>
            </thead>
            <tbody>
              <tr *ngFor="let r of reports()">
                <td class="td-mono">#{{r.reportId}}</td>
                <td>
                  <span class="badge" [class]="scopeBadge(r.scope)">{{r.scope}}</span>
                </td>
                <td class="td-mono">{{r.generatedDate | date:'mediumDate'}}</td>
                <td style="font-size:12px;color:var(--text2);max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                  {{r.metrics || '—'}}
                </td>
                <td>
                  <button class="btn btn-danger btn-sm" (click)="deleteReport(r)">🗑 Delete</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class AuditorReportsComponent implements OnInit {
  private reportSvc = inject(ReportService);
  private toast = inject(ToastService);

  loading = signal(true);
  generating = signal(false);
  reports = signal<ReportDTO[]>([]);
  lastGenerated = signal<ReportDTO | null>(null);
  selectedScope: ReportScope = 'ALLOCATION' as ReportScope;

  ngOnInit(): void { this.loadReports(); }

  loadReports(): void {
    this.loading.set(true);
    this.reportSvc.getAll().subscribe({
      next: r => { this.reports.set(r); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  generate(): void {
    this.generating.set(true);
    this.reportSvc.generate(this.selectedScope).subscribe({
      next: r => {
        this.lastGenerated.set(r);
        this.toast.success(`${this.selectedScope} report generated!`);
        this.generating.set(false);
        this.loadReports();
      },
      error: (e) => { this.toast.error(e.error?.message || 'Generation failed'); this.generating.set(false); }
    });
  }

  deleteReport(r: ReportDTO): void {
    if (!confirm('Delete this report?')) return;
    this.reportSvc.delete(r.reportId!).subscribe({
      next: () => { this.toast.success('Report deleted'); this.loadReports(); },
      error: () => this.toast.error('Delete failed')
    });
  }

  scopeBadge(scope: string): string {
    const map: Record<string, string> = { MONTHLY: 'badge-blue', QUARTERLY: 'badge-amber', ANNUAL: 'badge-green' };
    return map[scope] ?? 'badge-grey';
  }
}
