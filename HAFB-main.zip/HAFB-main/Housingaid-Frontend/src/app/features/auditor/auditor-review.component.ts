import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  HousingProjectService, HousingApplicationService,
  AllocationService, ComplianceRecordService
} from '../../core/services/api.services';
import { forkJoin } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { StatusBadgeComponent } from '../../shared/components/status-badge.component';

@Component({
  selector: 'app-auditor-review',
  standalone: true,
  imports: [CommonModule, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <h1>Program Review</h1>
          <p>Cross-service overview of the entire housing aid program</p>
        </div>
        <button class="btn btn-ghost" (click)="load()">↻ Refresh All</button>
      </div>

      <div *ngIf="loading()" class="loading-overlay" style="padding:100px">
        <span class="spinner"></span> Loading program data…
      </div>

      <div *ngIf="!loading()">
        <!-- KPI Row -->
        <div class="grid-4 mb-4">
          <div class="stat-card amber">
            <div class="stat-icon">🏗</div>
            <div class="stat-value text-amber">{{stats.totalProjects}}</div>
            <div class="stat-label">Total Projects</div>
            <div class="stat-delta text-muted">{{stats.completedProjects}} completed</div>
          </div>
          <div class="stat-card blue">
            <div class="stat-icon">📋</div>
            <div class="stat-value" style="color:var(--blue)">{{stats.totalApplications}}</div>
            <div class="stat-label">Applications</div>
            <div class="stat-delta text-muted">{{stats.approvedApplications}} approved</div>
          </div>
          <div class="stat-card green">
            <div class="stat-icon">🏠</div>
            <div class="stat-value text-green">{{stats.totalAllocations}}</div>
            <div class="stat-label">Allocations</div>
            <div class="stat-delta text-muted">Units assigned</div>
          </div>
          <div class="stat-card amber">
            <div class="stat-icon">💰</div>
            <div class="stat-value text-amber">₹{{formatBudget(stats.totalBudget)}}</div>
            <div class="stat-label">Total Budget</div>
            <div class="stat-delta text-muted">Across all projects</div>
          </div>
        </div>

        <!-- Application pipeline -->
        <div class="grid-2 mb-4">
          <div class="card">
            <div class="card-title">Application Pipeline</div>
            <div *ngFor="let item of pipeline" style="margin-bottom:12px">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
                <span style="font-size:13px">{{item.label}}</span>
                <span style="font-family:var(--font-mono);font-size:13px;font-weight:600"
                      [style.color]="item.color">{{item.value}}</span>
              </div>
              <div style="height:6px;background:var(--border);border-radius:99px;overflow:hidden">
                <div style="height:100%;border-radius:99px;transition:width 0.4s ease"
                     [style.width]="getPercent(item.value)+'%'"
                     [style.background]="item.color"></div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-title">Project Status Breakdown</div>
            <div *ngFor="let item of projectBreakdown" style="margin-bottom:12px">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
                <span style="font-size:13px">{{item.label}}</span>
                <span style="font-family:var(--font-mono);font-size:13px;font-weight:600"
                      [style.color]="item.color">{{item.value}}</span>
              </div>
              <div style="height:6px;background:var(--border);border-radius:99px;overflow:hidden">
                <div style="height:100%;border-radius:99px"
                     [style.width]="getProjectPercent(item.value)+'%'"
                     [style.background]="item.color"></div>
              </div>
            </div>
          </div>
        </div>

        <!-- Recent projects table -->
        <div class="card">
          <div class="card-title">Projects Overview</div>
          <div class="table-wrap">
            <table>
              <thead>
                <tr><th>ID</th><th>Title</th><th>Houses</th><th>Budget</th><th>Start</th><th>End</th><th>Status</th></tr>
              </thead>
              <tbody>
                <tr *ngFor="let p of projects()">
                  <td class="td-mono">#{{p.housingProjectId}}</td>
                  <td style="font-weight:600">{{p.housingProjectTitle}}</td>
                  <td class="td-mono">{{p.numberOfHouses}}</td>
                  <td class="td-mono">₹{{p.housingProjectBudget?.toLocaleString()}}</td>
                  <td class="td-mono">{{p.housingProjectStartDate}}</td>
                  <td class="td-mono">{{p.housingProjectEndDate}}</td>
                  <td><app-status-badge [status]="p.housingProjectStatus" /></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `
})
export class AuditorReviewComponent implements OnInit {
  private projectSvc = inject(HousingProjectService);
  private appSvc = inject(HousingApplicationService);
  private allocSvc = inject(AllocationService);

  loading = signal(true);
  projects = signal<any[]>([]);

  stats = {
    totalProjects: 0, completedProjects: 0,
    totalApplications: 0, approvedApplications: 0,
    totalAllocations: 0, totalBudget: 0
  };

  pipeline: any[] = [];
  projectBreakdown: any[] = [];

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    forkJoin({
      projects: this.projectSvc.getAll().pipe(catchError(() => of([]))),
      apps: this.appSvc.getAll().pipe(catchError(() => of([]))),
      allocs: this.allocSvc.getAll().pipe(catchError(() => of([]))),
      budget: this.projectSvc.getTotalBudget().pipe(catchError(() => of(0)))
    }).subscribe({
      next: ({ projects, apps, allocs, budget }) => {
        this.projects.set(projects as any[]);
        this.stats.totalProjects = (projects as any[]).length;
        this.stats.completedProjects = (projects as any[]).filter((p: any) => p.housingProjectStatus === 'COMPLETED').length;
        this.stats.totalApplications = (apps as any[]).length;
        this.stats.approvedApplications = (apps as any[]).filter((a: any) => a.housingApplicationStatus === 'APPROVED').length;
        this.stats.totalAllocations = (allocs as any[]).length;
        this.stats.totalBudget = budget as number ?? 0;

        const pending = (apps as any[]).filter((a: any) => a.housingApplicationStatus === 'PENDING').length;
        const underReview = (apps as any[]).filter((a: any) => a.housingApplicationStatus === 'UNDER_REVIEW').length;
        const rejected = (apps as any[]).filter((a: any) => a.housingApplicationStatus === 'REJECTED').length;

        this.pipeline = [
          { label: 'Pending', value: pending, color: 'var(--amber)' },
          { label: 'Under Review', value: underReview, color: 'var(--blue)' },
          { label: 'Approved', value: this.stats.approvedApplications, color: 'var(--green)' },
          { label: 'Rejected', value: rejected, color: 'var(--red)' },
        ];

        const planned = (projects as any[]).filter((p: any) => p.housingProjectStatus === 'PLANNED').length;
        const inProgress = (projects as any[]).filter((p: any) => p.housingProjectStatus === 'UNDERPROGRESS').length;
        this.projectBreakdown = [
          { label: 'Planned', value: planned, color: 'var(--text2)' },
          { label: 'Under Progress', value: inProgress, color: 'var(--blue)' },
          { label: 'Completed', value: this.stats.completedProjects, color: 'var(--green)' },
        ];

        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  getPercent(val: number): number {
    return this.stats.totalApplications ? Math.round((val / this.stats.totalApplications) * 100) : 0;
  }

  getProjectPercent(val: number): number {
    return this.stats.totalProjects ? Math.round((val / this.stats.totalProjects) * 100) : 0;
  }

  formatBudget(n: number): string {
    if (n >= 10000000) return (n / 10000000).toFixed(1) + 'Cr';
    if (n >= 100000) return (n / 100000).toFixed(1) + 'L';
    return n?.toLocaleString() ?? '0';
  }
}
