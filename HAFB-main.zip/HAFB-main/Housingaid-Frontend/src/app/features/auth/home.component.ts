import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { ThemeService } from '../../core/services/theme.service';
import { ToastService } from '../../core/services/toast.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="home-page">
      <div class="home-grid-bg"></div>
      <div class="home-accent"></div>

      <nav class="home-nav">
        <div class="home-logo">
          <div class="home-logo-icon">🏠</div>
          HousingAid
        </div>
        <div style="margin-left:auto; display:flex; align-items:center; gap:10px;">
          <button class="btn btn-ghost btn-sm" (click)="toggleTheme()">
            {{ theme() === 'dark' ? '☀️ Light Mode' : '🌙 Dark Mode' }}
          </button>
          <span style="font-family:var(--font-mono);font-size:11px;color:var(--text3)">
            AFFORDABLE SHELTER MANAGEMENT SYSTEM
          </span>
        </div>
      </nav>

      <div class="home-hero">
        <div class="home-hero-text">
          <div class="home-eyebrow">Government Housing Portal</div>
          <h1 class="home-title">
            <span>Affordable</span><br>Housing<br>Management
          </h1>
          <p class="home-desc">
            A unified platform for managing housing applications, allocations,
            compliance records, and inventory across all departments.
          </p>
          <div class="home-cta-row">
            <button class="btn btn-primary" (click)="activeTab='login'">Sign In</button>
            <button class="btn btn-ghost" (click)="activeTab='register'">Register as Citizen</button>
          </div>
          <div class="home-stats">
            <div>
              <div class="home-stat-val">6</div>
              <div class="home-stat-label">User Roles</div>
            </div>
            <div>
              <div class="home-stat-val">8</div>
              <div class="home-stat-label">Microservices</div>
            </div>
            <div>
              <div class="home-stat-val">100%</div>
              <div class="home-stat-label">Tracked</div>
            </div>
          </div>
        </div>

        <!-- Auth Card -->
        <div class="auth-card-wrapper">
          <div class="auth-card-title">
            {{ activeTab === 'login' ? 'Sign In' : 'Create Account' }}
          </div>
          <div class="auth-card-sub">
            {{ activeTab === 'login' ? 'Access your HousingAid portal' : 'Register as a citizen applicant' }}
          </div>

          <div class="auth-tabs">
            <button class="auth-tab" [class.active]="activeTab==='login'" (click)="activeTab='login'">Login</button>
            <button class="auth-tab" [class.active]="activeTab==='register'" (click)="activeTab='register'">Register</button>
          </div>

          <!-- Login Form -->
          <div *ngIf="activeTab === 'login'">
            <div class="form-group">
              <label class="form-label">Email</label>
              <input class="form-input" type="email" [(ngModel)]="loginEmail" placeholder="officer@housingaid.gov" />
            </div>
            <div class="form-group">
              <label class="form-label">Password</label>
              <input class="form-input" type="password" [(ngModel)]="loginPassword" placeholder="••••••••"
                     (keydown.enter)="handleLogin()" />
            </div>
            <button class="btn btn-primary w-full mt-2" (click)="handleLogin()" [disabled]="loading()">
              <span *ngIf="loading()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
              {{ loading() ? 'Signing in...' : 'Sign In' }}
            </button>
          </div>

          <!-- Register Form -->
          <div *ngIf="activeTab === 'register'">
            <div class="grid-2">
              <div class="form-group">
                <label class="form-label">Full Name</label>
                <input class="form-input" [(ngModel)]="reg.userName" placeholder="Arjun Mehta" />
              </div>
              <div class="form-group">
                <label class="form-label">Gender</label>
                <select class="form-select" [(ngModel)]="reg.citizenGender">
                  <option value="MALE">Male</option>
                  <option value="FEMALE">Female</option>
                  <option value="OTHER">Other</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Email</label>
              <input class="form-input" type="email" [(ngModel)]="reg.userEmail" placeholder="arjun@example.com" />
            </div>
            <div class="form-group">
              <label class="form-label">Password</label>
              <input class="form-input" type="password" [(ngModel)]="reg.userPassword" placeholder="Min 8 characters" />
            </div>
            <div class="form-group">
              <label class="form-label">Contact Info</label>
              <input class="form-input" [(ngModel)]="reg.citizenContactInfo" placeholder="+91 98765 43210" />
            </div>
            <div class="form-group">
              <label class="form-label">Address</label>
              <input class="form-input" [(ngModel)]="reg.citizenAddress" placeholder="123 Main Street, City" />
            </div>
            <div class="form-group">
              <label class="form-label">Date of Birth</label>
              <input class="form-input" type="date" [(ngModel)]="reg.citizenDOB" />
            </div>
            <button class="btn btn-primary w-full mt-2" (click)="handleRegister()" [disabled]="loading()">
              <span *ngIf="loading()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
              {{ loading() ? 'Registering...' : 'Create Account' }}
            </button>
          </div>

          <div style="margin-top:20px;padding-top:16px;border-top:1px solid var(--border);font-size:12px;color:var(--text3);text-align:center">
            Secure government portal · All actions are logged
          </div>
        </div>
      </div>
    </div>
  `
})
export class HomeComponent {
  private auth = inject(AuthService);
  private router = inject(Router);
  private toast = inject(ToastService);
  private themeService = inject(ThemeService);

  theme = this.themeService.theme;
  activeTab: 'login' | 'register' = 'login';
  loading = signal(false);

  loginEmail = '';
  loginPassword = '';

  reg = {
    userName: '',
    userEmail: '',
    userPassword: '',
    citizenContactInfo: '',
    citizenAddress: '',
    citizenDOB: '',
    citizenGender: 'MALE' as any
  };

  toggleTheme(): void {
    this.themeService.toggle();
  }

  handleLogin(): void {
    if (!this.loginEmail || !this.loginPassword) {
      this.toast.error('Please enter email and password');
      return;
    }
    this.loading.set(true);
    this.auth.login({ email: this.loginEmail, password: this.loginPassword }).subscribe({
      next: () => {
        this.toast.success('Welcome back!');
        this.router.navigate(['/dashboard']);
      },
      error: (e) => {
        this.toast.error(e.error?.message || 'Invalid credentials');
        this.loading.set(false);
      }
    });
  }

  handleRegister(): void {
    const { userName, userEmail, userPassword, citizenContactInfo, citizenAddress, citizenDOB, citizenGender } = this.reg;
    if (!userName || !userEmail || !userPassword || !citizenAddress || !citizenDOB) {
      this.toast.error('Please fill all required fields');
      return;
    }
    this.loading.set(true);
    this.auth.registerCitizen({ userName, userEmail, userPassword, citizenContactInfo, citizenAddress, citizenDOB, citizenGender }).subscribe({
      next: () => {
        this.toast.success('Account created! Please log in.');
        this.activeTab = 'login';
        this.loading.set(false);
      },
      error: (e) => {
        this.toast.error(e.error?.message || 'Registration failed');
        this.loading.set(false);
      }
    });
  }
}
