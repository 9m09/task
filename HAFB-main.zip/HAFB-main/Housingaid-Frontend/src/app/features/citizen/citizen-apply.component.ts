import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { HousingApplicationService, HousingProjectService, CitizenService } from '../../core/services/api.services';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { HousingApplicationRequestDTO, HousingProjectDTO, HousingUnitType } from '../../core/models/models';

@Component({
  selector: 'app-citizen-apply',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="page-content">
      <div class="page-header">
        <h1>Apply for Housing</h1>
        <p>Submit your housing application to available projects</p>
      </div>

      <div class="grid-2">
        <div>
          <div class="card mb-4">
            <div class="card-title">Available Projects</div>
            <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
            <div *ngIf="!loading() && projects().length === 0" class="empty-state">
              <div class="empty-state-icon">🏗</div>
              <p>No projects available</p>
            </div>
            <div *ngFor="let p of projects()"
                 class="project-option"
                 [class.selected]="selectedProject?.housingProjectId === p.housingProjectId"
                 (click)="selectProject(p)"
                 style="padding:14px;border:1px solid var(--border);border-radius:8px;cursor:pointer;margin-bottom:8px;transition:all 0.15s">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                <span style="font-weight:600;font-size:14px">{{p.housingProjectTitle}}</span>
                <span class="badge badge-{{statusColor(p.housingProjectStatus)}}">{{p.housingProjectStatus}}</span>
              </div>
              <div style="font-size:12px;color:var(--text2)">{{p.housingProjectDescription}}</div>
              <div style="display:flex;gap:16px;margin-top:8px;font-size:11px;font-family:var(--font-mono);color:var(--text3)">
                <span>Units: {{p.numberOfHouses}}</span>
                <span>Budget: ₹{{p.housingProjectBudget.toLocaleString()}}</span>
                <span>End: {{p.housingProjectEndDate}}</span>
              </div>
            </div>
          </div>
        </div>

        <div class="card">
          <div class="card-title">Application Details</div>
          <div *ngIf="selectedProject; else noProject">
            <div style="padding:12px;background:rgba(245,166,35,0.08);border:1px solid rgba(245,166,35,0.2);border-radius:6px;margin-bottom:16px">
              <div style="font-size:12px;color:var(--amber);font-weight:600">Selected Project</div>
              <div style="font-size:14px;margin-top:4px">{{selectedProject.housingProjectTitle}}</div>
            </div>

            <form [formGroup]="applicationForm" (ngSubmit)="submitApplication()">
              <input formControlName="housingProjectId" type="hidden" />

              <div class="form-group">
                <label class="form-label">Unit Type Preference</label>
                <select class="form-select" formControlName="housingUnitType">
                  <option [value]="'APARTMENT'">Apartment</option>
                  <option [value]="'SHELTER'">Shelter</option>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">Capacity Needed (persons)</label>
                <input class="form-input" type="number" formControlName="housingCapacity" min="1" placeholder="e.g. 4" />
                <div *ngIf="applicationForm.controls.housingCapacity.invalid && applicationForm.controls.housingCapacity.touched" class="form-error">
                  Please enter a valid capacity of at least 1.
                </div>
              </div>

              <div style="padding:12px;background:var(--bg3);border-radius:6px;font-size:12px;color:var(--text2);margin-bottom:16px">
                ℹ️ Your Citizen ID is automatically attached to the application.
              </div>

              <div *ngIf="citizenMissing()" class="form-error" style="margin-bottom:16px">
                No citizen profile was found for your account. You must complete registration before applying.
              </div>

              <button class="btn btn-primary w-full" type="submit" [disabled]="submitting() || applicationForm.invalid || citizenMissing()">
                <span *ngIf="submitting()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
                {{ submitting() ? 'Submitting...' : 'Submit Application' }}
              </button>
            </form>
          </div>
          <ng-template #noProject>
            <div class="empty-state">
              <div class="empty-state-icon">👈</div>
              <p>Select a project from the left to apply</p>
            </div>
          </ng-template>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .project-option:hover { border-color: var(--border2) !important; background: var(--surface); }
    .project-option.selected { border-color: var(--amber) !important; background: rgba(245,166,35,0.06); }
    .form-error { color: var(--danger); font-size: 12px; margin-top: 6px; }
  `]
})
export class CitizenApplyComponent implements OnInit {
  private appSvc = inject(HousingApplicationService);
  private projectSvc = inject(HousingProjectService);
  private citizenSvc = inject(CitizenService);
  private auth = inject(AuthService);
  private toast = inject(ToastService);
  private fb = inject(FormBuilder);

  loading = signal(true);
  submitting = signal(false);
  citizenMissing = signal(false);
  projects = signal<HousingProjectDTO[]>([]);
  selectedProject: HousingProjectDTO | null = null;
  currentCitizenId: number | null = null;

  applicationForm = this.fb.group({
    housingProjectId: [null, Validators.required],
    housingUnitType: ['APARTMENT' as HousingUnitType, Validators.required],
    housingCapacity: [4, [Validators.required, Validators.min(1)]],
    citizenId: [null as number | null, Validators.required]
  });

  ngOnInit(): void {
    console.log('🔍 CitizenApply ngOnInit:', {
      currentUser: this.auth.currentUser,
      userId: this.auth.currentUser?.userId,
      email: this.auth.currentUser?.email
    });

    this.citizenSvc.getCurrentCitizen().subscribe({
      next: (citizen) => {
        this.currentCitizenId = citizen.citizenId ?? null;
        if (citizen.citizenId) {
          this.applicationForm.patchValue({ citizenId: citizen.citizenId });
          console.log('✅ Citizen ID set:', citizen.citizenId);
        }
      },
      error: (err) => {
        if (err.status === 404) {
          console.warn('⚠️ No citizen record found for logged-in user');
          this.citizenMissing.set(true);
          this.toast.error('No citizen profile found. Please complete registration before applying.');
        } else {
          console.error('❌ Failed to fetch citizen info:', err);
          this.toast.error('Failed to load citizen information');
        }
      }
    });

    this.projectSvc.getActiveProjects().subscribe({
      next: p => { 
        console.log('✅ Active projects loaded:', p);
        this.projects.set(p); 
        this.loading.set(false); 
      },
      error: (err) => { 
        console.error('❌ Failed to load projects:', err);
        this.loading.set(false);
      }
    });
  }

  selectProject(p: HousingProjectDTO): void {
    console.log('📍 Project selected:', p);
    this.selectedProject = p;
    this.applicationForm.patchValue({ housingProjectId: p.housingProjectId as any });
    console.log('✏️ Form after selection:', {
      value: this.applicationForm.value,
      valid: this.applicationForm.valid,
      errors: this.applicationForm.errors
    });
  }

  submitApplication(): void {
    if (!this.selectedProject || this.applicationForm.invalid || !this.currentCitizenId) {
      this.applicationForm.markAllAsTouched();
      if (!this.currentCitizenId) {
        this.toast.error('Cannot submit because no citizen profile is linked to your account.');
      } else {
        this.toast.error('Please select a project and complete the form');
      }
      return;
    }

    const dto = this.applicationForm.value as unknown as HousingApplicationRequestDTO;
    this.submitting.set(true);

    this.appSvc.create(dto as any).subscribe({
      next: () => {
        this.toast.success('Application submitted successfully!');
        this.submitting.set(false);
        this.selectedProject = null;
        this.applicationForm.reset({ housingUnitType: 'APARTMENT', housingCapacity: 4, citizenId: this.currentCitizenId });
      },
      error: (e) => {
        this.toast.error(e.error?.message || 'Submission failed');
        this.submitting.set(false);
      }
    });
  }

  statusColor(s: string): string {
    if (s === 'COMPLETED') return 'green';
    if (s === 'UNDERPROGRESS') return 'blue';
    return 'amber';
  }
}
