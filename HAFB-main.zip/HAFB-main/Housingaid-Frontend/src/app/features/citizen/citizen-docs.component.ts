import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CitizenService } from '../../core/services/api.services';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { CitizenDocumentDTO } from '../../core/models/models';
import { StatusBadgeComponent } from '../../shared/components/status-badge.component';

@Component({
  selector: 'app-citizen-docs',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <h1>Documents</h1>
          <p>Upload and manage your verification documents</p>
        </div>
        <button class="btn btn-primary" (click)="showForm = !showForm">
          {{ showForm ? '✕ Cancel' : '+ Upload Document' }}
        </button>
      </div>

      <!-- Upload form -->
      <div class="card mb-4" *ngIf="showForm">
        <div class="card-title">Upload New Document</div>
        <div class="grid-2">
          <div class="form-group">
            <label class="form-label">Document Type</label>
            <select class="form-select" [(ngModel)]="form.citizenDocumentDocType">
              <option value="IDPROOF">ID Proof</option>
              <option value="INCOMECERTIFICATE">Income Certificate</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Document URI / Reference</label>
            <input class="form-input" [(ngModel)]="form.citizenDocumentFileUri" placeholder="https://docs.example.com/id.pdf" />
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Upload Date</label>
          <input class="form-input" type="datetime-local" [(ngModel)]="form.citizenDocumentUploadedDate" />
        </div>
        <div style="padding:12px;background:rgba(91,141,238,0.08);border:1px solid rgba(91,141,238,0.2);border-radius:6px;font-size:12px;color:var(--blue);margin-bottom:16px">
          ℹ️ Document will be submitted for verification. Status starts as PENDING.
        </div>
        <div class="modal-footer" style="padding-top:0;border:none;margin-top:0">
          <button class="btn btn-primary" (click)="upload()" [disabled]="uploading()">
            <span *ngIf="uploading()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
            {{ uploading() ? 'Uploading...' : 'Upload Document' }}
          </button>
        </div>
      </div>

      <!-- Documents table -->
      <div class="card">
        <div class="card-title">My Documents ({{docs().length}})</div>
        <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
        <div *ngIf="!loading() && docs().length === 0" class="empty-state">
          <div class="empty-state-icon">📁</div>
          <p>No documents uploaded yet</p>
        </div>
        <div *ngIf="!loading() && docs().length > 0" class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>ID</th><th>Type</th><th>URI</th><th>Uploaded</th><th>Status</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let d of docs()">
                <td class="td-mono">#{{d.citizenDocumentId}}</td>
                <td>{{d.citizenDocumentDocType}}</td>
                <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                  <a [href]="d.citizenDocumentFileUri" target="_blank" style="color:var(--blue);font-size:12px">
                    {{d.citizenDocumentFileUri}}
                  </a>
                </td>
                <td class="td-mono">{{d.citizenDocumentUploadedDate | date:'short'}}</td>
                <td><app-status-badge [status]="d.citizenDocumentVerificationStatus" /></td>
                <td>
                  <button class="btn btn-danger btn-sm"
                          *ngIf="d.citizenDocumentVerificationStatus !== 'VERIFIED'"
                          (click)="deleteDoc(d)">
                    🗑
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class CitizenDocsComponent implements OnInit {
  private citizenSvc = inject(CitizenService);
  private auth = inject(AuthService);
  private toast = inject(ToastService);

  loading = signal(true);
  uploading = signal(false);
  docs = signal<CitizenDocumentDTO[]>([]);
  showForm = false;
  citizenId: number | null = null;

  form: CitizenDocumentDTO = {
    citizenDocumentDocType: 'IDPROOF',
    citizenDocumentFileUri: '',
    citizenDocumentUploadedDate: new Date().toISOString().slice(0,16),
    citizenDocumentVerificationStatus: 'PENDING'
  };

  ngOnInit(): void {
    this.citizenSvc.getCurrentCitizen().subscribe({
      next: (citizen) => {
        this.citizenId = citizen.citizenId!;
        this.load();
      },
      error: () => {
        this.toast.error('Failed to load citizen info');
        this.loading.set(false);
      }
    });
  }

  load(): void {
    if (!this.citizenId) return;
    this.citizenSvc.getDocuments(this.citizenId).subscribe({
      next: d => { this.docs.set(d); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  upload(): void {
    if (!this.form.citizenDocumentFileUri) { this.toast.error('Please enter a document URI'); return; }
    if (!this.citizenId) { this.toast.error('Citizen ID not loaded'); return; }
    this.uploading.set(true);
    this.citizenSvc.uploadDocument(this.citizenId!, this.form).subscribe({
      next: () => { this.toast.success('Document uploaded!'); this.showForm = false; this.load(); this.uploading.set(false); },
      error: (e) => { this.toast.error(e.error?.message || 'Upload failed'); this.uploading.set(false); }
    });
  }

  deleteDoc(d: CitizenDocumentDTO): void {
    if (!this.citizenId) { this.toast.error('Citizen ID not loaded'); return; }
    if (!confirm('Delete this document?')) return;
    this.citizenSvc.deleteDocument(this.citizenId!, d.citizenDocumentId!).subscribe({
      next: () => { this.toast.success('Document deleted'); this.load(); },
      error: () => this.toast.error('Delete failed')
    });
  }
}
