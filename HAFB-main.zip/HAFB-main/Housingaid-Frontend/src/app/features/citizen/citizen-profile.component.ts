import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CitizenService } from '../../core/services/api.services';
import { ToastService } from '../../core/services/toast.service';
import { AuthService } from '../../core/services/auth.service';
import { CitizenDTO, CitizenGender } from '../../core/models/models';

@Component({
  selector: 'app-citizen-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="page-content">
      <div class="page-header">
        <div>
          <h1>My Profile</h1>
        </div>
      </div>

      <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span> Loading profile…</div>

      <div *ngIf="!loading() && error()" class="empty-state">
        <div class="empty-state-icon">⚠️</div>
        <p>{{ error() }}</p>
      </div>

      <div *ngIf="!loading() && !error()">
        <form [formGroup]="profileForm" (ngSubmit)="saveProfile()" class="card card-form">
          <div class="form-grid">
            <div class="form-group full-width">
              <label class="form-label">Full Name</label>
              <input class="form-input" formControlName="citizenName" placeholder="Enter your full name" />
            </div>
            <div class="form-group full-width">
              <label class="form-label">Email</label>
              <input class="form-input" [value]="userEmail || '—'" readonly />
            </div>
            <div class="form-group">
              <label class="form-label">Date of Birth</label>
              <input class="form-input" type="date" formControlName="citizenDOB" />
            </div>
            <div class="form-group">
              <label class="form-label">Gender</label>
              <select class="form-select" formControlName="citizenGender">
                <option [value]="'MALE'">Male</option>
                <option [value]="'FEMALE'">Female</option>
                <option [value]="'OTHER'">Other</option>
              </select>
            </div>
            <div class="form-group full-width">
              <label class="form-label">Contact Info</label>
              <input class="form-input" formControlName="citizenContactInfo" placeholder="Phone or email" />
            </div>
            <div class="form-group full-width">
              <label class="form-label">Address</label>
              <textarea class="form-input" formControlName="citizenAddress" rows="4" placeholder="Enter your current address"></textarea>
            </div>
          </div>

          <div class="form-actions">
            <button class="btn btn-primary" type="submit" [disabled]="submitting() || profileForm.invalid">
              <span *ngIf="submitting()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
              {{ submitting() ? 'Saving...' : 'Save Profile' }}
            </button>
          </div>
        </form>
      </div>
    </div>
  `,
  styles: [
    `.card-form { max-width: 760px; }`,
    `.form-grid { display:grid; grid-template-columns: repeat(2,minmax(0,1fr)); gap:16px; }`,
    `.form-group.full-width { grid-column: span 2; }`,
    `.form-actions { margin-top: 24px; display:flex; justify-content:flex-end; }`,
    `.form-input, .form-select, textarea { width:100%; }`
  ]
})
export class CitizenProfileComponent implements OnInit {
  private citizenSvc = inject(CitizenService);
  private toast = inject(ToastService);
  private auth = inject(AuthService);
  private router = inject(Router);
  private fb = inject(FormBuilder);

  loading = signal(true);
  submitting = signal(false);
  error = signal<string | null>(null);
  citizen = signal<CitizenDTO | null>(null);
  userEmail = this.auth.currentUser?.email ?? '';

  profileForm = this.fb.group({
    citizenName: ['', Validators.required],
    citizenDOB: ['', Validators.required],
    citizenGender: ['MALE' as CitizenGender, Validators.required],
    citizenAddress: ['', Validators.required],
    citizenContactInfo: ['', Validators.required]
  });

  ngOnInit(): void {
    this.citizenSvc.getCurrentCitizen().subscribe({
      next: (citizen) => {
        this.citizen.set(citizen);
        this.profileForm.patchValue({
          citizenName: citizen.citizenName,
          citizenDOB: citizen.citizenDOB,
          citizenGender: citizen.citizenGender,
          citizenAddress: citizen.citizenAddress,
          citizenContactInfo: citizen.citizenContactInfo
        });
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Could not load your profile. Please refresh or log in again.');
        this.loading.set(false);
      }
    });
  }

  saveProfile(): void {
    if (!this.citizen()?.citizenId) {
      this.toast.error('Citizen ID is missing.');
      return;
    }

    this.submitting.set(true);
    const payload: CitizenDTO = {
      ...this.citizen()!,
      ...this.profileForm.value
    } as CitizenDTO;

    this.citizenSvc.updateCitizen(this.citizen()!.citizenId!, payload).subscribe({
      next: () => {
        this.toast.success('Profile updated successfully.');
        this.submitting.set(false);
        this.router.navigate(['/dashboard/home']);
      },
      error: (err) => {
        this.toast.error(err.error?.message || 'Failed to update profile.');
        this.submitting.set(false);
      }
    });
  }
}
