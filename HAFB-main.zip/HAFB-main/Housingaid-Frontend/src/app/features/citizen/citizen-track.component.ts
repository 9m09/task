import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HousingApplicationService, CitizenService } from '../../core/services/api.services';
import { AuthService } from '../../core/services/auth.service';
import { HousingApplicationDTO } from '../../core/models/models';
import { StatusBadgeComponent } from '../../shared/components/status-badge.component';

@Component({
  selector: 'app-citizen-track',
  standalone: true,
  imports: [CommonModule, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <div class="page-header">
        <h1>Track Application</h1>
        <p>Monitor the status of your housing applications</p>
      </div>

      <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span> Loading applications…</div>

      <div *ngIf="!loading() && error()" class="empty-state">
        <div class="empty-state-icon">⚠️</div>
        <p>{{ error() }}</p>
      </div>

      <div *ngIf="!loading() && !error() && apps().length === 0" class="empty-state">
        <div class="empty-state-icon">📋</div>
        <p>No applications found</p>
      </div>

      <div *ngFor="let app of apps()" class="card mb-4">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
          <div>
            <div style="font-family:var(--font-head);font-size:16px;font-weight:700">
              Application #{{app.housingApplicationId}}
            </div>
            <div style="font-size:12px;color:var(--text2);margin-top:2px">
              Submitted: {{app.housingApplicationSubmittedDate | date:'mediumDate'}}
            </div>
          </div>
          <app-status-badge [status]="app.housingApplicationStatus ?? ''" />
        </div>

        <div class="info-grid">
          <div class="info-row">
            <span class="info-label">Applicant</span>
            <span class="info-value">{{app.housingApplicantName || 'N/A'}}</span>
          </div>
          <div class="info-row">
            <span class="info-label">Scheme</span>
            <span class="info-value">{{app.housingSchemeName || 'N/A'}}</span>
          </div>
          <div class="info-row">
            <span class="info-label">Project ID</span>
            <span class="info-value">#{{app.housingProjectId}}</span>
          </div>
          <div class="info-row">
            <span class="info-label">Status</span>
            <span class="info-value">{{app.housingApplicationStatus}}</span>
          </div>
        </div>

        <!-- Status timeline -->
        <div style="margin-top:20px;padding-top:16px;border-top:1px solid var(--border)">
          <div style="font-size:11px;color:var(--text3);text-transform:uppercase;letter-spacing:0.06em;margin-bottom:12px">Progress</div>
          <div style="display:flex;gap:0;align-items:center">
            <div *ngFor="let step of getSteps(app.housingApplicationStatus ?? ''); let i = index; let last = last"
                 style="display:flex;align-items:center;flex:1">
              <div style="display:flex;flex-direction:column;align-items:center;flex:1">
                <div style="width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700"
                     [style.background]="step.done ? 'var(--green)' : step.active ? 'var(--amber)' : 'var(--surface)'"
                     [style.color]="step.done || step.active ? '#0d0f14' : 'var(--text3)'">
                  {{step.done ? '✓' : i+1}}
                </div>
                <div style="font-size:11px;text-align:center;margin-top:4px;white-space:nowrap"
                     [style.color]="step.done ? 'var(--green)' : step.active ? 'var(--amber)' : 'var(--text3)'">
                  {{step.label}}
                </div>
              </div>
              <div *ngIf="!last" style="height:2px;flex:1;margin-bottom:20px"
                   [style.background]="step.done ? 'var(--green)' : 'var(--border)'"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CitizenTrackComponent implements OnInit {
  private appSvc = inject(HousingApplicationService);
  private auth = inject(AuthService);
  private citizenSvc = inject(CitizenService);

  loading = signal(true);
  error = signal<string | null>(null);
  apps = signal<HousingApplicationDTO[]>([]);

  ngOnInit(): void {
    this.citizenSvc.getCurrentCitizen().subscribe({
      next: citizen => {
        if (citizen?.citizenId) {
          this.loadApplications(citizen.citizenId);
        } else {
          this.error.set('Citizen profile not found for the logged-in user.');
          this.loading.set(false);
        }
      },
      error: () => {
        this.error.set('Unable to load citizen profile. Please log in again.');
        this.loading.set(false);
      }
    });
  }

  loadApplications(citizenId: number): void {
    this.appSvc.getAll().subscribe({
      next: apps => {
        this.apps.set(apps.filter(app => app.citizenId === citizenId));
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Unable to load your housing applications.');
        this.loading.set(false);
      }
    });
  }

  getSteps(status: string): any[] {
    const order = ['PENDING', 'UNDER_REVIEW', 'APPROVED'];
    const idx = order.indexOf(status);
    const labels = ['Submitted', 'Under Review', 'Approved'];
    return labels.map((label, i) => ({
      label, done: i < idx, active: i === idx
    }));
  }
}
