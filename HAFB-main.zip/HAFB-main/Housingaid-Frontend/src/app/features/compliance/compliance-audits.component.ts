import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ComplianceAuditService } from '../../core/services/api.services';
import { ToastService } from '../../core/services/toast.service';
import { AuditDTO } from '../../core/models/models';
import { StatusBadgeComponent } from '../../shared/components/status-badge.component';

@Component({
  selector: 'app-compliance-audits',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <h1>Audit Records</h1>
          <p>Review all compliance audits across the system</p>
        </div>
        <button class="btn btn-ghost" (click)="load()">↻ Refresh</button>
      </div>

      <!-- Stats -->
      <div class="grid-3 mb-4">
        <div class="stat-card amber">
          <div class="stat-icon">⏳</div>
          <div class="stat-value text-amber">{{countByStatus('PENDING')}}</div>
          <div class="stat-label">Pending</div>
        </div>
        <div class="stat-card green">
          <div class="stat-icon">✅</div>
          <div class="stat-value text-green">{{countByStatus('COMPLETED')}}</div>
          <div class="stat-label">Completed</div>
        </div>
        <div class="stat-card red">
          <div class="stat-icon">🚩</div>
          <div class="stat-value text-red">{{countByStatus('FLAGGED')}}</div>
          <div class="stat-label">Flagged</div>
        </div>
      </div>

      <!-- Search -->
      <div class="search-bar mb-4">
        <input class="search-input" type="number" [(ngModel)]="searchOfficerId" placeholder="Filter by Officer ID…" />
        <input class="search-input" [(ngModel)]="searchScope" placeholder="Filter by scope…" />
        <button class="btn btn-ghost" (click)="search()">Search</button>
        <button class="btn btn-ghost" (click)="load()">↻ Reset</button>
      </div>

      <!-- Table -->
      <div class="card">
        <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
        <div *ngIf="!loading() && audits().length === 0" class="empty-state">
          <div class="empty-state-icon">🔍</div>
          <p>No audits found</p>
        </div>
        <div *ngIf="!loading() && audits().length > 0" class="table-wrap">
          <table>
            <thead>
              <tr><th>ID</th><th>Officer ID</th><th>Scope</th><th>Date</th><th>Status</th><th>Findings</th><th>Actions</th></tr>
            </thead>
            <tbody>
              <tr *ngFor="let a of audits()">
                <td class="td-mono">#{{a.auditId}}</td>
                <td class="td-mono">#{{a.officerId}}</td>
                <td style="font-size:12px;max-width:150px">{{a.scope}}</td>
                <td class="td-mono">{{a.auditDate}}</td>
                <td><app-status-badge [status]="a.status" /></td>
                <td style="font-size:12px;color:var(--text2);max-width:200px;overflow:hidden;text-overflow:ellipsis">
                  {{a.findings}}
                </td>
                <td>
                  <select class="form-select" style="font-size:11px;padding:3px 6px;width:120px"
                          [(ngModel)]="a.status"
                          (change)="updateAudit(a)">
                    <option value="PENDING">Pending</option>
                    <option value="COMPLETED">Completed</option>
                    <option value="FLAGGED">Flagged</option>
                  </select>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class ComplianceAuditsComponent implements OnInit {
  private auditSvc = inject(ComplianceAuditService);
  private toast = inject(ToastService);

  loading = signal(true);
  audits = signal<AuditDTO[]>([]);
  searchOfficerId = '';
  searchScope = '';

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.auditSvc.getAll().subscribe({
      next: a => { this.audits.set(a); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  search(): void {
    this.loading.set(true);
    const oid = this.searchOfficerId ? Number(this.searchOfficerId) : undefined;
    this.auditSvc.search(oid, this.searchScope || undefined).subscribe({
      next: a => { this.audits.set(a); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  countByStatus(s: string): number { return this.audits().filter(a => a.status === s).length; }

  updateAudit(a: AuditDTO): void {
    this.auditSvc.update(a).subscribe({
      next: () => this.toast.success('Audit updated'),
      error: () => this.toast.error('Update failed')
    });
  }
}
