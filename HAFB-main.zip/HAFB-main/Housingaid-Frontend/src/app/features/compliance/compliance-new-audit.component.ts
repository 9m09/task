import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ComplianceAuditService } from '../../core/services/api.services';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { AuditDTO } from '../../core/models/models';

@Component({
  selector: 'app-compliance-new-audit',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-content">
      <div class="page-header">
        <h1>Create New Audit</h1>
        <p>Submit a new compliance audit record</p>
      </div>

      <div style="max-width:640px">
        <div class="card">
          <div class="card-title">Audit Details</div>

          <div class="form-group">
            <label class="form-label">Officer ID</label>
            <input class="form-input" type="number" [(ngModel)]="form.officerId" />
          </div>

          <div class="form-group">
            <label class="form-label">Scope</label>
            <input class="form-input" [(ngModel)]="form.scope"
                   placeholder="e.g. Q4 Housing Unit Compliance Review" />
            <div class="form-error" *ngIf="form.scope && form.scope.length < 5">
              Scope must be at least 5 characters
            </div>
          </div>

          <div class="form-group">
            <label class="form-label">Findings / Remarks</label>
            <textarea class="form-textarea" style="min-height:120px"
                      [(ngModel)]="form.findings"
                      placeholder="Document your audit findings in detail…"></textarea>
            <div class="form-error" *ngIf="form.findings && form.findings.length < 10">
              Findings must be at least 10 characters
            </div>
          </div>

          <div class="grid-2">
            <div class="form-group">
              <label class="form-label">Audit Date</label>
              <input class="form-input" type="date" [(ngModel)]="form.auditDate" />
            </div>
            <div class="form-group">
              <label class="form-label">Initial Status</label>
              <select class="form-select" [(ngModel)]="form.status">
                <option value="PENDING">Pending</option>
                <option value="COMPLETED">Completed</option>
                <option value="FLAGGED">Flagged</option>
              </select>
            </div>
          </div>

          <div style="padding:12px;background:rgba(245,166,35,0.08);border:1px solid rgba(245,166,35,0.2);border-radius:6px;font-size:12px;color:var(--amber);margin-bottom:16px">
            ⚠️ Audit records are permanent and will be included in compliance reports. Ensure all information is accurate before submitting.
          </div>

          <div style="display:flex;gap:10px;justify-content:flex-end">
            <button class="btn btn-ghost" routerLink="../compliance-audits">Cancel</button>
            <button class="btn btn-primary" (click)="submit()" [disabled]="submitting()">
              <span *ngIf="submitting()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
              {{ submitting() ? 'Submitting...' : '📝 Submit Audit' }}
            </button>
          </div>
        </div>

        <!-- Preview -->
        <div class="card mt-4" *ngIf="form.scope || form.findings">
          <div class="card-title">Preview</div>
          <div class="info-grid">
            <div class="info-row">
              <span class="info-label">Officer</span>
              <span class="info-value">#{{form.officerId}}</span>
            </div>
            <div class="info-row">
              <span class="info-label">Date</span>
              <span class="info-value">{{form.auditDate}}</span>
            </div>
            <div class="info-row" style="grid-column:1/-1">
              <span class="info-label">Scope</span>
              <span class="info-value">{{form.scope || '—'}}</span>
            </div>
            <div class="info-row" style="grid-column:1/-1">
              <span class="info-label">Findings / Remarks</span>
              <span class="info-value" style="white-space:pre-wrap;font-size:13px">{{form.findings || '—'}}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ComplianceNewAuditComponent {
  private auditSvc = inject(ComplianceAuditService);
  private auth = inject(AuthService);
  private toast = inject(ToastService);
  private router = inject(Router);

  submitting = signal(false);

  form: AuditDTO = {
    officerId: this.auth.currentUser?.userId ?? 1,
    scope: '',
    findings: '',
    auditDate: new Date().toISOString().split('T')[0],
    status: 'PENDING'
  };

  submit(): void {
    if (!this.form.scope || this.form.scope.length < 5) { this.toast.error('Scope too short'); return; }
    if (!this.form.findings || this.form.findings.length < 10) { this.toast.error('Findings too short'); return; }
    if (!this.auth.isLoggedIn) { this.toast.error('Please log in first'); return; }
    this.submitting.set(true);
    // Prepare payload matching the sample
    const payload: AuditDTO = {
      officerId: this.form.officerId,
      scope: this.form.scope,
      findings: this.form.findings,
      auditDate: this.form.auditDate!,
      status: this.form.status as any
    };
    console.log(payload);
    this.auditSvc.create(payload).subscribe({
      next: () => {
        this.toast.success('Audit submitted!');
        this.router.navigate(['/dashboard/compliance-audits']);
      },
      error: (e) => { this.toast.error(e.error?.message || 'Submit failed'); this.submitting.set(false); }
    });
  }
}
