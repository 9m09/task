import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ComplianceRecordService } from '../../core/services/api.services';
import { ToastService } from '../../core/services/toast.service';
import { ComplianceRecordDTO, ComplianceEntityType } from '../../core/models/models';
import { StatusBadgeComponent } from '../../shared/components/status-badge.component';

@Component({
  selector: 'app-compliance-records',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <h1>Compliance Records</h1>
          <p>Track compliance status for applications, units and projects</p>
        </div>
        <button class="btn btn-primary" (click)="showForm = !showForm">
          {{ showForm ? '✕ Cancel' : '+ New Record' }}
        </button>
      </div>

      <!-- Stats -->
      <div class="grid-3 mb-4">
        <div class="stat-card green">
          <div class="stat-icon">✅</div>
          <div class="stat-value text-green">{{countByResult('COMPLIANT')}}</div>
          <div class="stat-label">Compliant</div>
        </div>
        <div class="stat-card red">
          <div class="stat-icon">⚠️</div>
          <div class="stat-value text-red">{{countByResult('NONCOMPLIANT')}}</div>
          <div class="stat-label">Non-Compliant</div>
        </div>
        <div class="stat-card amber">
          <div class="stat-icon">📋</div>
          <div class="stat-value text-amber">{{records().length}}</div>
          <div class="stat-label">Total Records</div>
        </div>
      </div>

      <!-- Create form -->
      <div class="card mb-4" *ngIf="showForm">
        <div class="card-title">New Compliance Record</div>
        <div class="grid-2">
          <div class="form-group">
            <label class="form-label">Entity ID</label>
            <input class="form-input" type="number" [(ngModel)]="form.entityId" placeholder="e.g. 1" />
          </div>
          <div class="form-group">
            <label class="form-label">Entity Type</label>
            <select class="form-select" [(ngModel)]="form.type">
              <option value="APPLICATION">Application</option>
              <option value="UNIT">Unit</option>
              <option value="PROJECT">Project</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Result</label>
            <select class="form-select" [(ngModel)]="form.result">
              <option value="COMPLIANT">Compliant</option>
              <option value="NONCOMPLIANT">Non-Compliant</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Date</label>
            <input class="form-input" type="date" [(ngModel)]="form.date" />
          </div>
          <div class="form-group" style="grid-column:1/-1">
            <label class="form-label">Notes</label>
            <textarea class="form-textarea" [(ngModel)]="form.notes" placeholder="Compliance review notes…"></textarea>
          </div>
        </div>
        <div class="modal-footer" style="padding-top:0;border:none;margin-top:0">
          <button class="btn btn-primary" (click)="create()" [disabled]="saving()">
            <span *ngIf="saving()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
            {{ saving() ? 'Saving...' : 'Create Record' }}
          </button>
        </div>
      </div>

      <!-- Search -->
      <div class="search-bar mb-4">
        <input class="search-input" type="number" [(ngModel)]="searchEntityId" placeholder="Filter by Entity ID…" />
        <select class="form-select" style="width:160px" [(ngModel)]="searchType">
          <option value="">All Types</option>
          <option value="APPLICATION">Application</option>
          <option value="UNIT">Unit</option>
          <option value="PROJECT">Project</option>
        </select>
        <button class="btn btn-ghost" (click)="search()">Search</button>
        <button class="btn btn-ghost" (click)="load()">↻ Reset</button>
      </div>

      <!-- Table -->
      <div class="card">
        <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
        <div *ngIf="!loading() && records().length === 0" class="empty-state">
          <div class="empty-state-icon">📋</div>
          <p>No compliance records found</p>
        </div>
        <div *ngIf="!loading() && records().length > 0" class="table-wrap">
          <table>
            <thead>
              <tr><th>ID</th><th>Entity ID</th><th>Type</th><th>Result</th><th>Date</th><th>Notes</th></tr>
            </thead>
            <tbody>
              <tr *ngFor="let r of records()">
                <td class="td-mono">#{{r.complianceId}}</td>
                <td class="td-mono">#{{r.entityId}}</td>
                <td>
                  <span class="badge badge-grey">{{r.type}}</span>
                </td>
                <td><app-status-badge [status]="r.result" /></td>
                <td class="td-mono">{{r.date}}</td>
                <td style="font-size:12px;color:var(--text2);max-width:220px;overflow:hidden;text-overflow:ellipsis">{{r.notes}}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class ComplianceRecordsComponent implements OnInit {
  private recSvc = inject(ComplianceRecordService);
  private toast = inject(ToastService);

  loading = signal(true);
  saving = signal(false);
  records = signal<ComplianceRecordDTO[]>([]);
  showForm = false;
  searchEntityId = '';
  searchType = '';

  form: ComplianceRecordDTO = this.blank();

  blank(): ComplianceRecordDTO {
    return { entityId: 0, type: 'APPLICATION', result: 'COMPLIANT', date: new Date().toISOString().split('T')[0], notes: '' };
  }

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.recSvc.getAll().subscribe({
      next: r => { this.records.set(r); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  search(): void {
    this.loading.set(true);
    const eid = this.searchEntityId ? Number(this.searchEntityId) : undefined;
    this.recSvc.search(eid, this.searchType || undefined).subscribe({
      next: r => { this.records.set(r); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  countByResult(r: string): number { return this.records().filter(x => x.result === r).length; }

  create(): void {
    if (!this.form.entityId || !this.form.notes) { this.toast.error('Fill all fields'); return; }
    this.saving.set(true);
    this.recSvc.create(this.form).subscribe({
      next: () => { this.toast.success('Record created!'); this.showForm = false; this.form = this.blank(); this.load(); this.saving.set(false); },
      error: (e) => { this.toast.error(e.error?.message || 'Create failed'); this.saving.set(false); }
    });
  }
}
