import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import {
  HousingApplicationService,
  CitizenService,
  HousingProjectService,
  AllocationService,
  ComplianceAuditService
} from '../../core/services/api.services';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-content">
      <div class="page-header">
        <div>
          <h1>Welcome {{ displayName }}</h1>
        </div>
      </div>

      <div *ngIf="loading()" class="loading-overlay">
        <span class="spinner"></span> Loading dashboard details…
      </div>

      <div class="grid-stats mb-4" *ngIf="!loading() && stats().length" [style.grid-template-columns]="'repeat(' + stats().length + ', minmax(0, 1fr))'">
        <div *ngFor="let stat of stats()" class="stat-card" [ngClass]="stat.color">
          <div class="stat-icon">{{ stat.icon }}</div>
          <div class="stat-value">{{ stat.value }}</div>
          <div class="stat-label">{{ stat.label }}</div>
          <div class="stat-subtitle">{{ stat.sub }}</div>
        </div>
      </div>

      <div *ngIf="!loading()">
        <div class="card">
          <div class="card-title">Quick Actions</div>
          <div class="action-list">
            <a *ngFor="let action of quickActions" [routerLink]="['/dashboard', action.route]" class="action-item">
              <span class="action-icon">{{ action.icon }}</span>
              <span>{{ action.label }}</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
    `.page-header { margin-bottom: 28px; }`,
    `.grid-stats { display: grid; gap: 18px; }`,
    `.grid-2 { display:grid; grid-template-columns: 1.6fr 1fr; gap:18px; }`,
    `.stat-card { padding:24px; border-radius:18px; background: var(--bg2); border: 1px solid var(--border); min-height: 160px; }`,
    `.stat-icon { font-size: 32px; margin-bottom: 18px; }`,
    `.stat-value { font-size: 42px; font-weight: 700; color: var(--text); }`,
    `.stat-label { margin-top: 12px; font-size: 0.95rem; letter-spacing: 0.08em; text-transform: uppercase; color: var(--text2); }`,
    `.stat-subtitle { margin-top: 10px; color: var(--text3); font-size: 0.95rem; }`,
    `.card { padding: 22px; border-radius: 18px; background: var(--bg2); border: 1px solid var(--border); }`,
    `.card-title { margin-bottom: 18px; font-size: 1rem; font-weight: 700; color: var(--text); }`,
    `.action-list { display: flex; flex-direction: column; gap: 12px; }`,
    `.action-item { display: flex; align-items: center; gap: 12px; padding: 14px 16px; border-radius: 14px; border: 1px solid var(--border); background: var(--bg2); color: var(--text); text-decoration: none; }`,
    `.action-item:hover { background: var(--bg3); }`,
    `.action-icon { width: 34px; height: 34px; display: flex; align-items: center; justify-content: center; border-radius: 12px; background: var(--surface); }`,
    `.loading-overlay { display: flex; align-items: center; gap: 10px; color: var(--text2); font-size: 0.95rem; }`
  ]
})
export class DashboardComponent implements OnInit {
  private auth = inject(AuthService);
  private citizenSvc = inject(CitizenService);
  private appSvc = inject(HousingApplicationService);
  private projectSvc = inject(HousingProjectService);
  private allocSvc = inject(AllocationService);
  private complianceSvc = inject(ComplianceAuditService);

  loading = signal(true);
  stats = signal<any[]>([]);
  currentCitizen = signal<any | null>(null);
  user = this.auth.currentUser;

  get displayName(): string {
    const fullName = this.user?.name?.trim();
    if (fullName) return fullName;
    return this.user?.email?.split('@')[0] ?? 'Citizen';
  }

  get quickActions(): any[] {
    const role = this.user?.role;
    const map: Record<string, any[]> = {
      CITIZEN: [
        { icon: '📄', label: 'Apply for Housing', route: 'citizen-apply' },
        { icon: '📁', label: 'Upload Documents', route: 'citizen-docs' },
        { icon: '🔍', label: 'Track Application', route: 'citizen-track' },
        { icon: '👤', label: 'My Profile', route: 'citizen-profile' }
      ],
      OFFICER: [
        { icon: '📋', label: 'View Applications', route: 'officer-applications' },
        { icon: '✅', label: 'Eligibility Checks', route: 'officer-eligibility' },
        { icon: '🏠', label: 'Allocation', route: 'allocation-allocate' }
      ],
      MANAGER: [
        { icon: '🏗', label: 'Manage Projects', route: 'manager-projects' },
        { icon: '📦', label: 'Resources', route: 'manager-resources' }
      ],
      ADMIN: [
        { icon: '👥', label: 'Manage Users', route: 'admin-users' },
        { icon: '📋', label: 'Audit Logs', route: 'admin-logs' },
        { icon: '⚙️', label: 'Workflows', route: 'admin-workflows' }
      ],
      COMPLIANCE: [
        { icon: '📋', label: 'Compliance Records', route: 'compliance-records' },
        { icon: '🔍', label: 'View Audits', route: 'compliance-audits' },
        { icon: '📝', label: 'New Audit', route: 'compliance-new-audit' }
      ],
      AUDITOR: [
        { icon: '📊', label: 'Generate Report', route: 'auditor-reports' },
        { icon: '🔍', label: 'Program Review', route: 'auditor-review' }
      ]
    };
    return map[role ?? ''] ?? [];
  }

  ngOnInit(): void {
    this.loadDashboard();
  }

  loadDashboard(): void {
    const role = this.user?.role;
    if (role === 'CITIZEN') {
      this.loadCitizenDashboard();
    } else if (role === 'ADMIN' || role === 'MANAGER' || role === 'OFFICER' || role === 'AUDITOR' || role === 'COMPLIANCE') {
      this.loadAdminDashboard();
    } else {
      this.stats.set([]);
      this.loading.set(false);
    }
  }

  loadAdminDashboard(): void {
    forkJoin({
      total: this.projectSvc.getTotalCount().pipe(catchError(() => of(0))),
      totalApps: this.appSvc.getTotalCount().pipe(catchError(() => of(0))),
      pending: this.appSvc.getCountByStatus('PENDING').pipe(catchError(() => of(0))),
      approved: this.appSvc.getCountByStatus('APPROVED').pipe(catchError(() => of(0))),
      allocations: this.allocSvc.getTotal().pipe(catchError(() => of(0))),
    }).subscribe({
      next: (r) => {
        this.stats.set([
          { label: 'Total Projects', value: r.total, icon: '🏗', color: 'amber', sub: 'All housing projects' },
          { label: 'Applications', value: r.totalApps, icon: '📋', color: 'blue', sub: 'Total submitted' },
          { label: 'Pending Review', value: r.pending, icon: '⏳', color: 'amber', sub: 'Awaiting action' },
          { label: 'Allocations', value: r.allocations, icon: '🏠', color: 'green', sub: 'Units assigned' },
        ]);
        this.loading.set(false);
      },
      error: () => this.loading.set(false)
    });
  }

  loadCitizenDashboard(): void {
    this.citizenSvc.getCurrentCitizen().subscribe({
      next: (citizen) => {
        this.currentCitizen.set(citizen);
        const citizenId = citizen?.citizenId;

        if (!citizenId) {
          this.stats.set(this.defaultStats());
          this.loading.set(false);
          return;
        }

        forkJoin({
          applications: this.appSvc.getAll().pipe(catchError(() => of([])))
        }).subscribe({
          next: ({ applications }) => {
            const myApps = (applications as any[]).filter(app => app.citizenId === citizenId);
            const pending = myApps.filter(app => app.housingApplicationStatus === 'PENDING').length;
            const approved = myApps.filter(app => app.housingApplicationStatus === 'APPROVED').length;

            this.stats.set([
              { label: 'My Applications', value: myApps.length, icon: '📋', color: 'blue', sub: 'Submitted applications' },
              { label: 'Pending Review', value: pending, icon: '⏳', color: 'amber', sub: 'Awaiting decision' },
              { label: 'Approved', value: approved, icon: '✅', color: 'green', sub: 'Ready for allocation' }
            ]);
            this.loading.set(false);
          },
          error: () => {
            this.stats.set(this.defaultStats());
            this.loading.set(false);
          }
        });
      },
      error: () => {
        this.stats.set(this.defaultStats());
        this.loading.set(false);
      }
    });
  }

  defaultStats(): any[] {
    return [
      { label: 'My Applications', value: 0, icon: '📋', color: 'blue', sub: 'Submitted applications' },
      { label: 'Pending Review', value: 0, icon: '⏳', color: 'amber', sub: 'Awaiting decision' },
      { label: 'Approved', value: 0, icon: '✅', color: 'green', sub: 'Ready for allocation' }
    ];
  }
}
