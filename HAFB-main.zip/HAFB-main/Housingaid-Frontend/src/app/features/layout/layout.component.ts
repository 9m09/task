import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, Router, NavigationEnd } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { ThemeService } from '../../core/services/theme.service';
import { UserRole } from '../../core/models/models';
import { filter } from 'rxjs';

interface NavItem { icon: string; label: string; route: string; }

const ROLE_MENUS: Record<UserRole, NavItem[]> = {
  CITIZEN: [
    { icon: '📊', label: 'Dashboard', route: 'home' },
    { icon: '📄', label: 'Apply for Housing', route: 'citizen-apply' },
    { icon: '📁', label: 'Upload Documents', route: 'citizen-docs' },
    { icon: '🔍', label: 'Track Application', route: 'citizen-track' },
  ],
  OFFICER: [
    { icon: '📊', label: 'Dashboard', route: 'home' },
    { icon: '📋', label: 'Applications', route: 'officer-applications' },
    { icon: '✅', label: 'Eligibility Check', route: 'officer-eligibility' },
    { icon: '🏠', label: 'Allocation', route: 'allocation-allocate' },
  ],
  MANAGER: [
    { icon: '📊', label: 'Dashboard', route: 'home' },
    { icon: '🏗', label: 'Projects', route: 'manager-projects' },
    { icon: '📦', label: 'Resources', route: 'manager-resources' },
    { icon: '🏢', label: 'Units Inventory', route: 'manager-units' }
  ],
  ADMIN: [
    { icon: '📊', label: 'Dashboard', route: 'home' },
    { icon: '👥', label: 'User Management', route: 'admin-users' },
    { icon: '⚙️', label: 'Workflows', route: 'admin-workflows' },
    { icon: '📋', label: 'Audit Logs', route: 'admin-logs' }
  ],
  COMPLIANCE: [
    { icon: '📊', label: 'Dashboard', route: 'home' },
    { icon: '📋', label: 'Compliance Records', route: 'compliance-records' },
    { icon: '🔍', label: 'Audits', route: 'compliance-audits' },
    { icon: '📝', label: 'New Audit', route: 'compliance-new-audit' },
  ],
  AUDITOR: [
    { icon: '📊', label: 'Dashboard', route: 'home' },
    { icon: '📊', label: 'Reports', route: 'auditor-reports' },
    { icon: '🔍', label: 'Program Review', route: 'auditor-review' },
  ]
};

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink],
  template: `
    <div class="app-layout">
      <!-- Sidebar -->
      <aside class="sidebar">
        <div class="sidebar-logo">
          <div class="sidebar-logo-icon">🏠</div>
          HousingAid
        </div>
        <div class="sidebar-role">{{ user?.role }}</div>

        <nav class="sidebar-section">
          <div *ngFor="let item of navItems"
               class="sidebar-item"
               [class.active]="activeRoute === item.route"
               [routerLink]="['/dashboard', item.route]"
               (click)="activeRoute = item.route">
            <span class="sidebar-item-icon">{{item.icon}}</span>
            {{item.label}}
          </div>
        </nav>

        <div class="sidebar-bottom">
          <button class="btn btn-ghost btn-sm w-full" (click)="logout()">
            🚪 Sign Out
          </button>
        </div>
      </aside>

      <!-- Main -->
      <div class="main-area">
        <div class="topbar">
          <span class="topbar-title">{{pageTitle}}</span>
          <div class="topbar-actions">
            <button class="btn btn-ghost btn-sm" (click)="toggleTheme()">
              {{ theme() === 'dark' ? '☀️ Light Mode' : '🌙 Dark Mode' }}
            </button>
            <button *ngIf="user?.role === 'CITIZEN'" class="profile-button" [routerLink]="['/dashboard','citizen-profile']">
              <span class="profile-avatar">{{ avatarLetter }}</span>
            </button>
          </div>
        </div>
        <router-outlet />
      </div>
    </div>
  `,
  styles: [
    `.topbar { display:flex; justify-content:space-between; align-items:center; gap:16px; margin-bottom:24px; }`,
    `.topbar-actions { display:flex; align-items:center; gap:12px; }`,
    `.profile-button { display:flex; align-items:center; gap:8px; padding:10px 14px; border-radius:999px; border:1px solid rgba(255,255,255,0.12); background:rgba(255,255,255,0.04); color:inherit; cursor:pointer; transition:background 0.2s, transform 0.2s; }`,
    `.profile-button:hover { background:rgba(255,255,255,0.08); transform:translateY(-1px); }`,
    `.profile-avatar { width:32px; height:32px; border-radius:50%; background:var(--amber); color:#111; display:flex; align-items:center; justify-content:center; font-weight:700; }`
  ]
})
export class LayoutComponent implements OnInit {
  private auth = inject(AuthService);
  private router = inject(Router);
  private themeService = inject(ThemeService);

  theme = this.themeService.theme;
  user = this.auth.currentUser;
  navItems: NavItem[] = [];
  activeRoute = 'home';
  pageTitle = 'Dashboard';

  get avatarLetter(): string {
    const name = this.user?.name || this.user?.email || 'U';
    return name[0].toUpperCase();
  }

  ngOnInit(): void {
    this.navItems = ROLE_MENUS[this.user?.role ?? 'CITIZEN'] ?? [];
    this.router.events.pipe(filter(e => e instanceof NavigationEnd)).subscribe((e: any) => {
      const seg = e.url.split('/').pop() || 'home';
      this.activeRoute = seg;
      const found = this.navItems.find(n => n.route === seg);
      this.pageTitle = found?.label ?? 'Dashboard';
    });
  }

  toggleTheme(): void {
    this.themeService.toggle();
  }

  logout(): void { this.auth.logout(); }
}
