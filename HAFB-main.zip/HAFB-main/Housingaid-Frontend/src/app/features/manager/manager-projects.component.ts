import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HousingProjectService } from '../../core/services/api.services';
import { ToastService } from '../../core/services/toast.service';
import { HousingProjectDTO } from '../../core/models/models';
import { StatusBadgeComponent } from '../../shared/components/status-badge.component';

@Component({
  selector: 'app-manager-projects',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <h1>Housing Projects</h1>
          <p>Create and manage housing development projects</p>
        </div>
        <button class="btn btn-primary" (click)="showForm = !showForm">
          {{ showForm ? '✕ Cancel' : '+ New Project' }}
        </button>
      </div>

      <!-- Stats row -->
      <div class="grid-3 mb-4">
        <div class="stat-card amber">
          <div class="stat-icon">🏗</div>
          <div class="stat-value text-amber">{{total()}}</div>
          <div class="stat-label">Total Projects</div>
        </div>
        <div class="stat-card green">
          <div class="stat-icon">💰</div>
          <div class="stat-value text-green">₹{{(budget() / 1e6).toFixed(1)}}M</div>
          <div class="stat-label">Total Budget</div>
        </div>
        <div class="stat-card blue">
          <div class="stat-icon">🔨</div>
          <div class="stat-value text-blue">{{inProgress()}}</div>
          <div class="stat-label">In Progress</div>
        </div>
      </div>

      <!-- Create Form -->
      <div class="card mb-4" *ngIf="showForm">
        <div class="card-title">{{editingId ? 'Update Project' : 'New Housing Project'}}</div>
        <div class="grid-2">
          <div class="form-group" style="grid-column:span 2">
            <label class="form-label">Project Title</label>
            <input class="form-input" [(ngModel)]="form.housingProjectTitle" placeholder="Affordable Housing Scheme Phase 1" />
          </div>
          <div class="form-group" style="grid-column:span 2">
            <label class="form-label">Description</label>
            <textarea class="form-textarea" [(ngModel)]="form.housingProjectDescription" placeholder="Project description…"></textarea>
          </div>
          <div class="form-group">
            <label class="form-label">Number of Houses</label>
            <input class="form-input" type="number" [(ngModel)]="form.numberOfHouses" min="1" />
          </div>
          <div class="form-group">
            <label class="form-label">Budget (₹)</label>
            <input class="form-input" type="number" [(ngModel)]="form.housingProjectBudget" min="1" />
          </div>
          <div class="form-group">
            <label class="form-label">Start Date</label>
            <input class="form-input" type="date" [(ngModel)]="form.housingProjectStartDate" />
          </div>
          <div class="form-group">
            <label class="form-label">End Date</label>
            <input class="form-input" type="date" [(ngModel)]="form.housingProjectEndDate" />
          </div>
          <div class="form-group">
            <label class="form-label">Status</label>
            <select class="form-select" [(ngModel)]="form.housingProjectStatus">
              <option value="PLANNED">Planned</option>
              <option value="UNDERPROGRESS">Under Progress</option>
              <option value="COMPLETED">Completed</option>
            </select>
          </div>
        </div>
        <div class="modal-footer" style="padding-top:0;border:none;margin-top:0">
          <button class="btn btn-ghost" (click)="cancelEdit()">Cancel</button>
          <button class="btn btn-primary" (click)="save()" [disabled]="saving()">
            <span *ngIf="saving()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
            {{ saving() ? 'Saving...' : (editingId ? 'Update' : 'Create Project') }}
          </button>
        </div>
      </div>

      <!-- Search -->
      <div class="search-bar mb-4">
        <input class="search-input" [(ngModel)]="searchTitle" placeholder="Search by title…" (input)="filterProjects()" />
        <button class="btn btn-ghost" (click)="load()">↻ Refresh</button>
      </div>

      <!-- Projects grid -->
      <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
      <div *ngIf="!loading() && filtered().length === 0" class="empty-state">
        <div class="empty-state-icon">🏗</div>
        <p>No projects found</p>
      </div>

      <div *ngIf="!loading()" style="display:flex;flex-direction:column;gap:12px">
        <div *ngFor="let p of filtered()" class="card">
          <div style="display:flex;justify-content:space-between;align-items:flex-start">
            <div style="flex:1">
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
                <span style="font-family:var(--font-mono);font-size:11px;color:var(--text3)">#{{p.housingProjectId}}</span>
                <app-status-badge [status]="p.housingProjectStatus" />
              </div>
              <div style="font-family:var(--font-head);font-size:16px;font-weight:700;margin-bottom:4px">{{p.housingProjectTitle}}</div>
              <div style="font-size:12px;color:var(--text2);max-width:600px">{{p.housingProjectDescription}}</div>
            </div>
            <div style="display:flex;gap:8px;flex-shrink:0;margin-left:16px">
              <button class="btn btn-ghost btn-sm" (click)="startEdit(p)">✏ Edit</button>
            </div>
          </div>
          <div style="display:flex;gap:32px;margin-top:16px;padding-top:12px;border-top:1px solid var(--border)">
            <div class="info-row">
              <span class="info-label">Houses</span>
              <span class="info-value">{{p.numberOfHouses}}</span>
            </div>
            <div class="info-row">
              <span class="info-label">Budget</span>
              <span class="info-value">₹{{p.housingProjectBudget.toLocaleString()}}</span>
            </div>
            <div class="info-row">
              <span class="info-label">Start</span>
              <span class="info-value">{{p.housingProjectStartDate}}</span>
            </div>
            <div class="info-row">
              <span class="info-label">End</span>
              <span class="info-value">{{p.housingProjectEndDate}}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ManagerProjectsComponent implements OnInit {
  private projectSvc = inject(HousingProjectService);
  private toast = inject(ToastService);

  loading = signal(true);
  saving = signal(false);
  all = signal<HousingProjectDTO[]>([]);
  filtered = signal<HousingProjectDTO[]>([]);
  total = signal(0);
  budget = signal(0);
  inProgress = signal(0);
  showForm = false;
  searchTitle = '';
  editingId: number | null = null;

  form: HousingProjectDTO = this.blankForm();

  blankForm(): HousingProjectDTO {
    return {
      numberOfHouses: 10,
      housingProjectTitle: '',
      housingProjectDescription: '',
      housingProjectStartDate: new Date().toISOString().slice(0,10),
      housingProjectEndDate: '',
      housingProjectBudget: 1000000,
      housingProjectStatus: 'PLANNED'
    };
  }

  ngOnInit(): void { this.load(); this.loadStats(); }

  load(): void {
    this.loading.set(true);
    this.projectSvc.getAll().subscribe({
      next: p => { this.all.set(p); this.filtered.set(p); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  loadStats(): void {
    this.projectSvc.getTotalCount().subscribe(n => this.total.set(n));
    this.projectSvc.getTotalBudget().subscribe(b => this.budget.set(b ?? 0));
    this.projectSvc.getCountByStatus('UNDERPROGRESS').subscribe(n => this.inProgress.set(n));
  }

  filterProjects(): void {
    const q = this.searchTitle.toLowerCase();
    this.filtered.set(this.all().filter(p => p.housingProjectTitle.toLowerCase().includes(q)));
  }

  startEdit(p: HousingProjectDTO): void {
    this.editingId = p.housingProjectId ?? null;
    this.form = { ...p };
    this.showForm = true;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  cancelEdit(): void { this.editingId = null; this.form = this.blankForm(); this.showForm = false; }

  save(): void {
    if (!this.form.housingProjectTitle || !this.form.housingProjectEndDate) {
      this.toast.error('Please fill all required fields');
      return;
    }
    this.saving.set(true);
    const req = this.editingId
      ? this.projectSvc.update(this.editingId, this.form)
      : this.projectSvc.create(this.form);
    req.subscribe({
      next: () => {
        this.toast.success(this.editingId ? 'Project updated!' : 'Project created!');
        this.cancelEdit();
        this.load();
        this.loadStats();
        this.saving.set(false);
      },
      error: (e) => { this.toast.error(e.error?.message || 'Save failed'); this.saving.set(false); }
    });
  }
}
