import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ResourcesService } from '../../core/services/api.services';
import { ToastService } from '../../core/services/toast.service';
import { ResourcesDTO } from '../../core/models/models';
import { StatusBadgeComponent } from '../../shared/components/status-badge.component';

@Component({
  selector: 'app-manager-resources',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <h1>Resources</h1>
          <p>Manage funds and materials allocated to projects</p>
        </div>
        <button class="btn btn-primary" (click)="showForm = !showForm">
          {{ showForm ? '✕ Cancel' : '+ Add Resource' }}
        </button>
      </div>

      <!-- Form -->
      <div class="card mb-4" *ngIf="showForm">
        <div class="card-title">{{editingId ? 'Update Resource' : 'New Resource'}}</div>
        <div class="grid-2">
          <div class="form-group">
            <label class="form-label">Resource Type</label>
            <select class="form-select" [(ngModel)]="form.resourcesType">
              <option value="FUNDS">Funds</option>
              <option value="MATERIALS">Materials</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Status</label>
            <select class="form-select" [(ngModel)]="form.resourcesStatus">
              <option value="AVAILABLE">Available</option>
              <option value="ALLOCATED">Allocated</option>
              <option value="INUSE">In Use</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Quantity</label>
            <input class="form-input" type="number" [(ngModel)]="form.resourcesQuantity" min="1" />
          </div>
          <div class="form-group">
            <label class="form-label">Housing Project ID</label>
            <input class="form-input" type="number" [(ngModel)]="form.housingProjectId" />
          </div>
        </div>
        <div class="modal-footer" style="padding-top:0;border:none;margin-top:0">
          <button class="btn btn-ghost" (click)="cancelEdit()">Cancel</button>
          <button class="btn btn-primary" (click)="save()" [disabled]="saving()">
            <span *ngIf="saving()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
            {{ saving() ? 'Saving...' : (editingId ? 'Update' : 'Create Resource') }}
          </button>
        </div>
      </div>

      <!-- Search / Filter -->
      <div class="search-bar mb-4">
        <select class="form-select" style="width:160px" [(ngModel)]="filterType" (change)="applyFilter()">
          <option value="">All Types</option>
          <option value="FUNDS">Funds</option>
          <option value="MATERIALS">Materials</option>
        </select>
        <select class="form-select" style="width:160px" [(ngModel)]="filterStatus" (change)="applyFilter()">
          <option value="">All Statuses</option>
          <option value="AVAILABLE">Available</option>
          <option value="ALLOCATED">Allocated</option>
          <option value="INUSE">In Use</option>
        </select>
        <button class="btn btn-ghost" (click)="load()">↻ Reset</button>
      </div>

      <!-- Table -->
      <div class="card">
        <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
        <div *ngIf="!loading() && resources().length === 0" class="empty-state">
          <div class="empty-state-icon">📦</div>
          <p>No resources found</p>
        </div>
        <div *ngIf="!loading() && resources().length > 0" class="table-wrap">
          <table>
            <thead>
              <tr><th>ID</th><th>Type</th><th>Quantity</th><th>Project</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
              <tr *ngFor="let r of resources()">
                <td class="td-mono">#{{r.resourcesId}}</td>
                <td>
                  <span style="font-size:16px">{{r.resourcesType === 'FUNDS' ? '💰' : '🧱'}}</span>
                  {{r.resourcesType}}
                </td>
                <td class="td-mono">{{r.resourcesQuantity}}</td>
                <td class="td-mono">#{{r.housingProjectId}}</td>
                <td><app-status-badge [status]="r.resourcesStatus" /></td>
                <td>
                  <button class="btn btn-ghost btn-sm" (click)="startEdit(r)">✏ Edit</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class ManagerResourcesComponent implements OnInit {
  private resSvc = inject(ResourcesService);
  private toast = inject(ToastService);

  loading = signal(true);
  saving = signal(false);
  resources = signal<ResourcesDTO[]>([]);
  showForm = false;
  filterType = '';
  filterStatus = '';
  editingId: number | null = null;

  form: ResourcesDTO = { resourcesType: 'FUNDS', resourcesStatus: 'AVAILABLE', resourcesQuantity: 1, housingProjectId: 1 };

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.filterType = '';
    this.filterStatus = '';
    this.resSvc.getAll().subscribe({
      next: r => { this.resources.set(r); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  applyFilter(): void {
    this.loading.set(true);
    this.resSvc.search(undefined, (this.filterType as any) || undefined, (this.filterStatus as any) || undefined).subscribe({
      next: r => { this.resources.set(r); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  startEdit(r: ResourcesDTO): void {
    this.editingId = r.resourcesId ?? null;
    this.form = { ...r };
    this.showForm = true;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  cancelEdit(): void { this.editingId = null; this.form = { resourcesType: 'FUNDS', resourcesStatus: 'AVAILABLE', resourcesQuantity: 1, housingProjectId: 1 }; this.showForm = false; }

  save(): void {
    this.saving.set(true);
    const req = this.editingId ? this.resSvc.update(this.editingId, this.form) : this.resSvc.create(this.form);
    req.subscribe({
      next: () => { this.toast.success(this.editingId ? 'Resource updated!' : 'Resource created!'); this.cancelEdit(); this.load(); this.saving.set(false); },
      error: (e) => { this.toast.error(e.error?.message || 'Save failed'); this.saving.set(false); }
    });
  }
}
