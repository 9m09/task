import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HousingApplicationService } from '../../core/services/api.services';
import { ToastService } from '../../core/services/toast.service';
import { HousingApplicationDTO, HousingApplicationStatus } from '../../core/models/models';
import { StatusBadgeComponent } from '../../shared/components/status-badge.component';

@Component({
  selector: 'app-officer-applications',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <div class="page-header">
        <h1>Applications</h1>
        <p>Review and manage housing applications</p>
      </div>

      <!-- Filter bar -->
      <div class="search-bar">
        <input class="search-input" [(ngModel)]="searchQ" placeholder="Search by ID or applicant…" (input)="filterApps()" />
        <select class="form-select" style="width:180px" [(ngModel)]="filterStatus" (change)="loadByStatus()">
          <option value="">All Statuses</option>
          <option value="PENDING">Pending</option>
          <option value="UNDER_REVIEW">Under Review</option>
          <option value="APPROVED">Approved</option>
          <option value="REJECTED">Rejected</option>
        </select>
        <button class="btn btn-ghost" (click)="load()">↻ Refresh</button>
      </div>

      <div class="card">
        <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
        <div *ngIf="!loading() && filtered().length === 0" class="empty-state">
          <div class="empty-state-icon">📋</div>
          <p>No applications found</p>
        </div>
        <div *ngIf="!loading() && filtered().length > 0" class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>ID</th><th>Applicant</th><th>Scheme</th><th>Project ID</th><th>Submitted</th><th>Status</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let a of filtered()">
                <td class="td-mono">#{{a.housingApplicationId}}</td>
                <td>{{a.housingApplicantName || 'Citizen '+a.citizenId}}</td>
                <td style="color:var(--text2);font-size:12px">{{a.housingSchemeName || '—'}}</td>
                <td class="td-mono">#{{a.housingProjectId}}</td>
                <td class="td-mono">{{a.housingApplicationSubmittedDate | date:'mediumDate'}}</td>
                <td><app-status-badge [status]="a.housingApplicationStatus ?? ''" /></td>
                <td>
                  <button class="btn btn-primary btn-sm"
                          *ngIf="a.housingApplicationStatus === 'PENDING' || a.housingApplicationStatus === 'UNDER_REVIEW'"
                          (click)="navigateToEligibility(a.housingApplicationId)">
                    Check
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class OfficerApplicationsComponent implements OnInit {
  private appSvc = inject(HousingApplicationService);
  private toast = inject(ToastService);
  private router = inject(Router);

  loading = signal(true);
  all = signal<HousingApplicationDTO[]>([]);
  filtered = signal<HousingApplicationDTO[]>([]);
  searchQ = '';
  filterStatus = '';

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.appSvc.getAll().subscribe({
      next: a => { this.all.set(a); this.filtered.set(a); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  loadByStatus(): void {
    if (!this.filterStatus) { this.load(); return; }
    this.loading.set(true);
    this.appSvc.getByStatus(this.filterStatus as HousingApplicationStatus).subscribe({
      next: a => { this.all.set(a); this.filtered.set(a); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  filterApps(): void {
    const q = this.searchQ.toLowerCase();
    this.filtered.set(this.all().filter(a =>
      String(a.housingApplicationId).includes(q) ||
      (a.housingApplicantName || '').toLowerCase().includes(q)
    ));
  }

  updateStatus(app: HousingApplicationDTO, status: string): void {
    this.appSvc.updateStatus(status, app.housingApplicationId!).subscribe({
      next: () => { this.toast.success(`Status updated to ${status}`); this.load(); },
      error: () => this.toast.error('Update failed')
    });
  }

  navigateToEligibility(applicationId?: number): void {
    if (!applicationId) return;
    this.router.navigate(['/dashboard/officer-eligibility', applicationId]);
  }
}
