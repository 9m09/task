import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EligibilityCheckService, HousingApplicationService, CitizenService, HousingProjectService, AllocationService } from '../../core/services/api.services';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { EligibilityCheckDTO, CitizenDocumentDTO, HousingApplicationDTO, HousingProjectDTO, AllocationResponseDTO } from '../../core/models/models';
import { StatusBadgeComponent } from '../../shared/components/status-badge.component';

@Component({
  selector: 'app-officer-eligibility',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <!-- Application Review View -->
      <div *ngIf="selectedApplicationId">
        <div class="page-header" style="display:flex;justify-content:space-between;align-items:center">
          <div>
            <h1>Review Application #{{ selectedApplicationId }}</h1>
            <p>Review and approve the housing application eligibility</p>
          </div>
          <button class="btn btn-ghost" (click)="goBack()">← Back</button>
        </div>

        <!-- Documents Table -->
        <div class="card mb-4">
          <div class="card-title">Citizen Documents</div>
          <div *ngIf="documents().length === 0" class="empty-state">
            <div class="empty-state-icon">📄</div>
            <p>No documents found for this applicant</p>
          </div>
          <div *ngIf="documents().length > 0" class="table-wrap">
            <table>
              <thead>
                <tr><th>Document ID</th><th>Document Type</th><th>Document URL</th><th>Status</th><th>Actions</th></tr>
              </thead>
              <tbody>
                <tr *ngFor="let doc of documents()">
                  <td class="td-mono">#{{doc.citizenDocumentId}}</td>
                  <td>{{doc.citizenDocumentDocType || 'N/A'}}</td>
                  <td>
                    <a [href]="doc.citizenDocumentFileUri" target="_blank" style="color:var(--primary);text-decoration:underline">
                      {{doc.citizenDocumentFileUri}}
                    </a>
                  </td>
                  <td><app-status-badge [status]="doc.citizenDocumentVerificationStatus || ''" /></td>
                  <td>
                    <div style="display:flex;gap:6px">
                      <button class="btn btn-success btn-sm" (click)="approveDocument(doc)" *ngIf="doc.citizenDocumentVerificationStatus !== 'VERIFIED'">
                        Accept
                      </button>
                      <button class="btn btn-danger btn-sm" (click)="rejectDocument(doc)" *ngIf="doc.citizenDocumentVerificationStatus !== 'REJECTED'">
                        Reject
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="card">
          <div class="card-title">Eligibility Check Form</div>
          <div class="grid-2">
            <div class="form-group">
              <label class="form-label">Housing Application ID</label>
              <input class="form-input" type="number" [(ngModel)]="form.housingApplicationId" readonly style="background:var(--bg2)" />
            </div>
            <div class="form-group">
              <label class="form-label">Officer ID</label>
              <input class="form-input" type="number" [(ngModel)]="form.officerId" readonly style="background:var(--bg2)" />
            </div>
            <div class="form-group">
              <label class="form-label">Verified Document ID</label>
              <input class="form-input" type="number" [value]="selectedVerifiedDocument?.citizenDocumentId || 'N/A'" readonly style="background:var(--bg2)" />
            </div>
            <div class="form-group">
              <label class="form-label">Verified Document Type</label>
              <input class="form-input" type="text" [value]="selectedVerifiedDocument?.citizenDocumentDocType || 'N/A'" readonly style="background:var(--bg2)" />
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Review Notes</label>
            <textarea class="form-textarea" [(ngModel)]="form.eligibilityCheckNotes" placeholder="Enter your review notes here..."></textarea>
          </div>
          <div style="display:flex;gap:12px;margin-top:24px">
            <button class="btn btn-success btn-lg" (click)="acceptAndApprove()" [disabled]="submitting()" style="flex:1">
              <span *ngIf="submitting()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
              {{ submitting() ? 'Approving...' : 'Accept' }}
            </button>
            <button class="btn btn-danger btn-lg" (click)="rejectApplication()" [disabled]="submitting()" style="flex:1">
              {{ submitting() ? 'Rejecting...' : 'Reject' }}
            </button>
          </div>
        </div>

        <div class="card mt-4">
          <div class="card-title">Housing Allocation</div>
          <div *ngIf="application?.housingApplicationStatus !== 'APPROVED'" class="info-box">
            Allocation is available only after this application is approved.
            Current status: <strong>{{ application?.housingApplicationStatus || 'Unknown' }}</strong>
          </div>
          <div *ngIf="application?.housingApplicationStatus === 'APPROVED'">
            <div class="grid-2">
              <div class="form-group">
                <label class="form-label">Citizen ID</label>
                <input class="form-input" type="number" [value]="application?.citizenId" readonly style="background:var(--bg2)" />
              </div>
              <div class="form-group">
                <label class="form-label">Officer ID</label>
                <input class="form-input" type="number" [value]="currentUserId" readonly style="background:var(--bg2)" />
              </div>
              <div class="form-group" style="grid-column:span 2">
                <label class="form-label">Select Project</label>
                <select class="form-select" [(ngModel)]="allocationForm.housingProjectId">
                  <option [value]="0" disabled>Select a project</option>
                  <option *ngFor="let project of projects()" [value]="project.housingProjectId">
                    #{{ project.housingProjectId }} — {{ project.housingProjectTitle }}
                  </option>
                </select>
              </div>
            </div>
            <button class="btn btn-primary w-full mt-2" (click)="allocateHousing()" [disabled]="submitting() || !allocationForm.housingProjectId">
              <span *ngIf="submitting()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
              {{ submitting() ? 'Allocating...' : 'Allocate Housing' }}
            </button>
            <div *ngIf="allocationResult()" class="card mt-4">
              <div class="card-title">Allocation Result</div>
              <div class="info-box success-box">
                <div><strong>{{ allocationResult()?.message }}</strong></div>
                <div>Allocation ID: #{{ allocationResult()?.allocationId }}</div>
                <div>Project ID: #{{ allocationResult()?.housingProjectId }}</div>
                <div>Unit ID: #{{ allocationResult()?.housingunitId }}</div>
                <div>Status: {{ allocationResult()?.status }}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Eligibility Checks List View -->
      <div *ngIf="!selectedApplicationId">
        <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
          <div>
            <h1>Eligibility Checks</h1>
            <p>Submit and review eligibility verifications</p>
          </div>
          <button class="btn btn-primary" (click)="showForm = !showForm">
            {{ showForm ? '✕ Cancel' : '+ New Check' }}
          </button>
        </div>

        <!-- Submission form -->
        <div class="card mb-4" *ngIf="showForm">
          <div class="card-title">New Eligibility Check</div>
          <div class="grid-2">
            <div class="form-group">
              <label class="form-label">Housing Application ID</label>
              <input class="form-input" type="number" [(ngModel)]="form.housingApplicationId" placeholder="e.g. 1" />
            </div>
            <div class="form-group">
              <label class="form-label">Citizen Document ID</label>
              <input class="form-input" type="number" [(ngModel)]="form.citizenDocumentId" placeholder="e.g. 5" />
            </div>
            <div class="form-group">
              <label class="form-label">Officer ID</label>
              <input class="form-input" type="number" [(ngModel)]="form.officerId" [value]="currentUserId" />
            </div>
            <div class="form-group">
              <label class="form-label">Result</label>
              <select class="form-select" [(ngModel)]="form.eligibilityCheckResult">
                <option value="ELIGIBLE">ELIGIBLE</option>
                <option value="NOTELIGIBLE">NOT ELIGIBLE</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Notes</label>
            <textarea class="form-textarea" [(ngModel)]="form.eligibilityCheckNotes" placeholder="Document review notes…"></textarea>
          </div>
          <div class="modal-footer" style="padding-top:0;border:none;margin-top:0">
            <button class="btn btn-primary" (click)="submit()" [disabled]="submitting()">
              <span *ngIf="submitting()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
              {{ submitting() ? 'Submitting...' : 'Submit Check' }}
            </button>
          </div>
        </div>

        <!-- History -->
        <div class="card">
          <div class="card-title">Check History</div>
          <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
          <div *ngIf="!loading() && checks().length === 0" class="empty-state">
            <div class="empty-state-icon">✅</div>
            <p>No eligibility checks found</p>
          </div>
          <div *ngIf="!loading() && checks().length > 0" class="table-wrap">
            <table>
              <thead>
                <tr><th>ID</th><th>Application ID</th><th>Document ID</th><th>Officer ID</th><th>Result</th><th>Notes</th></tr>
              </thead>
              <tbody>
                <tr *ngFor="let c of checks()">
                  <td class="td-mono">#{{c.eligibilityCheckId || c.id}}</td>
                  <td class="td-mono">#{{c.housingApplicationId}}</td>
                  <td class="td-mono">#{{c.citizenDocumentId}}</td>
                  <td class="td-mono">#{{c.officerId}}</td>
                  <td><app-status-badge [status]="c.eligibilityCheckResult || c.result || ''" /></td>
                  <td style="font-size:12px;color:var(--text2);max-width:200px">{{c.eligibilityCheckNotes || c.notes}}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `
})
export class OfficerEligibilityComponent implements OnInit {
  private eligSvc = inject(EligibilityCheckService);
  private appSvc = inject(HousingApplicationService);
  private citizenSvc = inject(CitizenService);
  private projectSvc = inject(HousingProjectService);
  private allocSvc = inject(AllocationService);
  private auth = inject(AuthService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  loading = signal(true);
  submitting = signal(false);
  docsSubmitting = signal(false);
  checks = signal<EligibilityCheckDTO[]>([]);
  documents = signal<CitizenDocumentDTO[]>([]);
  verifiedDocuments = signal<CitizenDocumentDTO[]>([]);
  projects = signal<HousingProjectDTO[]>([]);
  allocationResult = signal<AllocationResponseDTO | null>(null);
  application: HousingApplicationDTO | null = null;
  citizenId = 0;
  showForm = false;
  selectedApplicationId = 0;
  selectedVerifiedDocument: CitizenDocumentDTO | null = null;
  currentUserId = this.auth.currentUser?.userId ?? 1;

  allocationForm = {
    citizenId: 0,
    officerId: this.currentUserId,
    housingProjectId: 0
  };

  form: EligibilityCheckDTO = {
    housingApplicationId: 0,
    citizenDocumentId: 0,
    officerId: this.auth.currentUser?.userId ?? 1,
    eligibilityCheckResult: 'ELIGIBLE',
    eligibilityCheckNotes: '',
    eligibilityCheckDate: new Date().toISOString().split('T')[0]
  };

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const appId = Number(params.get('applicationId'));
      this.selectedApplicationId = appId > 0 ? appId : 0;
      if (this.selectedApplicationId) {
        this.form.housingApplicationId = this.selectedApplicationId;
        this.loadApplication();
        this.showForm = true;
      }
    });
    this.load();
    this.loadProjects();
  }

  loadApplication(): void {
    if (!this.selectedApplicationId) return;
    this.appSvc.getById(this.selectedApplicationId).subscribe({
      next: (app) => {
        this.application = app;
        this.citizenId = app.citizenId;
        this.allocationForm.citizenId = app.citizenId;
        this.loadDocuments();
      },
      error: () => this.toast.error('Failed to load application')
    });
  }

  loadDocuments(): void {
    if (!this.citizenId) return;
    this.citizenSvc.getDocuments(this.citizenId).subscribe({
      next: (docs) => {
        this.documents.set(docs);
        // Filter and set only verified documents
        const verified = docs.filter(d => d.citizenDocumentVerificationStatus === 'VERIFIED');
        this.verifiedDocuments.set(verified);
        // Automatically select the first verified document
        if (verified.length > 0) {
          this.selectedVerifiedDocument = verified[0];
          this.form.citizenDocumentId = verified[0].citizenDocumentId || 0;
        }
      },
      error: () => this.toast.error('Failed to load documents')
    });
  }

  loadProjects(): void {
    this.projectSvc.getAll().subscribe({
      next: projects => this.projects.set(projects),
      error: () => this.toast.error('Failed to load housing projects')
    });
  }

  load(): void {
    this.eligSvc.getHistory().subscribe({
      next: c => { this.checks.set(c); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  submit(): void {
    if (!this.form.housingApplicationId || !this.form.citizenDocumentId) {
      this.toast.error('Please fill all required fields');
      return;
    }
    this.submitting.set(true);
    this.eligSvc.submit(this.form).subscribe({
      next: () => { 
        this.toast.success('Eligibility check submitted!'); 
        this.showForm = false; 
        this.load(); 
        this.submitting.set(false); 
      },
      error: (e) => { 
        this.toast.error(e.error?.message || 'Submission failed'); 
        this.submitting.set(false); 
      }
    });
  }

  acceptAndApprove(): void {
    if (!this.selectedApplicationId) {
      this.toast.error('No application selected');
      return;
    }
    if (!this.selectedVerifiedDocument || !this.selectedVerifiedDocument.citizenDocumentId) {
      this.toast.error('No verified document found for this applicant');
      return;
    }

    this.submitting.set(true);
    const today = new Date().toISOString().split('T')[0];
    const payload: EligibilityCheckDTO = {
      housingApplicationId: this.selectedApplicationId,
      citizenDocumentId: this.selectedVerifiedDocument.citizenDocumentId,
      officerId: this.currentUserId,
      eligibilityCheckResult: 'ELIGIBLE',
      eligibilityCheckNotes: this.form.eligibilityCheckNotes || '',
      eligibilityCheckDate: today
    };

    this.eligSvc.submit(payload).subscribe({
      next: () => {
        this.toast.success('Application approved! Eligibility status: ELIGIBLE');
        this.load();
        this.showForm = false;
        this.selectedApplicationId = 0;
        this.submitting.set(false);
        setTimeout(() => this.router.navigate(['/dashboard/officer-applications']), 1500);
      },
      error: (e) => {
        this.toast.error(e.error?.message || 'Approval failed');
        this.submitting.set(false);
      }
    });
  }

  rejectApplication(): void {
    if (!this.selectedApplicationId) {
      this.toast.error('No application selected');
      return;
    }
    if (!this.selectedVerifiedDocument || !this.selectedVerifiedDocument.citizenDocumentId) {
      this.toast.error('No verified document found for this applicant');
      return;
    }

    this.submitting.set(true);
    const today = new Date().toISOString().split('T')[0];
    const payload: EligibilityCheckDTO = {
      housingApplicationId: this.selectedApplicationId,
      citizenDocumentId: this.selectedVerifiedDocument.citizenDocumentId,
      officerId: this.currentUserId,
      eligibilityCheckResult: 'NOTELIGIBLE',
      eligibilityCheckNotes: this.form.eligibilityCheckNotes || '',
      eligibilityCheckDate: today
    };

    this.eligSvc.submit(payload).subscribe({
      next: () => {
        this.toast.success('Application rejected! Eligibility status: NOT ELIGIBLE');
        this.load();
        this.showForm = false;
        this.selectedApplicationId = 0;
        this.submitting.set(false);
        setTimeout(() => this.router.navigate(['/dashboard/officer-applications']), 1500);
      },
      error: (e) => {
        this.toast.error(e.error?.message || 'Rejection failed');
        this.submitting.set(false);
      }
    });
  }

  allocateHousing(): void {
    if (!this.application?.citizenId) {
      this.toast.error('No citizen selected for allocation');
      return;
    }
    if (!this.allocationForm.housingProjectId) {
      this.toast.error('Please select a housing project');
      return;
    }

    this.submitting.set(true);
    const request = {
      citizenId: this.application.citizenId,
      officerId: this.currentUserId,
      housingProjectId: this.allocationForm.housingProjectId
    };

    this.allocSvc.create(request).subscribe({
      next: (result) => {
        this.allocationResult.set(result);
        this.toast.success('Housing allocation created successfully');
        this.submitting.set(false);
      },
      error: (e) => {
        this.toast.error(e.error?.message || 'Allocation failed');
        this.submitting.set(false);
      }
    });
  }

  goBack(): void {
    this.router.navigate(['/dashboard/officer-applications']);
  }

  updateDocumentStatus(docId: number, status: string): void {
    this.citizenSvc.updateDocStatus(status, docId).subscribe({
      next: () => {
        this.toast.success(`Document status updated to ${status}`);
        this.loadDocuments();
      },
      error: () => this.toast.error('Failed to update document status')
    });
  }

  approveDocument(doc: CitizenDocumentDTO): void {
    if (!doc.citizenDocumentId) return;
    this.updateDocumentStatus(doc.citizenDocumentId, 'VERIFIED');
  }

  rejectDocument(doc: CitizenDocumentDTO): void {
    if (!doc.citizenDocumentId) return;
    this.updateDocumentStatus(doc.citizenDocumentId, 'REJECTED');
  }
}
