import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HousingUnitService, ResourcesService } from '../../core/services/api.services';
import { ToastService } from '../../core/services/toast.service';
import { HousingUnitDTO } from '../../core/models/models';
import { StatusBadgeComponent } from '../../shared/components/status-badge.component';

@Component({
  selector: 'app-officer-units',
  standalone: true,
  imports: [CommonModule, FormsModule, StatusBadgeComponent],
  template: `
    <div class="page-content">
      <div class="page-header" style="display:flex;justify-content:space-between;align-items:flex-start">
        <div>
          <h1>Housing Units</h1>
          <p>Browse and manage individual housing units</p>
        </div>
        <button class="btn btn-primary" (click)="showForm = !showForm">
          {{ showForm ? '✕ Cancel' : '+ Add Unit' }}
        </button>
      </div>

      <!-- Add form -->
      <div class="card mb-4" *ngIf="showForm">
        <div class="card-title">New Housing Unit</div>
        <div class="grid-2">
          <div class="form-group">
            <label class="form-label">Location</label>
            <input class="form-input" [(ngModel)]="form.housingUnitLocation" placeholder="Block A, City" />
          </div>
          <div class="form-group">
            <label class="form-label">Type</label>
            <select class="form-select" [(ngModel)]="form.housingUnitType">
              <option value="APARTMENT">Apartment</option>
              <option value="SHELTER">Shelter</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Capacity</label>
            <input class="form-input" type="number" [(ngModel)]="form.housingUnitCapacity" min="1" />
          </div>
          <div class="form-group">
            <label class="form-label">Status</label>
            <select class="form-select" [(ngModel)]="form.housingUnitStatus">
              <option value="AVAILABLE">Available</option>
              <option value="ALLOCATED">Allocated</option>
              <option value="MAINTENANCE">Maintenance</option>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Resource ID</label>
            <input class="form-input" type="number" [(ngModel)]="form.resourcesId" />
          </div>
          <div class="form-group">
            <label class="form-label">Project ID</label>
            <input class="form-input" type="number" [(ngModel)]="form.housingProjectId" />
          </div>
        </div>
        <div class="modal-footer" style="padding-top:0;border:none;margin-top:0">
          <button class="btn btn-primary" (click)="createUnit()" [disabled]="saving()">
            <span *ngIf="saving()" class="spinner" style="width:14px;height:14px;border-width:2px"></span>
            {{ saving() ? 'Saving...' : 'Create Unit' }}
          </button>
        </div>
      </div>

      <!-- Search -->
      <div class="search-bar mb-4">
        <input class="search-input" [(ngModel)]="searchLocation" placeholder="Filter by location…" />
        <select class="form-select" style="width:160px" [(ngModel)]="searchType">
          <option value="">All Types</option>
          <option value="APARTMENT">Apartment</option>
          <option value="SHELTER">Shelter</option>
        </select>
        <button class="btn btn-ghost" (click)="searchUnits()">Search</button>
        <button class="btn btn-ghost" (click)="load()">↻ Reset</button>
      </div>

      <!-- Units grid -->
      <div *ngIf="loading()" class="loading-overlay"><span class="spinner"></span></div>
      <div *ngIf="!loading() && units().length === 0" class="empty-state">
        <div class="empty-state-icon">🏠</div>
        <p>No housing units found</p>
      </div>
      <div class="grid-3" *ngIf="!loading() && units().length > 0">
        <div *ngFor="let u of units()" class="card" style="position:relative">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
            <div>
              <div style="font-family:var(--font-mono);font-size:11px;color:var(--text3)">#{{u.housingUnitId}}</div>
              <div style="font-weight:600;font-size:14px;margin-top:2px">{{u.housingUnitType}}</div>
            </div>
            <app-status-badge [status]="u.housingUnitStatus" />
          </div>
          <div class="info-grid" style="grid-template-columns:1fr 1fr">
            <div class="info-row">
              <span class="info-label">Location</span>
              <span class="info-value" style="font-size:12px">{{u.housingUnitLocation}}</span>
            </div>
            <div class="info-row">
              <span class="info-label">Capacity</span>
              <span class="info-value">{{u.housingUnitCapacity}} persons</span>
            </div>
            <div class="info-row">
              <span class="info-label">Project</span>
              <span class="info-value">#{{u.housingProjectId}}</span>
            </div>
            <div class="info-row">
              <span class="info-label">Resource</span>
              <span class="info-value">#{{u.resourcesId}}</span>
            </div>
          </div>
          <div style="margin-top:12px;display:flex;gap:6px">
            <select class="form-select" style="flex:1;font-size:12px;padding:5px 8px" [(ngModel)]="u.housingUnitStatus">
              <option value="AVAILABLE">Available</option>
              <option value="ALLOCATED">Allocated</option>
              <option value="MAINTENANCE">Maintenance</option>
            </select>
            <button class="btn btn-ghost btn-sm" (click)="updateStatus(u)">Update</button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class OfficerUnitsComponent implements OnInit {
  private unitSvc = inject(HousingUnitService);
  private toast = inject(ToastService);

  loading = signal(true);
  saving = signal(false);
  units = signal<HousingUnitDTO[]>([]);
  showForm = false;
  searchLocation = '';
  searchType = '';

  form: HousingUnitDTO = {
    housingUnitLocation: '',
    housingUnitType: 'APARTMENT',
    housingUnitCapacity: 1,
    housingUnitStatus: 'AVAILABLE',
    resourcesId: 1,
    housingProjectId: 1
  };

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading.set(true);
    this.unitSvc.getAll().subscribe({
      next: u => { this.units.set(u); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  searchUnits(): void {
    this.loading.set(true);
    this.unitSvc.search(undefined, this.searchLocation || undefined, (this.searchType as any) || undefined).subscribe({
      next: u => { this.units.set(u); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  createUnit(): void {
    this.saving.set(true);
    this.unitSvc.create(this.form).subscribe({
      next: () => { this.toast.success('Unit created!'); this.showForm = false; this.load(); this.saving.set(false); },
      error: (e) => { this.toast.error(e.error?.message || 'Create failed'); this.saving.set(false); }
    });
  }

  updateStatus(u: HousingUnitDTO): void {
    this.unitSvc.updateStatus(u.housingUnitStatus, u.housingUnitId!).subscribe({
      next: () => this.toast.success('Status updated'),
      error: () => this.toast.error('Update failed')
    });
  }
}
