import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-status-badge',
  standalone: true,
  template: `<span class="badge" [class]="badgeClass">{{status}}</span>`
})
export class StatusBadgeComponent {
  @Input() status = '';

  get badgeClass(): string {
    const s = (this.status || '').toLowerCase();
    if (['active','available','approved','compliant','completed','verified','eligible'].some(x => s.includes(x))) return 'badge-green';
    if (['pending','planned','under_review','inuse'].some(x => s.includes(x))) return 'badge-amber';
    if (['inactive','rejected','noncompliant','noteligible','suspended','maintenance'].some(x => s.includes(x))) return 'badge-red';
    if (['allocated','underprogress','flagged'].some(x => s.includes(x))) return 'badge-blue';
    return 'badge-grey';
  }
}
