Prototype link:  https://housing-aid.github.io/Housing-Aid-Prototype/
